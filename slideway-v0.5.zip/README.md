# SlideWay 0.5 — Foundation, Telegram, Mini App, Control Center

**Play. Connect. Level Up.**

Реализованы рабочий backend, бот, личный кабинет Mini App и административная панель. Это поэтапная реализация исходного большого ТЗ: игры, комнаты, групповая модерация и платежи пока отсутствуют. Интерфейс не показывает вымышленные данные.

## Что работает

- Чёрно-белый Liquid Glass: стеклянная навигация/диалоги, системные emoji, анимации переходов и нажатий, поддержка reduced motion. На iPhone emoji отображаются шрифтом Apple; на других платформах — системным.
- Друзья: поиск по имени/username с opt-in приватностью, заявки, принятие/отклонение/отмена, удаление, блокировка и разблокировка. Подробнее: [SOCIAL.md](docs/SOCIAL.md).
- Центр активности: непрочитанный счётчик, события новой заявки и принятия дружбы, прочтение и удаление уведомлений. Обновление выполняется каждые 15 секунд без хранения токенов в браузере.

- NestJS API, PostgreSQL/Prisma, Redis-лимиты, пять SQL-миграций, seed справочника интересов.
- Настоящая серверная проверка Telegram initData: HMAC, возраст, защита от повтора; случайные Bearer-сессии, в БД только хеши токенов.
- Профили, интересы, приватность, RU/EN, светлая/тёмная/Telegram-тема, активные сессии, отзыв и удаление аккаунта. Сессии хранятся в памяти фронтенда, не в localStorage.
- Бот grammY: /start, /help, /profile, /settings, /privacy; открытие Mini App и contextual deep links. Webhook secret, inbox PostgreSQL, конкурентные workers, повторы временных ошибок и обработка блокировки бота.
- Отдельный Control Center: реальные метрики, поиск/пагинация пользователей, временные и бессрочные ограничения, разблокировка, отзыв сессий, делегирование ролей, журнал действий. Изменения и аудит атомарны и идемпотентны.
- Owner, Administrator, Moderator, Support, Analyst с проверкой прав на backend.
- Docker/Compose/Nginx/TLS-конфигурация, OpenAPI, CI и автоматизированные проверки.

## Доступ владельца

**Telegram ID владельца: `8765005700`.** Он задан серверным `ADMIN_OWNER_TELEGRAM_ID`. Доступ возникает только после проверки подписанных Telegram-данных. Ввести ID в форму или параметр запроса недостаточно.

Скрытые команды не публикуются через setMyCommands:

- `/admin` — открывает Control Center владельцу и пользователям, которым он явно назначил административную роль.
- `/stats` — реальные счётчики, только владельцу.

Обычным пользователям эти команды не отвечают. Скрытость не заменяет авторизацию: каждый admin endpoint проверяет права. Для чувствительных изменений требуется вход не старше десяти минут. Владельца нельзя заблокировать, понизить или удалить через интерфейс; сначала нужно передать владение в серверной конфигурации.

## Локальный запуск

Требуются Node.js 24 LTS, PostgreSQL 17 и Redis 7.

```sh
cp .env.example .env
# Заменить DATABASE_URL, REDIS_URL, TELEGRAM_BOT_TOKEN и ALLOWED_ORIGINS.
npm ci
npm run db:generate
npm run db:migrate
npm run db:seed
npm run build
npm start
# В отдельных терминалах:
npm run dev:miniapp   # http://localhost:5173
npm run dev:admin     # http://localhost:5174/admin/
```

Vite проксирует /api в API на порту 3000. В ALLOWED_ORIGINS перечислить оба origin через запятую. Для локального API на хосте нужны доступные ему PostgreSQL/Redis; production Compose не публикует их порты.

Без Telegram initData приложения показывают инструкцию входа, а не тестовый профиль. Для реального запуска внутри Telegram необходим HTTPS-домен. Не отправляйте bot token в чат или Git.

## Подключение Telegram

1. Задать BOT_ENABLED=true, TELEGRAM_BOT_TOKEN, TELEGRAM_BOT_USERNAME, MINIAPP_URL и TELEGRAM_WEBHOOK_SECRET — случайную строку 32+ символа.
2. Задать WEBHOOK_URL=https://YOUR_DOMAIN/api/v1/telegram/webhook.
3. Развернуть API и обе frontend-сборки по инструкции docs/DEPLOYMENT.md. Mini App — `/`, Control Center — `/admin/`.
4. `npm run bot:register` настраивает команды, кнопку меню и webhook. Это реальный вызов Telegram; он не выполняется автоматически при старте.
5. `npm run start:bot` запускает worker. В Compose: `docker compose --profile telegram up -d`.
6. Открыть бот со своего аккаунта и отправить `/admin`.

В текущей среде настоящие токен и домен не настроены: регистрация webhook, публикация и проверка в реальном Telegram не выполнены.

## Проверки

`npm run check` — Prisma generate, обе frontend-сборки, backend и unit tests.

```sh
# Только изолированная БД slideway_test и отдельная Redis DB 15:
NODE_ENV=test DATABASE_URL=postgresql://USER:PASSWORD@localhost:5432/slideway_test REDIS_URL=redis://localhost:6379/15 npm run db:migrate
NODE_ENV=test DATABASE_URL=postgresql://USER:PASSWORD@localhost:5432/slideway_test REDIS_URL=redis://localhost:6379/15 npm run db:seed
NODE_ENV=test DATABASE_URL=postgresql://USER:PASSWORD@localhost:5432/slideway_test REDIS_URL=redis://localhost:6379/15 npm run test:integration
```

Тесты очищают тестовые данные. Browser E2E: `tests/browser_e2e.py` и `tests/admin_browser_e2e.py`, с теми же переменными, Python Playwright и Chromium. Только тестовый браузер получает синтетический Telegram-контекст; backend и БД настоящие. Production-код не содержит обхода авторизации.

## Документация

- docs/ARCHITECTURE.md и docs/STAGE2-DESIGN.md — архитектура и этапы.
- docs/ADMIN.md — права, скрытые команды, владельцы, аудит.
- docs/openapi.json — реализованное API.
- docs/SECURITY.md — границы защиты и ограничения.
- docs/DEPLOYMENT.md — VPS, обновление, backup/restore.
- docs/ROADMAP.md — незавершённые функции.
- docs/VALIDATION.md — фактические результаты и пределы проверок.

Не заявляется готовность всей платформы к production или гарантированная защита от атак.
