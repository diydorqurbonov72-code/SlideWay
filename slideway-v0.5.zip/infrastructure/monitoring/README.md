# Foundation monitoring
API writes JSON request logs with generated request ID, method, status and duration; no request bodies, Authorization headers, usernames or query strings.
Readiness checks PostgreSQL and Redis; liveness checks process only. Configure external probes for /api/v1/health/ready and alert on failures and increasing 5xx rates. Containers log to stdout; set Docker log rotation on the host.
Prometheus/Grafana/Sentry and business metrics are not implemented in this milestone. No capacity claims have been measured.
