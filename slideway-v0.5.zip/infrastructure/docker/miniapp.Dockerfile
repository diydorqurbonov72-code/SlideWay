# syntax=docker/dockerfile:1
FROM node:24-bookworm-slim AS build
WORKDIR /app
COPY package.json package-lock.json ./
COPY apps/miniapp/package.json apps/miniapp/package.json
COPY apps/admin/package.json apps/admin/package.json
RUN --mount=type=secret,id=proxy_ca \
    if [ -f /run/secrets/proxy_ca ]; then NODE_EXTRA_CA_CERTS=/run/secrets/proxy_ca npm ci --workspace @slideway/miniapp --workspace @slideway/admin --include-workspace-root=false; else npm ci --workspace @slideway/miniapp --workspace @slideway/admin --include-workspace-root=false; fi
COPY apps/miniapp apps/miniapp
COPY apps/admin apps/admin
ARG VITE_BOT_USERNAME
ENV VITE_BOT_USERNAME=$VITE_BOT_USERNAME
RUN npm run build -w @slideway/miniapp && npm run build -w @slideway/admin
FROM nginxinc/nginx-unprivileged:stable-alpine
COPY --from=build --chown=101:101 /app/apps/miniapp/dist /usr/share/nginx/html
COPY --from=build --chown=101:101 /app/apps/admin/dist /usr/share/nginx/html/admin
COPY --chown=101:101 --chmod=644 infrastructure/nginx/default.conf /etc/nginx/conf.d/default.conf
