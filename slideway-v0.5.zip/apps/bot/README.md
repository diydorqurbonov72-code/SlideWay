# SlideWay Telegram bot

Implemented private commands: /start /help /profile /settings /privacy, RU/EN, database registration, profile lookup, contextual Mini App buttons and menu registration. No group moderation, payments, invitations, support or other commands yet.

API endpoint POST /api/v1/telegram/webhook validates X-Telegram-Bot-Api-Secret-Token, limits commands per sender and stores a minimal update in PostgreSQL. update_id is unique. No message body is logged. Unsupported group/media updates are acknowledged without storage.

Separate worker: `npm run start:bot` after build. Set BOT_ENABLED=true, TELEGRAM_BOT_TOKEN, TELEGRAM_BOT_USERNAME, TELEGRAM_WEBHOOK_SECRET (random 32+ characters), MINIAPP_URL (HTTPS). Worker gets actual bot metadata using getMe and checks username. Config has no production Telegram test mode.

`npm run bot:register` explicitly configures commands, menu and webhook. Requires WEBHOOK_URL=https://YOUR_DOMAIN/api/v1/telegram/webhook. This is a real Telegram mutation; it is NOT run automatically on service start. No registration was run in the development environment because credentials were not supplied.

Inbox worker claims via SKIP LOCKED with 60-second lease, retries transient errors up to five attempts, respects Telegram 429 retry_after, marks 400/403 terminal, and clears payload after success/final failure. Delivery is at-least-once: a crash after Telegram accepts a message but before recording completion can cause a duplicate outgoing message. No claim of exactly-once external delivery.


Hidden commands: /admin is available to configured Owner or explicitly delegated admin roles; /stats is Owner-only. They are not published in setMyCommands. Owner configuration is ADMIN_OWNER_TELEGRAM_ID=8765005700. Access is also checked independently by the admin API. These commands have automated tests for ordinary users, Owner and delegated access.
