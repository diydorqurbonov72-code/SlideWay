import { Bot, InlineKeyboard } from "grammy";
import { PrismaClient } from "@prisma/client";
export const commands = [
  { command: "start", description: "Open SlideWay" },
  { command: "help", description: "Help / Помощь" },
  { command: "profile", description: "Your profile / Профиль" },
  { command: "settings", description: "Settings / Настройки" },
  { command: "privacy", description: "Privacy / Приватность" },
];
export function createBot(
  db: PrismaClient,
  token: string,
  username: string,
  miniAppUrl: string,
  ownerId = "8765005700",
) {
  const bot = new Bot(token, { client: { timeoutSeconds: 15 } });
  bot.on("message:text", async (ctx) => {
    if (
      ctx.chat.type !== "private" ||
      ctx.from.is_bot ||
      ctx.chat.id !== ctx.from.id
    )
      return;
    const parsed =
      /^\/(start|help|profile|settings|privacy|admin|stats)(?:@([A-Za-z0-9_]+))?(?:\s|$)/i.exec(
        ctx.message.text,
      );
    if (
      !parsed ||
      (parsed[2] && parsed[2].toLowerCase() !== username.toLowerCase())
    )
      return;
    if (
      ["admin", "stats"].includes(parsed[1].toLowerCase()) &&
      ctx.from.id.toString() !== ownerId
    ) {
      if (parsed[1].toLowerCase() === "stats") return;
      const existing = await db.user.findUnique({
        where: { telegramId: BigInt(ctx.from.id) },
        include: { adminUser: true },
      });
      if (
        !existing?.adminUser ||
        (existing.banned &&
          (!existing.banUntil || existing.banUntil > new Date()))
      )
        return;
    }
    const command = parsed[1].toLowerCase(),
      tg = ctx.from;
    const user = await db.user.upsert({
      where: { telegramId: BigInt(tg.id) },
      create: {
        telegramId: BigInt(tg.id),
        displayName: [tg.first_name, tg.last_name]
          .filter(Boolean)
          .join(" ")
          .slice(0, 80),
        username: tg.username,
        locale: tg.language_code === "ru" ? "ru" : "en",
        settings: { create: {} },
      },
      update: { username: tg.username ?? null },
      include: { settings: true },
    });
    const ru = user.locale === "ru";
    if (user.banned && (!user.banUntil || user.banUntil > new Date())) {
      await ctx.reply(
        ru ? "Доступ к аккаунту ограничен." : "Account access is restricted.",
      );
      return;
    }
    if (command === "admin") {
      await ctx.reply(
        ru
          ? "SlideWay Control Center. Доступ проверяется сервером."
          : "SlideWay Control Center. Access is verified by the server.",
        {
          reply_markup: new InlineKeyboard().webApp(
            ru ? "Открыть админ-панель" : "Open Control Center",
            new URL("/admin/", miniAppUrl).toString(),
          ),
        },
      );
      return;
    }
    if (command === "stats") {
      const [users, sessions, pending] = await Promise.all([
        db.user.count(),
        db.userSession.count({ where: { expiresAt: { gt: new Date() } } }),
        db.telegramUpdate.count({
          where: { status: { in: ["pending", "processing"] } },
        }),
      ]);
      await ctx.reply(
        ru
          ? `Пользователи: ${users}\nАктивные сессии: ${sessions}\nЗадания бота в очереди: ${pending}`
          : `Users: ${users}\nActive sessions: ${sessions}\nQueued bot tasks: ${pending}`,
      );
      return;
    }
    const path =
      command === "privacy"
        ? "privacy"
        : command === "settings"
          ? "settings"
          : command === "profile"
            ? "profile"
            : "home";
    const url = new URL(miniAppUrl);
    url.hash = path;
    const keyboard = new InlineKeyboard().webApp(
      ru ? "Открыть SlideWay" : "Open SlideWay",
      url.toString(),
    );
    let text = ru
      ? "Добро пожаловать в SlideWay!\n\nСоздай свой профиль, выбери интересы и настрой приватность.\n\nPlay. Connect. Level Up."
      : "Welcome to SlideWay!\n\nSet up your profile, choose your interests and manage your privacy.\n\nPlay. Connect. Level Up.";
    if (command === "profile")
      text = ru
        ? `Твой профиль: ${user.displayName}\n${user.bio || "Описание пока не добавлено."}`
        : `Your profile: ${user.displayName}\n${user.bio || "No bio yet."}`;
    if (command === "settings")
      text = ru
        ? "Язык, интересы и активные сессии доступны в настройках SlideWay."
        : "Manage your language, interests and active sessions in SlideWay settings.";
    if (command === "privacy")
      text = ru
        ? "Ты управляешь приватностью. По умолчанию видимость профиля и запросы в друзья выключены. Настройки и удаление аккаунта доступны в Mini App."
        : "You control your privacy. Profile visibility and friend requests are off by default. Manage settings or delete your account in the Mini App.";
    if (command === "help")
      text = ru
        ? "Доступно сейчас: профиль, интересы, приватность и сессии.\n/start — открыть приложение\n/profile — профиль\n/settings — настройки\n/privacy — приватность\n\nИгры, друзья и сообщества появятся в следующих этапах."
        : "Available now: profile, interests, privacy and sessions.\n/start — open app\n/profile — profile\n/settings — settings\n/privacy — privacy\n\nGames, friends and communities are planned for later releases.";
    await ctx.reply(text, { reply_markup: keyboard });
  });
  return bot;
}
