import "dotenv/config";
import { PrismaClient } from "@prisma/client";
import { PrismaPg } from "@prisma/adapter-pg";
import pino from "pino";
import { readConfig } from "../../../packages/config/src";
import { createBot } from "./handler";
import { processNext } from "./queue";
const config = readConfig();
const log = pino({ base: { service: "slideway-bot" } });
async function main() {
  if (config.BOT_ENABLED !== "true") throw new Error("Bot disabled");
  const db = new PrismaClient({
    adapter: new PrismaPg({ connectionString: config.DATABASE_URL, max: 4 }),
  });
  const bot = createBot(
    db,
    config.TELEGRAM_BOT_TOKEN,
    config.TELEGRAM_BOT_USERNAME!,
    config.MINIAPP_URL!,
    config.ADMIN_OWNER_TELEGRAM_ID,
  );
  let stopping = false;
  process.on("SIGTERM", () => {
    stopping = true;
  });
  process.on("SIGINT", () => {
    stopping = true;
  });
  await bot.init();
  if (
    bot.botInfo.username.toLowerCase() !==
    config.TELEGRAM_BOT_USERNAME!.toLowerCase()
  )
    throw new Error("Bot identity mismatch");
  await db.$connect();
  log.info("Worker ready");
  try {
    while (!stopping) {
      try {
        if (!(await processNext(db, (u) => bot.handleUpdate(u))))
          await new Promise((r) => setTimeout(r, 500));
      } catch {
        log.error("Worker iteration failed");
        await new Promise((r) => setTimeout(r, 1000));
      }
    }
  } finally {
    await db.$disconnect();
  }
}
main().catch(() => {
  log.error("Bot startup failed; check configuration");
  process.exitCode = 1;
});
