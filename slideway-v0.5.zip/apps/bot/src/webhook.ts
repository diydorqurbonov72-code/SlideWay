import { timingSafeEqual } from "node:crypto";
import { z } from "zod";
export function validWebhookSecret(
  received: unknown,
  expected: string | undefined,
): boolean {
  if (typeof received !== "string" || !expected) return false;
  const a = Buffer.from(received),
    b = Buffer.from(expected);
  return a.length === b.length && timingSafeEqual(a, b);
}
// Persist only the fields needed for supported private commands, not arbitrary updates.
export const incomingUpdate = z.object({
  update_id: z.number().int().nonnegative().max(Number.MAX_SAFE_INTEGER),
  message: z
    .object({
      message_id: z.number().int(),
      date: z.number().int().nonnegative(),
      chat: z.object({
        id: z.number().int().positive().max(Number.MAX_SAFE_INTEGER),
        type: z.literal("private"),
      }),
      from: z.object({
        id: z.number().int().positive().max(Number.MAX_SAFE_INTEGER),
        is_bot: z.literal(false),
        first_name: z.string().min(1).max(256),
        last_name: z.string().max(256).optional(),
        username: z.string().max(64).optional(),
        language_code: z.string().max(16).optional(),
      }),
      text: z.string().max(4096),
    })
    .optional(),
});
export const envelope = z.object({
  update_id: z.number().int().nonnegative().max(Number.MAX_SAFE_INTEGER),
});
