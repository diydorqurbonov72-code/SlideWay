import "dotenv/config";
import { Bot } from "grammy";
import { readConfig } from "../../../packages/config/src";
import { commands } from "./handler";
async function main() {
  const c = readConfig();
  if (
    c.BOT_ENABLED !== "true" ||
    !c.WEBHOOK_URL ||
    new URL(c.WEBHOOK_URL).protocol !== "https:" ||
    new URL(c.WEBHOOK_URL).pathname !== "/api/v1/telegram/webhook"
  )
    throw new Error("Set HTTPS WEBHOOK_URL ending /api/v1/telegram/webhook");
  const bot = new Bot(c.TELEGRAM_BOT_TOKEN);
  const me = await bot.api.getMe();
  if (me.username?.toLowerCase() !== c.TELEGRAM_BOT_USERNAME?.toLowerCase())
    throw new Error("Bot username does not match token");
  await bot.api.setMyCommands(commands, {
    scope: { type: "all_private_chats" },
  });
  await bot.api.setChatMenuButton({
    menu_button: {
      type: "web_app",
      text: "SlideWay",
      web_app: { url: c.MINIAPP_URL! },
    },
  });
  await bot.api.setWebhook(c.WEBHOOK_URL, {
    secret_token: c.TELEGRAM_WEBHOOK_SECRET,
    allowed_updates: ["message"],
    drop_pending_updates: false,
    max_connections: 20,
  });
  console.log("Webhook, commands and menu registered.");
}
main().catch(() => {
  console.error(
    "Registration failed. Check bot configuration and Telegram connectivity.",
  );
  process.exitCode = 1;
});
