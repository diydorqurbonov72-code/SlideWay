import { randomUUID } from "node:crypto";
import { Prisma, PrismaClient, TelegramUpdate } from "@prisma/client";
import { BotError, GrammyError } from "grammy";
import type { Update } from "grammy/types";
export async function processNext(
  db: PrismaClient,
  handle: (u: Update) => Promise<void>,
  now = new Date(),
) {
  const claimId = randomUUID();
  const rows = await db.$queryRaw<
    TelegramUpdate[]
  >`UPDATE "TelegramUpdate" SET "status"='processing', "claimId"=${claimId}::uuid, "lockedUntil"=${new Date(now.getTime() + 60000)}, "attempts"="attempts"+1 WHERE "id"=(SELECT "id" FROM "TelegramUpdate" WHERE (("status"='pending' AND "availableAt"<=${now}) OR ("status"='processing' AND "lockedUntil"<${now})) ORDER BY "id" FOR UPDATE SKIP LOCKED LIMIT 1) RETURNING *`;
  const row = rows[0];
  if (!row) return false;
  try {
    if (row.attempts > 5 || now.getTime() - row.createdAt.getTime() > 86400000)
      throw new Error("expired");
    await handle(row.payload as unknown as Update);
    await db.telegramUpdate.updateMany({
      where: { id: row.id, claimId },
      data: {
        status: "done",
        finishedAt: new Date(),
        payload: Prisma.JsonNull,
        claimId: null,
        lockedUntil: null,
      },
    });
  } catch (error) {
    const e = error instanceof BotError ? error.error : error;
    const terminal =
      (e instanceof GrammyError && [400, 403].includes(e.error_code)) ||
      row.attempts >= 5 ||
      now.getTime() - row.createdAt.getTime() > 86400000;
    const retrySeconds =
      e instanceof GrammyError && e.error_code === 429
        ? Math.max(1, e.parameters.retry_after ?? 60)
        : Math.min(300, 2 ** row.attempts);
    await db.telegramUpdate.updateMany({
      where: { id: row.id, claimId },
      data: {
        status: terminal ? "failed" : "pending",
        finishedAt: terminal ? new Date() : null,
        availableAt: new Date(Date.now() + retrySeconds * 1000),
        lockedUntil: null,
        claimId: null,
        ...(terminal ? { payload: Prisma.JsonNull } : {}),
      },
    });
  }
  return true;
}
