import {
  Body,
  Controller,
  Delete,
  Get,
  HttpCode,
  Param,
  Patch,
  Post,
  Req,
  UseGuards,
  BadRequestException,
  ServiceUnavailableException,
  UnauthorizedException,
  ForbiddenException,
} from "@nestjs/common";
import { z } from "zod";
import { AuthService } from "./auth.service";
import { Cache, Database, config } from "./resources";
import { AuthRequest, SessionGuard } from "./guards";
import { authBody, profilePatch } from "../../../packages/shared/src";
function parse<T>(schema: z.ZodType<T>, body: unknown): T {
  const r = schema.safeParse(body);
  if (!r.success) throw new BadRequestException("Invalid request body");
  return r.data;
}
const profileSelect = {
  id: true,
  displayName: true,
  bio: true,
  locale: true,
  createdAt: true,
  settings: {
    select: {
      profileVisible: true,
      showActivity: true,
      showAchievements: true,
      allowFriendRequests: true,
      notifications: true,
    },
  },
  interests: { select: { interestKey: true } },
} as const;
@Controller("auth")
export class AuthController {
  constructor(private readonly auth: AuthService) {}
  @Post("telegram") @HttpCode(200) login(@Body() body: unknown) {
    return this.auth.login(parse(authBody, body).initData);
  }
}
@Controller("me")
@UseGuards(SessionGuard)
export class MeController {
  constructor(private readonly db: Database) {}
  @Get() async me(@Req() req: AuthRequest) {
    const user = await this.db.user.findUnique({
      where: { id: req.session.userId },
      select: profileSelect,
    });
    if (!user) throw new UnauthorizedException();
    return user;
  }
  @Patch() async update(@Req() req: AuthRequest, @Body() body: unknown) {
    const { settings, interests, ...profile } = parse(profilePatch, body);
    if (
      interests &&
      (await this.db.interest.count({ where: { key: { in: interests } } })) !==
        interests.length
    )
      throw new BadRequestException("Unknown interest");
    return this.db.user.update({
      where: { id: req.session.userId },
      data: {
        ...profile,
        ...(settings ? { settings: { update: settings } } : {}),
        ...(interests
          ? {
              interests: {
                deleteMany: {},
                create: interests.map((interestKey) => ({ interestKey })),
              },
            }
          : {}),
      },
      select: profileSelect,
    });
  }
  @Get("sessions") async sessions(@Req() req: AuthRequest) {
    const sessions = await this.db.userSession.findMany({
      where: { userId: req.session.userId, expiresAt: { gt: new Date() } },
      select: { id: true, createdAt: true, expiresAt: true },
      orderBy: { createdAt: "desc" },
      take: 100,
    });
    return sessions.map((s) => ({ ...s, current: s.id === req.session.id }));
  }
  @Delete("sessions/:id") @HttpCode(204) async revoke(
    @Req() req: AuthRequest,
    @Param("id") id: string,
  ) {
    parse(z.string().uuid(), id);
    await this.db.userSession.deleteMany({
      where: { id, userId: req.session.userId },
    });
  }
  @Delete("sessions") @HttpCode(204) async revokeAll(@Req() req: AuthRequest) {
    await this.db.userSession.deleteMany({
      where: { userId: req.session.userId },
    });
  }
  @Delete() @HttpCode(204) async remove(
    @Req() req: AuthRequest,
    @Body() body: unknown,
  ) {
    parse(z.object({ confirmation: z.literal("DELETE") }).strict(), body);
    if (Date.now() - req.session.createdAt.getTime() > 300000)
      throw new UnauthorizedException("Reauthenticate before deleting account");
    const user = await this.db.user.findUnique({
      where: { id: req.session.userId },
      select: { telegramId: true },
    });
    if (user?.telegramId.toString() === config.ADMIN_OWNER_TELEGRAM_ID)
      throw new ForbiddenException(
        "Transfer ownership in server configuration before deleting owner account",
      );
    await this.db.user.deleteMany({ where: { id: req.session.userId } });
  }
}
@Controller("interests")
@UseGuards(SessionGuard)
export class InterestsController {
  constructor(private readonly db: Database) {}
  @Get() list() {
    return this.db.interest.findMany({ orderBy: { key: "asc" }, take: 100 });
  }
}
@Controller("health")
export class HealthController {
  constructor(
    private readonly db: Database,
    private readonly cache: Cache,
  ) {}
  @Get("live") live() {
    return { status: "ok" };
  }
  @Get("ready") async ready() {
    try {
      await this.db.$queryRaw`SELECT 1`;
      await this.cache.client.ping();
      return { status: "ready" };
    } catch {
      throw new ServiceUnavailableException("Dependencies unavailable");
    }
  }
}
