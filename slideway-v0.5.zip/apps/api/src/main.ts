import "dotenv/config";
import "reflect-metadata";
import { randomUUID } from "node:crypto";
import { NestFactory } from "@nestjs/core";
import {
  ArgumentsHost,
  Catch,
  ExceptionFilter,
  HttpException,
} from "@nestjs/common";
import { json, Request, Response } from "express";
import helmet from "helmet";
import pino from "pino";
import { AppModule } from "./app";
import { config, Database, Cache } from "./resources";
const log = pino({ base: { service: "slideway-api" } });
@Catch()
class Errors implements ExceptionFilter {
  catch(e: unknown, host: ArgumentsHost) {
    const res = host.switchToHttp().getResponse<Response>();
    const status =
      e instanceof HttpException
        ? e.getStatus()
        : e &&
            typeof e === "object" &&
            "type" in e &&
            e.type === "entity.parse.failed"
          ? 400
          : e &&
              typeof e === "object" &&
              "type" in e &&
              e.type === "entity.too.large"
            ? 413
            : 500;
    if (status >= 500)
      log.error(
        { requestId: res.getHeader("X-Request-ID"), status },
        "Request failed",
      );
    res.status(status).json({
      statusCode: status,
      message:
        status >= 500
          ? "Service unavailable"
          : e instanceof HttpException
            ? e.message
            : "Error",
      requestId: res.getHeader("X-Request-ID"),
    });
  }
}
async function main() {
  const app = await NestFactory.create(AppModule, {
    bodyParser: false,
    logger: ["error", "warn", "log"],
  });
  app.use(helmet());
  app.use((req: Request, res: Response, next: () => void) => {
    const start = Date.now();
    res.setHeader("X-Request-ID", randomUUID());
    res.setHeader("Cache-Control", "no-store");
    res.on("finish", () =>
      log.info(
        {
          requestId: res.getHeader("X-Request-ID"),
          method: req.method,
          status: res.statusCode,
          durationMs: Date.now() - start,
        },
        "Request",
      ),
    );
    next();
  });
  app.use(json({ limit: "12kb", strict: true }));
  app.enableCors({
    origin: config.origins,
    methods: ["GET", "POST", "PATCH", "DELETE"],
    allowedHeaders: ["Content-Type", "Authorization"],
  });
  // Only trust the immediate reverse proxy; production Compose exposes no API port.
  if (config.NODE_ENV === "production")
    app.getHttpAdapter().getInstance().set("trust proxy", 1);
  app.setGlobalPrefix("api/v1");
  app.useGlobalFilters(new Errors());
  app.enableShutdownHooks();
  await app.get(Database).$connect();
  // Redis readiness is reflected by /health/ready; requests fail closed during outage.
  const cleanup = setInterval(() => {
    app
      .get(Database)
      .$transaction([
        app
          .get(Database)
          .authReplay.deleteMany({ where: { expiresAt: { lt: new Date() } } }),
        app
          .get(Database)
          .userSession.deleteMany({ where: { expiresAt: { lt: new Date() } } }),
      ])
      .catch(() => log.error("Session cleanup failed"));
  }, 60000);
  cleanup.unref();
  await app.listen(config.PORT, "0.0.0.0");
}
main().catch(() => {
  log.fatal("API startup failed; verify configuration and dependencies");
  process.exitCode = 1;
});
