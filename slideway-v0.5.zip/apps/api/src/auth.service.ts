import { restricted } from "../../../packages/security/src/admin";
import {
  Injectable,
  ForbiddenException,
  UnauthorizedException,
  ConflictException,
  BadRequestException,
} from "@nestjs/common";
import { Prisma } from "@prisma/client";
import { Database, config } from "./resources";
import {
  digest,
  newSessionToken,
  verifyTelegram,
} from "../../../packages/security/src/telegram";
@Injectable()
export class AuthService {
  constructor(private readonly db: Database) {}
  async login(raw: string) {
    let verified: ReturnType<typeof verifyTelegram>;
    try {
      verified = verifyTelegram(
        raw,
        config.TELEGRAM_BOT_TOKEN,
        config.AUTH_MAX_AGE_SECONDS,
      );
    } catch {
      throw new UnauthorizedException("Invalid Telegram authentication");
    }
    const token = newSessionToken();
    const expiresAt = new Date(Date.now() + config.SESSION_TTL_SECONDS * 1000);
    try {
      await this.db.$transaction(async (tx) => {
        // The unique constraint claims the signed payload atomically with the session.
        await tx.authReplay.create({
          data: { hash: verified.replayHash, expiresAt: verified.expiresAt },
        });
        const u = verified.user;
        const user = await tx.user.upsert({
          where: { telegramId: BigInt(u.id) },
          create: {
            telegramId: BigInt(u.id),
            displayName: [u.first_name, u.last_name]
              .filter(Boolean)
              .join(" ")
              .slice(0, 80),
            username: u.username,
            locale: ["ru", "en", "uz"].includes(u.language_code || "")
              ? u.language_code
              : "en",
            settings: { create: {} },
          },
          update: { username: u.username ?? null },
        });
        if (restricted(user))
          throw new ForbiddenException("Account restricted");
        await tx.userSession.create({
          data: { userId: user.id, tokenHash: digest(token), expiresAt },
        });
      });
    } catch (e) {
      if (
        e instanceof Prisma.PrismaClientKnownRequestError &&
        e.code === "P2002"
      )
        throw new ConflictException(
          "Authentication already used; reopen Mini App",
        );
      throw e;
    }
    return { accessToken: token, tokenType: "Bearer", expiresAt };
  }
  async authenticate(header?: string) {
    if (!header || !/^Bearer [A-Za-z0-9_-]{43}$/.test(header))
      throw new UnauthorizedException();
    const session = await this.db.userSession.findUnique({
      where: { tokenHash: digest(header.slice(7)) },
      include: { user: { select: { banned: true, banUntil: true } } },
    });
    if (!session || session.expiresAt <= new Date())
      throw new UnauthorizedException();
    if (restricted(session.user))
      throw new ForbiddenException("Account restricted");
    const { user, ...safeSession } = session;
    return safeSession;
  }
}
