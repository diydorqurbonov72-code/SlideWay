import {
  Controller,
  Delete,
  Get,
  HttpCode,
  Param,
  Post,
  Req,
  UseGuards,
  BadRequestException,
} from "@nestjs/common";
import { z } from "zod";
import { AuthRequest, SessionGuard } from "./guards";
import { NotificationsService } from "./notifications.service";

function id(value: string) {
  const result = z.string().uuid().safeParse(value);
  if (!result.success) throw new BadRequestException("Invalid notification");
  return result.data;
}

@Controller("notifications")
@UseGuards(SessionGuard)
export class NotificationsController {
  constructor(private readonly notifications: NotificationsService) {}

  @Get()
  list(@Req() request: AuthRequest) {
    return this.notifications.list(request.session.userId);
  }

  @Post("read-all")
  @HttpCode(200)
  markAll(@Req() request: AuthRequest) {
    return this.notifications.markAll(request.session.userId);
  }

  @Post(":id/read")
  @HttpCode(200)
  mark(@Req() request: AuthRequest, @Param("id") notificationId: string) {
    return this.notifications.mark(request.session.userId, id(notificationId));
  }

  @Delete(":id")
  remove(@Req() request: AuthRequest, @Param("id") notificationId: string) {
    return this.notifications.remove(
      request.session.userId,
      id(notificationId),
    );
  }
}
