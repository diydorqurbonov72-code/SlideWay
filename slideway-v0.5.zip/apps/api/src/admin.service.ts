import {
  Injectable,
  ForbiddenException,
  UnauthorizedException,
  NotFoundException,
  ConflictException,
} from "@nestjs/common";
import { Prisma } from "@prisma/client";
import { Database, config } from "./resources";
import {
  effectiveRole,
  permissions,
  restricted,
  Permission,
} from "../../../packages/security/src/admin";
import { digest } from "../../../packages/security/src/telegram";
import { AuthRequest } from "./guards";
export type Action = "ban" | "unban" | "revoke-sessions" | "role";
export type Command = {
  operationId: string;
  reason: string;
  durationHours?: number;
  role?: "ADMINISTRATOR" | "MODERATOR" | "SUPPORT" | "ANALYST" | "NONE";
};
const userSelect = {
  id: true,
  displayName: true,
  username: true,
  createdAt: true,
  locale: true,
  banned: true,
  banReason: true,
  banUntil: true,
  telegramId: true,
  adminUser: { select: { role: true } },
} as const;
@Injectable()
export class AdminService {
  constructor(private readonly db: Database) {}
  async identity(
    userId: string,
    permission?: Permission,
    tx: Prisma.TransactionClient = this.db,
  ) {
    const user = await tx.user.findUnique({
      where: { id: userId },
      include: { adminUser: true },
    });
    if (!user || restricted(user)) throw new ForbiddenException();
    const role = effectiveRole(user, config.ADMIN_OWNER_TELEGRAM_ID);
    if (!role || (permission && !permissions[role].includes(permission)))
      throw new ForbiddenException("Insufficient permissions");
    return {
      id: user.id,
      displayName: user.displayName,
      role,
      permissions: permissions[role],
    };
  }
  async dashboard(userId: string) {
    await this.identity(userId, "dashboard:read");
    const now = new Date(),
      since = new Date(Date.now() - 86400000);
    const [
      users,
      newUsers,
      activeSessions,
      restrictedUsers,
      queuePending,
      queueFailed,
      queueDone,
      registrations,
    ] = await this.db.$transaction([
      this.db.user.count(),
      this.db.user.count({ where: { createdAt: { gte: since } } }),
      this.db.userSession.count({ where: { expiresAt: { gt: now } } }),
      this.db.user.count({
        where: {
          banned: true,
          OR: [{ banUntil: null }, { banUntil: { gt: now } }],
        },
      }),
      this.db.telegramUpdate.count({
        where: { status: { in: ["pending", "processing"] } },
      }),
      this.db.telegramUpdate.count({ where: { status: "failed" } }),
      this.db.telegramUpdate.count({ where: { status: "done" } }),
      this.db.$queryRaw<
        { day: Date; count: bigint }[]
      >`SELECT date_trunc('day', "createdAt" AT TIME ZONE 'UTC') AS day, count(*) AS count FROM "User" WHERE "createdAt">=date_trunc('day',NOW() AT TIME ZONE 'UTC')-INTERVAL '6 days' GROUP BY 1 ORDER BY 1`,
    ]);
    const days = Array.from({ length: 7 }, (_, i) => {
      const date = new Date(now);
      date.setUTCHours(0, 0, 0, 0);
      date.setUTCDate(date.getUTCDate() - 6 + i);
      const key = date.toISOString().slice(0, 10);
      return {
        date: key,
        count: Number(
          registrations.find((r) => r.day.toISOString().slice(0, 10) === key)
            ?.count ?? 0,
        ),
      };
    });
    return {
      users,
      newUsers,
      activeSessions,
      restrictedUsers,
      queue: { pending: queuePending, failed: queueFailed, done: queueDone },
      registrations: days,
      generatedAt: now,
    };
  }
  async users(actorId: string, q: string, cursor?: string) {
    const actor = await this.identity(actorId, "users:read");
    const where: Prisma.UserWhereInput = q
      ? {
          OR: [
            { displayName: { contains: q, mode: "insensitive" } },
            { username: { contains: q, mode: "insensitive" } },
            ...(/^\d{1,16}$/.test(q) && actor.role === "OWNER"
              ? [{ telegramId: BigInt(q) }]
              : []),
          ],
        }
      : {};
    const rows = await this.db.user.findMany({
      where,
      select: userSelect,
      orderBy: { id: "asc" },
      take: 26,
      ...(cursor ? { cursor: { id: cursor }, skip: 1 } : {}),
    });
    return {
      items: rows
        .slice(0, 25)
        .map((u) => ({
          id: u.id,
          displayName: u.displayName,
          username: u.username,
          createdAt: u.createdAt,
          locale: u.locale,
          restricted: restricted(u),
          banReason: u.banReason,
          banUntil: u.banUntil,
          role: effectiveRole(u, config.ADMIN_OWNER_TELEGRAM_ID),
          ...(actor.role === "OWNER"
            ? { telegramId: u.telegramId.toString() }
            : {}),
        })),
      nextCursor: rows.length > 25 ? rows[24].id : null,
    };
  }
  async audit(userId: string, cursor?: string) {
    await this.identity(userId, "audit:read");
    const rows = await this.db.auditLog.findMany({
      select: {
        id: true,
        action: true,
        details: true,
        createdAt: true,
        actor: { select: { displayName: true } },
        target: { select: { displayName: true } },
      },
      orderBy: [{ createdAt: "desc" }, { id: "desc" }],
      take: 26,
      ...(cursor ? { cursor: { id: cursor }, skip: 1 } : {}),
    });
    return {
      items: rows.slice(0, 25),
      nextCursor: rows.length > 25 ? rows[24].id : null,
    };
  }
  async mutate(
    req: AuthRequest,
    targetId: string,
    action: Action,
    command: Command,
  ) {
    const permission: Permission =
      action === "role"
        ? "roles:write"
        : action === "revoke-sessions"
          ? "sessions:revoke"
          : "users:moderate";
    const hash = digest(JSON.stringify({ targetId, action, ...command }));
    try {
      return await this.db.$transaction(
        async (tx) => {
          const session = await tx.userSession.findUnique({
            where: { id: req.session.id },
          });
          if (
            !session ||
            session.expiresAt <= new Date() ||
            Date.now() - session.createdAt.getTime() > 600000
          )
            throw new UnauthorizedException(
              "Reopen admin panel before sensitive actions",
            );
          const actor = await this.identity(req.session.userId, permission, tx);
          const previous = await tx.auditLog.findUnique({
            where: { operationId: command.operationId },
          });
          if (previous) {
            if (
              previous.actorId !== actor.id ||
              previous.operationHash !== hash
            )
              throw new ConflictException("Operation ID already used");
            return { ok: true };
          }
          const target = await tx.user.findUnique({
            where: { id: targetId },
            include: { adminUser: true },
          });
          if (!target) throw new NotFoundException();
          const targetRole = effectiveRole(
            target,
            config.ADMIN_OWNER_TELEGRAM_ID,
          );
          if (
            targetId === actor.id ||
            targetRole === "OWNER" ||
            (actor.role !== "OWNER" && targetRole)
          )
            throw new ForbiddenException("Protected account");
          if (action === "ban") {
            await tx.user.update({
              where: { id: targetId },
              data: {
                banned: true,
                banReason: command.reason,
                banUntil: command.durationHours
                  ? new Date(Date.now() + command.durationHours * 3600000)
                  : null,
              },
            });
            await tx.userSession.deleteMany({ where: { userId: targetId } });
          } else if (action === "unban")
            await tx.user.update({
              where: { id: targetId },
              data: { banned: false, banReason: null, banUntil: null },
            });
          else if (action === "revoke-sessions")
            await tx.userSession.deleteMany({ where: { userId: targetId } });
          else {
            if (command.role === "NONE")
              await tx.adminUser.deleteMany({ where: { userId: targetId } });
            else
              await tx.adminUser.upsert({
                where: { userId: targetId },
                create: {
                  userId: targetId,
                  role: command.role! as Exclude<
                    Command["role"],
                    "NONE" | undefined
                  >,
                },
                update: {
                  role: command.role! as Exclude<
                    Command["role"],
                    "NONE" | undefined
                  >,
                },
              });
            await tx.userSession.deleteMany({ where: { userId: targetId } });
          }
          await tx.auditLog.create({
            data: {
              operationId: command.operationId,
              operationHash: hash,
              actorId: actor.id,
              targetId,
              action,
              details: {
                reason: command.reason,
                ...(command.role ? { role: command.role } : {}),
                ...(command.durationHours
                  ? { durationHours: command.durationHours }
                  : {}),
              },
            },
          });
          return { ok: true };
        },
        { isolationLevel: Prisma.TransactionIsolationLevel.Serializable },
      );
    } catch (e) {
      if (
        e instanceof Prisma.PrismaClientKnownRequestError &&
        ["P2034", "P2002"].includes(e.code)
      )
        throw new ConflictException(
          "Concurrent update; retry with the same operation ID",
        );
      throw e;
    }
  }
}
