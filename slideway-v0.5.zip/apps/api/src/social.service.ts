import {
  Injectable,
  BadRequestException,
  ForbiddenException,
  NotFoundException,
  ConflictException,
} from "@nestjs/common";
import { Prisma } from "@prisma/client";
import { Database } from "./resources";
import { restricted } from "../../../packages/security/src/admin";
const publicSelect = { id: true, displayName: true, bio: true } as const;
@Injectable()
export class SocialService {
  constructor(private readonly db: Database) {}
  private pair(a: string, b: string) {
    if (a === b) throw new BadRequestException("Cannot target yourself");
    return [a, b].sort() as [string, string];
  }
  private async serial<T>(fn: (tx: Prisma.TransactionClient) => Promise<T>) {
    try {
      return await this.db.$transaction(fn, {
        isolationLevel: Prisma.TransactionIsolationLevel.Serializable,
      });
    } catch (e) {
      if (
        e instanceof Prisma.PrismaClientKnownRequestError &&
        ["P2034", "P2002"].includes(e.code)
      )
        throw new ConflictException("Concurrent change; refresh and retry");
      throw e;
    }
  }
  private async allowed(tx: Prisma.TransactionClient, a: string, b: string) {
    const users = await tx.user.findMany({
      where: { id: { in: [a, b] } },
      include: { settings: true },
    });
    if (
      users.length !== 2 ||
      users.some((restrictedUser) => restricted(restrictedUser))
    )
      throw new NotFoundException();
    if (
      await tx.userBlock.count({
        where: {
          OR: [
            { actorId: a, targetId: b },
            { actorId: b, targetId: a },
          ],
        },
      })
    )
      throw new ForbiddenException("Contact unavailable");
    return users;
  }
  async search(actor: string, q: string) {
    return this.db.user.findMany({
      where: {
        id: { not: actor },
        settings: { profileVisible: true },
        AND: [
          { OR: [{ banned: false }, { banUntil: { lte: new Date() } }] },
          {
            OR: [
              { displayName: { contains: q, mode: "insensitive" } },
              { username: { contains: q, mode: "insensitive" } },
            ],
          },
        ],
        blocks: { none: { targetId: actor } },
        blockedBy: { none: { actorId: actor } },
      },
      select: {
        ...publicSelect,
        settings: { select: { allowFriendRequests: true } },
      },
      take: 25,
      orderBy: { id: "asc" },
    });
  }
  async list(actor: string) {
    const rows = await this.db.friendship.findMany({
      where: { OR: [{ firstId: actor }, { secondId: actor }] },
      include: {
        first: { select: publicSelect },
        second: { select: publicSelect },
      },
      orderBy: { updatedAt: "desc" },
      take: 100,
    });
    type Item = {
      id: string;
      user: { id: string; displayName: string; bio: string | null };
    };
    const friends: Item[] = [],
      incoming: Item[] = [],
      outgoing: Item[] = [];
    for (const row of rows) {
      const other = row.firstId === actor ? row.second : row.first;
      const item = { id: row.id, user: other };
      if (row.status === "ACCEPTED") friends.push(item);
      else {
        const sender = row.requestedByFirst ? row.firstId : row.secondId;
        (sender === actor ? outgoing : incoming).push(item);
      }
    }
    const blocked = await this.db.userBlock.findMany({
      where: { actorId: actor },
      select: { target: { select: { id: true, displayName: true } } },
      orderBy: { createdAt: "desc" },
      take: 100,
    });
    return {
      friends,
      incoming,
      outgoing,
      blocked: blocked.map((x) => x.target),
    };
  }
  async request(actor: string, target: string) {
    const [firstId, secondId] = this.pair(actor, target);
    return this.serial(async (tx) => {
      const users = await this.allowed(tx, actor, target);
      const recipient = users.find((u) => u.id === target)!;
      if (
        !recipient.settings?.profileVisible ||
        !recipient.settings.allowFriendRequests
      )
        throw new ForbiddenException("Requests are disabled");
      const existing = await tx.friendship.findUnique({
        where: { firstId_secondId: { firstId, secondId } },
      });
      if (existing) return { id: existing.id };
      const row = await tx.friendship.create({
        data: { firstId, secondId, requestedByFirst: actor === firstId },
      });
      await tx.notification.create({
        data: {
          userId: target,
          actorId: actor,
          type: "FRIEND_REQUEST",
          entityId: row.id,
        },
      });
      return { id: row.id };
    });
  }
  async accept(actor: string, id: string) {
    return this.serial(async (tx) => {
      const row = await tx.friendship.findUnique({ where: { id } });
      if (!row) throw new NotFoundException();
      const sender = row.requestedByFirst ? row.firstId : row.secondId;
      const recipient = row.requestedByFirst ? row.secondId : row.firstId;
      if (actor !== recipient) throw new ForbiddenException();
      await this.allowed(tx, sender, recipient);
      await tx.friendship.update({
        where: { id },
        data: { status: "ACCEPTED" },
      });
      await tx.notification.deleteMany({
        where: { userId: recipient, type: "FRIEND_REQUEST", entityId: id },
      });
      await tx.notification.upsert({
        where: {
          userId_type_entityId: {
            userId: sender,
            type: "FRIEND_ACCEPTED",
            entityId: id,
          },
        },
        create: {
          userId: sender,
          actorId: recipient,
          type: "FRIEND_ACCEPTED",
          entityId: id,
        },
        update: {},
      });
      return { ok: true };
    });
  }
  async remove(actor: string, id: string) {
    return this.serial(async (tx) => {
      const row = await tx.friendship.findFirst({
        where: { id, OR: [{ firstId: actor }, { secondId: actor }] },
        select: { id: true },
      });
      if (row) {
        await tx.notification.deleteMany({ where: { entityId: row.id } });
        await tx.friendship.delete({ where: { id: row.id } });
      }
      return { ok: true };
    });
  }
  async block(actor: string, target: string) {
    const [firstId, secondId] = this.pair(actor, target);
    return this.serial(async (tx) => {
      if (
        !(await tx.user.findUnique({
          where: { id: target },
          select: { id: true },
        }))
      )
        throw new NotFoundException();
      await tx.userBlock.upsert({
        where: { actorId_targetId: { actorId: actor, targetId: target } },
        create: { actorId: actor, targetId: target },
        update: {},
      });
      const relationship = await tx.friendship.findUnique({
        where: { firstId_secondId: { firstId, secondId } },
        select: { id: true },
      });
      if (relationship) {
        await tx.notification.deleteMany({
          where: { entityId: relationship.id },
        });
        await tx.friendship.delete({ where: { id: relationship.id } });
      }
      return { ok: true };
    });
  }
  async unblock(actor: string, target: string) {
    await this.db.userBlock.deleteMany({
      where: { actorId: actor, targetId: target },
    });
    return { ok: true };
  }
}
