import { Injectable } from "@nestjs/common";
import { Database } from "./resources";

@Injectable()
export class NotificationsService {
  constructor(private readonly db: Database) {}

  async list(userId: string) {
    const [items, unread] = await this.db.$transaction([
      this.db.notification.findMany({
        where: { userId },
        select: {
          id: true,
          type: true,
          entityId: true,
          readAt: true,
          createdAt: true,
          actor: { select: { id: true, displayName: true } },
        },
        orderBy: [{ createdAt: "desc" }, { id: "desc" }],
        take: 50,
      }),
      this.db.notification.count({ where: { userId, readAt: null } }),
    ]);
    return { unread, items };
  }

  async markAll(userId: string) {
    await this.db.notification.updateMany({
      where: { userId, readAt: null },
      data: { readAt: new Date() },
    });
    return { ok: true };
  }

  async mark(userId: string, id: string) {
    await this.db.notification.updateMany({
      where: { id, userId, readAt: null },
      data: { readAt: new Date() },
    });
    return { ok: true };
  }

  async remove(userId: string, id: string) {
    await this.db.notification.deleteMany({ where: { id, userId } });
    return { ok: true };
  }
}
