import {
  Body,
  Controller,
  Headers,
  HttpCode,
  Post,
  UnauthorizedException,
  ServiceUnavailableException,
  BadRequestException,
  HttpException,
} from "@nestjs/common";
import { Prisma } from "@prisma/client";
import { Cache, Database, config } from "./resources";
import {
  envelope,
  incomingUpdate,
  validWebhookSecret,
} from "../../bot/src/webhook";
import { digest } from "../../../packages/security/src/telegram";
@Controller("telegram")
export class TelegramController {
  constructor(
    private readonly db: Database,
    private readonly cache: Cache,
  ) {}
  @Post("webhook") @HttpCode(200) async receive(
    @Headers("x-telegram-bot-api-secret-token") secret: unknown,
    @Body() body: unknown,
  ) {
    if (config.BOT_ENABLED !== "true")
      throw new ServiceUnavailableException("Bot disabled");
    if (!validWebhookSecret(secret, config.TELEGRAM_WEBHOOK_SECRET))
      throw new UnauthorizedException();
    if (!envelope.safeParse(body).success)
      throw new BadRequestException("Invalid update");
    const parsed = incomingUpdate.safeParse(body);
    // Acknowledge unsupported updates (groups/media) so Telegram does not retry them.
    if (!parsed.success || !parsed.data.message) return { ok: true };
    const { message, update_id } = parsed.data;
    if (
      message.from.id !== message.chat.id ||
      !/^\/(start|help|profile|settings|privacy|admin|stats)(?:@\w+)?(?:\s|$)/i.test(
        message.text,
      )
    )
      return { ok: true };
    if (
      await this.db.telegramUpdate.findUnique({
        where: { id: BigInt(update_id) },
        select: { id: true },
      })
    )
      return { ok: true };
    let count: number;
    try {
      count = Number(
        await this.cache.client.eval(
          "local n=redis.call('INCR',KEYS[1]); if n==1 then redis.call('EXPIRE',KEYS[1],60) end; return n",
          1,
          "bot:rate:" + digest(String(message.from.id)),
        ),
      );
    } catch {
      throw new ServiceUnavailableException();
    }
    if (count > 30) throw new HttpException("Too many commands", 429);
    try {
      await this.db.telegramUpdate.create({
        data: {
          id: BigInt(update_id),
          payload: parsed.data as unknown as Prisma.InputJsonValue,
        },
      });
    } catch (e) {
      if (!(
        e instanceof Prisma.PrismaClientKnownRequestError && e.code === "P2002"
      ))
        throw e;
    }
    return { ok: true };
  }
}
