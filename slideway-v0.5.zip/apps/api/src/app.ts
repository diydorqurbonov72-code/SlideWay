import { SocialController } from "./social.controller";
import { SocialService } from "./social.service";
import { NotificationsController } from "./notifications.controller";
import { NotificationsService } from "./notifications.service";
import { AdminController } from "./admin.controller";
import { AdminService } from "./admin.service";
import "reflect-metadata";
import { Module } from "@nestjs/common";
import { TelegramController } from "./telegram.controller";
import { APP_GUARD } from "@nestjs/core";
import {
  AuthController,
  MeController,
  HealthController,
  InterestsController,
} from "./controllers";
import { AuthService } from "./auth.service";
import { Database, Cache } from "./resources";
import { SessionGuard, RateGuard } from "./guards";
@Module({
  controllers: [
    NotificationsController,
    SocialController,
    AdminController,
    TelegramController,
    AuthController,
    MeController,
    HealthController,
    InterestsController,
  ],
  providers: [
    NotificationsService,
    SocialService,
    AdminService,
    Database,
    Cache,
    AuthService,
    SessionGuard,
    { provide: APP_GUARD, useClass: RateGuard },
  ],
})
export class AppModule {}
