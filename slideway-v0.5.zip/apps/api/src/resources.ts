import { Injectable, OnModuleDestroy } from "@nestjs/common";
import { PrismaClient } from "@prisma/client";
import { PrismaPg } from "@prisma/adapter-pg";
import Redis from "ioredis";
import { readConfig } from "../../../packages/config/src";
export const config = readConfig();
@Injectable()
export class Database extends PrismaClient implements OnModuleDestroy {
  constructor() {
    super({
      adapter: new PrismaPg({
        connectionString: config.DATABASE_URL,
        max: 10,
        connectionTimeoutMillis: 5000,
      }),
    });
  }
  async onModuleDestroy() {
    await this.$disconnect();
  }
}
@Injectable()
export class Cache implements OnModuleDestroy {
  readonly client = new Redis(config.REDIS_URL, {
    maxRetriesPerRequest: 1,
    connectTimeout: 5000,
    enableOfflineQueue: false,
  });
  constructor() {
    this.client.on("error", () => {});
  }
  async onModuleDestroy() {
    this.client.disconnect();
  }
}
