import {
  Controller,
  Get,
  Post,
  Delete,
  Param,
  Query,
  Req,
  Body,
  UseGuards,
  BadRequestException,
  HttpException,
  ServiceUnavailableException,
  HttpCode,
} from "@nestjs/common";
import { z } from "zod";
import { SessionGuard, AuthRequest } from "./guards";
import { SocialService } from "./social.service";
import { Cache } from "./resources";
function valid<T>(schema: z.ZodType<T>, value: unknown) {
  const r = schema.safeParse(value);
  if (!r.success) throw new BadRequestException("Invalid request");
  return r.data;
}
@Controller("friends")
@UseGuards(SessionGuard)
export class SocialController {
  constructor(
    private readonly social: SocialService,
    private readonly cache: Cache,
  ) {}
  @Get() list(@Req() r: AuthRequest) {
    return this.social.list(r.session.userId);
  }
  @Get("search") search(@Req() r: AuthRequest, @Query() query: unknown) {
    const { q } = valid(
      z.object({ q: z.string().trim().min(2).max(64) }).strict(),
      query,
    );
    return this.social.search(r.session.userId, q);
  }
  @Post("requests") @HttpCode(200) async request(
    @Req() r: AuthRequest,
    @Body() body: unknown,
  ) {
    const { userId } = valid(
      z.object({ userId: z.string().uuid() }).strict(),
      body,
    );
    let count: number;
    try {
      count = Number(
        await this.cache.client.eval(
          "local n=redis.call('INCR',KEYS[1]); if n==1 then redis.call('EXPIRE',KEYS[1],3600) end; return n",
          1,
          "friend-requests:" + r.session.userId,
        ),
      );
    } catch {
      throw new ServiceUnavailableException();
    }
    if (count > 10) throw new HttpException("Request limit exceeded", 429);
    return this.social.request(r.session.userId, userId);
  }
  @Post("requests/:id/accept") @HttpCode(200) accept(
    @Req() r: AuthRequest,
    @Param("id") id: string,
  ) {
    return this.social.accept(r.session.userId, valid(z.string().uuid(), id));
  }
  @Post("blocks/:id") @HttpCode(200) block(
    @Req() r: AuthRequest,
    @Param("id") id: string,
  ) {
    return this.social.block(r.session.userId, valid(z.string().uuid(), id));
  }
  @Delete("blocks/:id") unblock(
    @Req() r: AuthRequest,
    @Param("id") id: string,
  ) {
    return this.social.unblock(r.session.userId, valid(z.string().uuid(), id));
  }
  @Delete(":id") remove(@Req() r: AuthRequest, @Param("id") id: string) {
    return this.social.remove(r.session.userId, valid(z.string().uuid(), id));
  }
}
