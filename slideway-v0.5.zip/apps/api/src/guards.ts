import {
  CanActivate,
  ExecutionContext,
  HttpException,
  Injectable,
  ServiceUnavailableException,
} from "@nestjs/common";
import { Request } from "express";
import { UserSession } from "@prisma/client";
import { AuthService } from "./auth.service";
import { Cache } from "./resources";
import { digest } from "../../../packages/security/src/telegram";
export type AuthRequest = Request & { session: UserSession };
@Injectable()
export class SessionGuard implements CanActivate {
  constructor(private readonly auth: AuthService) {}
  async canActivate(ctx: ExecutionContext) {
    const req = ctx.switchToHttp().getRequest<AuthRequest>();
    req.session = await this.auth.authenticate(req.headers.authorization);
    return true;
  }
}
@Injectable()
export class RateGuard implements CanActivate {
  constructor(private readonly cache: Cache) {}
  async canActivate(ctx: ExecutionContext) {
    const req = ctx.switchToHttp().getRequest<Request>();
    if (
      req.path === "/api/v1/telegram/webhook" ||
      req.path === "/api/v1/health/live" ||
      req.path === "/api/v1/health/ready"
    )
      return true;
    const login = req.path === "/api/v1/auth/telegram";
    const key = `rate:${login ? "login" : "api"}:${digest(req.ip || "unknown")}`;
    let count: number;
    try {
      count = Number(
        await this.cache.client.eval(
          "local n=redis.call('INCR',KEYS[1]); if n==1 then redis.call('EXPIRE',KEYS[1],60) end; return n",
          1,
          key,
        ),
      );
    } catch {
      throw new ServiceUnavailableException("Rate limiter unavailable");
    }
    if (count > (login ? 20 : 120)) {
      ctx.switchToHttp().getResponse().setHeader("Retry-After", "60");
      throw new HttpException("Too many requests", 429);
    }
    return true;
  }
}
