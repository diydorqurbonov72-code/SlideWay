import {
  Controller,
  Get,
  Post,
  Body,
  Req,
  Param,
  Query,
  UseGuards,
  BadRequestException,
  HttpCode,
} from "@nestjs/common";
import { z } from "zod";
import { AuthRequest, SessionGuard } from "./guards";
import { AdminService, Action } from "./admin.service";
const querySchema = z
  .object({
    q: z.string().trim().max(80).default(""),
    cursor: z.string().uuid().optional(),
  })
  .strict();
const commandSchema = z
  .object({
    operationId: z.string().uuid(),
    reason: z.string().trim().min(3).max(280),
    durationHours: z.number().int().min(1).max(8760).optional(),
    role: z
      .enum(["ADMINISTRATOR", "MODERATOR", "SUPPORT", "ANALYST", "NONE"])
      .optional(),
  })
  .strict();
function parse<T>(schema: z.ZodType<T>, data: unknown): T {
  const result = schema.safeParse(data);
  if (!result.success) throw new BadRequestException("Invalid request");
  return result.data;
}
@Controller("admin")
@UseGuards(SessionGuard)
export class AdminController {
  constructor(private readonly admin: AdminService) {}
  @Get("me") me(@Req() req: AuthRequest) {
    return this.admin.identity(req.session.userId);
  }
  @Get("dashboard") dashboard(@Req() req: AuthRequest) {
    return this.admin.dashboard(req.session.userId);
  }
  @Get("users") users(@Req() req: AuthRequest, @Query() query: unknown) {
    const { q, cursor } = parse(querySchema, query);
    return this.admin.users(req.session.userId, q, cursor);
  }
  @Get("audit") audit(@Req() req: AuthRequest, @Query() query: unknown) {
    const { cursor } = parse(
      z.object({ cursor: z.string().uuid().optional() }).strict(),
      query,
    );
    return this.admin.audit(req.session.userId, cursor);
  }
  @Post("users/:id/:action") @HttpCode(200) mutate(
    @Req() req: AuthRequest,
    @Param("id") id: string,
    @Param("action") action: string,
    @Body() body: unknown,
  ) {
    parse(z.string().uuid(), id);
    const valid = parse(
      z.enum(["ban", "unban", "revoke-sessions", "role"]),
      action,
    ) as Action;
    const command = parse(commandSchema, body);
    if (
      (valid === "role" && !command.role) ||
      (valid !== "role" && command.role) ||
      (valid !== "ban" && command.durationHours)
    )
      throw new BadRequestException("Invalid action fields");
    return this.admin.mutate(req, id, valid, command);
  }
}
