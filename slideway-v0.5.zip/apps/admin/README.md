# SlideWay Control Center

Отдельный React/TypeScript/Vite frontend, путь /admin/. `npm run dev:admin` из корня — порт 5174. Server API на порту 3000. `npm run build -w @slideway/admin` — apps/admin/dist.

Вход через Telegram initData; права проверяет backend. Owner ID 8765005700 задан серверной конфигурацией, отсутствует как доверенная настройка frontend. Нужна скрытая команда /admin; обычный браузер показывает входной экран без демоданных.

Работают dashboard, поиск пользователей, временные/бессрочные ограничения, разблокировка, отзыв сессий, роли и Audit Log. UI скрывает недоступные роли действия, но безопасность обеспечивается API. Подтверждение изменений — Radix dialog с причиной; повторная попытка сохраняет operationId, пока форма не изменена. Подробнее docs/ADMIN.md.
