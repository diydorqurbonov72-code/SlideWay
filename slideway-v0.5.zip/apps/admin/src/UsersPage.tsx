import { useState, useRef } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import * as Dialog from "@radix-ui/react-dialog";
import {
  Search,
  ChevronRight,
  X,
  ShieldCheck,
  UserRound,
  CheckCircle2,
} from "lucide-react";
import {
  request,
  useAuth,
  UserRow,
  Page,
  roleLabel,
  formatDate,
  errorMessage,
} from "./api";
import { Button, Panel, Loading, ErrorState, Pagination } from "./components";
type Action = "ban" | "unban" | "revoke-sessions" | "role";
export default function UsersPage() {
  const initial = new URLSearchParams(location.search).get("q") ?? "";
  const [q, setQ] = useState(initial),
    [draft, setDraft] = useState(initial),
    [cursors, setCursors] = useState<(string | undefined)[]>([undefined]),
    [selected, setSelected] = useState<UserRow | null>(null),
    [notice, setNotice] = useState("");
  const cursor = cursors.at(-1);
  const query = useQuery({
    queryKey: ["admin", "users", q, cursor],
    queryFn: () =>
      request<Page<UserRow>>(
        "/admin/users?" +
          new URLSearchParams({ q, ...(cursor ? { cursor } : {}) }),
      ),
  });
  return (
    <>
      <Panel className="users-panel">
        <form
          className="table-toolbar"
          onSubmit={(e) => {
            e.preventDefault();
            setQ(draft.trim());
            setCursors([undefined]);
            const url = new URL(location.href);
            draft.trim()
              ? url.searchParams.set("q", draft.trim())
              : url.searchParams.delete("q");
            history.replaceState(null, "", url);
          }}
        >
          <div className="search-field">
            <Search size={18} aria-hidden="true" />
            <label className="sr-only" htmlFor="user-search">
              Поиск пользователей
            </label>
            <input
              id="user-search"
              name="q"
              value={draft}
              onChange={(e) => setDraft(e.target.value)}
              maxLength={80}
              placeholder="Имя или username…"
              autoComplete="off"
            />
            <Button type="submit">Найти</Button>
          </div>
          <span className="table-note">Реальные аккаунты платформы</span>
        </form>
        <div className="notice" aria-live="polite">
          {notice && (
            <>
              <CheckCircle2 size={16} aria-hidden="true" />
              {notice}
            </>
          )}
        </div>
        {query.isPending ? (
          <Loading />
        ) : query.isError ? (
          <ErrorState error={query.error} onRetry={() => query.refetch()} />
        ) : (
          <>
            <div className="table-scroll">
              <table>
                <thead>
                  <tr>
                    <th>Пользователь</th>
                    <th>Роль</th>
                    <th>Статус</th>
                    <th>Регистрация</th>
                    <th>
                      <span className="sr-only">Действия</span>
                    </th>
                  </tr>
                </thead>
                <tbody>
                  {query.data.items.map((user) => (
                    <tr key={user.id}>
                      <td>
                        <div className="table-user">
                          <span className="user-avatar">
                            {user.displayName.slice(0, 1)}
                          </span>
                          <div>
                            <strong>{user.displayName}</strong>
                            <small>
                              {user.username
                                ? "@" + user.username
                                : "Без username"}
                            </small>
                          </div>
                        </div>
                      </td>
                      <td>
                        <span
                          className={
                            "role-badge " +
                            (user.role === "OWNER" ? "owner" : "")
                          }
                        >
                          {roleLabel(user.role)}
                        </span>
                      </td>
                      <td>
                        <span
                          className={
                            "status " +
                            (user.restricted ? "restricted" : "active")
                          }
                        >
                          <i />
                          {user.restricted ? "Ограничен" : "Активен"}
                        </span>
                      </td>
                      <td className="date-cell">
                        {formatDate(user.createdAt)}
                      </td>
                      <td>
                        <button
                          className="row-action"
                          aria-label={"Управлять: " + user.displayName}
                          onClick={() => setSelected(user)}
                        >
                          <ChevronRight size={20} aria-hidden="true" />
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
              {query.data.items.length === 0 && (
                <div className="empty">
                  <UserRound size={28} aria-hidden="true" />
                  <h3>Никого не нашли</h3>
                  <p>Попробуй другое имя или username.</p>
                </div>
              )}
            </div>
            <Pagination
              hasNext={!!query.data.nextCursor}
              hasPrevious={cursors.length > 1}
              next={() => setCursors([...cursors, query.data.nextCursor!])}
              previous={() => setCursors(cursors.slice(0, -1))}
              fetching={query.isFetching}
            />
          </>
        )}
      </Panel>
      {selected && (
        <UserDialog
          key={selected.id}
          user={selected}
          close={() => setSelected(null)}
          success={() => {
            setSelected(null);
            setNotice("Изменения применены и записаны в журнал.");
          }}
        />
      )}
    </>
  );
}
function UserDialog({
  user,
  close,
  success,
}: {
  user: UserRow;
  close: () => void;
  success: () => void;
}) {
  const identity = useAuth((s) => s.identity)!;
  const qc = useQueryClient();
  const protectedAccount =
    user.role === "OWNER" ||
    user.id === identity.id ||
    (identity.role !== "OWNER" && !!user.role);
  const actions: { id: Action; label: string }[] = [];
  if (!protectedAccount) {
    if (identity.permissions.includes("users:moderate"))
      actions.push({
        id: user.restricted ? "unban" : "ban",
        label: user.restricted ? "Снять ограничение" : "Ограничить аккаунт",
      });
    if (identity.permissions.includes("sessions:revoke"))
      actions.push({ id: "revoke-sessions", label: "Завершить все сессии" });
    if (identity.permissions.includes("roles:write"))
      actions.push({ id: "role", label: "Изменить роль" });
  }
  const [action, setAction] = useState<Action>(actions[0]?.id ?? "ban"),
    [reason, setReason] = useState(""),
    [duration, setDuration] = useState("24"),
    [role, setRole] = useState(user.role ?? "NONE");
  const operationId = useRef(crypto.randomUUID());
  const resetKey = () => {
    operationId.current = crypto.randomUUID();
  };
  const mutation = useMutation({
    mutationFn: () =>
      request("/admin/users/" + user.id + "/" + action, "POST", {
        operationId: operationId.current,
        reason: reason.trim(),
        ...(action === "ban" && duration !== "permanent"
          ? { durationHours: Number(duration) }
          : {}),
        ...(action === "role" ? { role } : {}),
      }),
    onSuccess: () => {
      void qc.invalidateQueries({ queryKey: ["admin"] });
      success();
    },
  });
  return (
    <Dialog.Root
      open
      onOpenChange={(open) => {
        if (!open && !mutation.isPending) close();
      }}
    >
      <Dialog.Portal>
        <Dialog.Overlay className="dialog-overlay" />
        <Dialog.Content className="user-dialog">
          <div className="dialog-top">
            <span className="user-avatar large">
              {user.displayName.slice(0, 1)}
            </span>
            <Dialog.Close asChild>
              <button
                className="row-action"
                aria-label="Закрыть"
                disabled={mutation.isPending}
              >
                <X size={20} aria-hidden="true" />
              </button>
            </Dialog.Close>
          </div>
          <Dialog.Title>{user.displayName}</Dialog.Title>
          <Dialog.Description>
            {user.username ? "@" + user.username : "Участник SlideWay"} ·{" "}
            {roleLabel(user.role)}
          </Dialog.Description>
          <dl className="user-details">
            <div>
              <dt>Статус</dt>
              <dd>
                {user.restricted ? "Доступ ограничен" : "Аккаунт активен"}
              </dd>
            </div>
            <div>
              <dt>Регистрация</dt>
              <dd>{formatDate(user.createdAt)}</dd>
            </div>
            {user.telegramId && (
              <div>
                <dt>Telegram ID</dt>
                <dd>{user.telegramId}</dd>
              </div>
            )}
            {user.restricted && (
              <>
                <div>
                  <dt>Причина</dt>
                  <dd>{user.banReason ?? "Не указана"}</dd>
                </div>
                <div>
                  <dt>Окончание</dt>
                  <dd>
                    {user.banUntil ? formatDate(user.banUntil) : "Бессрочно"}
                  </dd>
                </div>
              </>
            )}
          </dl>
          {actions.length ? (
            <form
              onSubmit={(e) => {
                e.preventDefault();
                if (reason.trim().length >= 3) mutation.mutate();
              }}
            >
              <label htmlFor="admin-action">Действие</label>
              <select
                id="admin-action"
                value={action}
                onChange={(e) => {
                  setAction(e.target.value as Action);
                  resetKey();
                  mutation.reset();
                }}
              >
                {actions.map((a) => (
                  <option key={a.id} value={a.id}>
                    {a.label}
                  </option>
                ))}
              </select>
              {action === "ban" && (
                <>
                  <label htmlFor="ban-duration">Срок ограничения</label>
                  <select
                    id="ban-duration"
                    value={duration}
                    onChange={(e) => {
                      setDuration(e.target.value);
                      resetKey();
                    }}
                  >
                    <option value="1">1 час</option>
                    <option value="24">24 часа</option>
                    <option value="168">7 дней</option>
                    <option value="permanent">Бессрочно</option>
                  </select>
                </>
              )}
              {action === "role" && (
                <>
                  <label htmlFor="admin-role">Новая роль</label>
                  <select
                    id="admin-role"
                    value={role}
                    onChange={(e) => {
                      setRole(e.target.value);
                      resetKey();
                    }}
                  >
                    {[
                      "NONE",
                      "ADMINISTRATOR",
                      "MODERATOR",
                      "SUPPORT",
                      "ANALYST",
                    ].map((r) => (
                      <option key={r} value={r}>
                        {roleLabel(r === "NONE" ? null : r)}
                      </option>
                    ))}
                  </select>
                  <p className="helper">
                    После изменения роли пользователь должен войти заново.
                  </p>
                </>
              )}
              <label htmlFor="action-reason">Причина действия</label>
              <textarea
                id="action-reason"
                name="reason"
                value={reason}
                required
                minLength={3}
                maxLength={280}
                rows={3}
                autoComplete="off"
                placeholder="Кратко опиши причину…"
                onChange={(e) => {
                  setReason(e.target.value);
                  resetKey();
                  mutation.reset();
                }}
              />
              <p className="helper">
                <ShieldCheck size={14} aria-hidden="true" />
                Действие и причина сохранятся в журнале.
              </p>
              {mutation.isError && (
                <p className="error" role="alert">
                  {errorMessage(mutation.error)}
                </p>
              )}
              <div className="dialog-actions">
                <Button
                  type="button"
                  onClick={close}
                  disabled={mutation.isPending}
                >
                  Отмена
                </Button>
                <Button
                  variant={action === "ban" ? "danger" : "primary"}
                  disabled={mutation.isPending || reason.trim().length < 3}
                >
                  {mutation.isPending ? "Применяем…" : "Подтвердить действие"}
                </Button>
              </div>
            </form>
          ) : (
            <div className="protected-note">
              <ShieldCheck size={20} aria-hidden="true" />
              {protectedAccount
                ? "Этот аккаунт защищён от изменений через панель."
                : "У твоей роли есть только доступ к просмотру."}
            </div>
          )}
        </Dialog.Content>
      </Dialog.Portal>
    </Dialog.Root>
  );
}
