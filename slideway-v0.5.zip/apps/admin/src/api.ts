import { create } from "zustand";
export type Permission =
  | "dashboard:read"
  | "users:read"
  | "users:moderate"
  | "sessions:revoke"
  | "roles:write"
  | "audit:read";
export interface Identity {
  id: string;
  displayName: string;
  role: string;
  permissions: Permission[];
}
export interface UserRow {
  id: string;
  displayName: string;
  username: string | null;
  createdAt: string;
  locale: string;
  restricted: boolean;
  banReason: string | null;
  banUntil: string | null;
  role: string | null;
  telegramId?: string;
}
export interface Dashboard {
  users: number;
  newUsers: number;
  activeSessions: number;
  restrictedUsers: number;
  queue: { pending: number; done: number; failed: number };
  registrations: { date: string; count: number }[];
  generatedAt: string;
}
export interface Audit {
  id: string;
  action: string;
  details: { reason?: string; role?: string; durationHours?: number };
  createdAt: string;
  actor: { displayName: string } | null;
  target: { displayName: string } | null;
}
export interface Page<T> {
  items: T[];
  nextCursor: string | null;
}
export const useAuth = create<{
  token: string | null;
  identity: Identity | null;
  phase: "loading" | "outside" | "ready" | "denied" | "expired" | "error";
}>(() => ({ token: null, identity: null, phase: "loading" }));
export class ApiError extends Error {
  constructor(public status: number) {
    super(String(status));
  }
}
export async function request<T>(
  path: string,
  method = "GET",
  body?: unknown,
): Promise<T> {
  const token = useAuth.getState().token;
  const r = await fetch("/api/v1" + path, {
    method,
    headers: {
      "Content-Type": "application/json",
      ...(token ? { Authorization: "Bearer " + token } : {}),
    },
    body: body === undefined ? undefined : JSON.stringify(body),
    signal: AbortSignal.timeout(15000),
  });
  if (!r.ok) {
    if (r.status === 401 && path !== "/auth/telegram")
      useAuth.setState({ phase: "expired", token: null, identity: null });
    throw new ApiError(r.status);
  }
  return r.status === 204 ? (undefined as T) : r.json();
}
let started = false;
export async function authenticate() {
  if (started) return;
  started = true;
  const tg = (window as any).Telegram?.WebApp;
  if (!tg?.initData) {
    useAuth.setState({ phase: "outside" });
    return;
  }
  tg.ready();
  tg.expand();
  const safe = () =>
    document.documentElement.style.setProperty(
      "--tg-top",
      `${(tg.safeAreaInset?.top ?? 0) + (tg.contentSafeAreaInset?.top ?? 0)}px`,
    );
  safe();
  tg.onEvent?.("safeAreaChanged", safe);
  tg.onEvent?.("contentSafeAreaChanged", safe);
  try {
    const auth = await request<{ accessToken: string }>(
      "/auth/telegram",
      "POST",
      { initData: tg.initData },
    );
    useAuth.setState({ token: auth.accessToken });
    const identity = await request<Identity>("/admin/me");
    useAuth.setState({ phase: "ready", identity });
  } catch (e) {
    useAuth.setState({
      phase: e instanceof ApiError && e.status === 403 ? "denied" : "error",
      token: null,
      identity: null,
    });
  }
}
export const errorMessage = (error: unknown) =>
  error instanceof ApiError
    ? error.status === 403
      ? "Недостаточно прав для этого действия."
      : error.status === 409
        ? "Данные изменились. Обнови страницу и повтори действие."
        : error.status === 429
          ? "Слишком много запросов. Подожди минуту."
          : error.status === 400
            ? "Проверь заполненные поля."
            : "Не удалось выполнить запрос. Попробуй ещё раз."
    : "Не удалось связаться с сервером. Проверь соединение.";
export const roleLabel = (role: string | null) =>
  ({
    OWNER: "Владелец",
    ADMINISTRATOR: "Администратор",
    MODERATOR: "Модератор",
    SUPPORT: "Поддержка",
    ANALYST: "Аналитик",
  })[role ?? ""] ?? "Участник";
export const formatDate = (date: string) =>
  new Intl.DateTimeFormat("ru-RU", {
    dateStyle: "medium",
    timeStyle: "short",
  }).format(new Date(date));
