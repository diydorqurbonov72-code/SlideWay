import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { ScrollText, ShieldCheck } from "lucide-react";
import { request, Page, Audit, formatDate, roleLabel } from "./api";
import { Panel, Loading, ErrorState, Pagination } from "./components";
const actionLabel: Record<string, string> = {
  ban: "Ограничение аккаунта",
  unban: "Снятие ограничения",
  "revoke-sessions": "Отзыв сессий",
  role: "Изменение роли",
};
export default function AuditPage() {
  const [cursors, setCursors] = useState<(string | undefined)[]>([undefined]);
  const cursor = cursors.at(-1);
  const q = useQuery({
    queryKey: ["admin", "audit", cursor],
    queryFn: () =>
      request<Page<Audit>>(
        "/admin/audit" + (cursor ? "?cursor=" + cursor : ""),
      ),
  });
  return (
    <Panel>
      <div className="panel-heading">
        <div>
          <h2>История административных действий</h2>
          <p>Записывается сервером вместе с изменением данных.</p>
        </div>
        <ShieldCheck size={22} className="teal" aria-hidden="true" />
      </div>
      {q.isPending ? (
        <Loading />
      ) : q.isError ? (
        <ErrorState error={q.error} onRetry={() => q.refetch()} />
      ) : (
        <>
          {q.data.items.length === 0 ? (
            <div className="empty">
              <ScrollText size={30} aria-hidden="true" />
              <h3>Журнал пока пуст</h3>
              <p>Здесь появятся действия администраторов.</p>
            </div>
          ) : (
            <div className="audit-list">
              {q.data.items.map((row) => (
                <article className="audit-row" key={row.id}>
                  <span className="audit-icon">
                    <ShieldCheck size={18} aria-hidden="true" />
                  </span>
                  <div>
                    <h3>{actionLabel[row.action] ?? row.action}</h3>
                    <p>
                      <strong>
                        {row.actor?.displayName ?? "Удалённый аккаунт"}
                      </strong>{" "}
                      → {row.target?.displayName ?? "Удалённый аккаунт"}
                    </p>
                    <p className="audit-reason">{row.details.reason}</p>
                    {row.details.role && (
                      <small>
                        Новая роль:{" "}
                        {roleLabel(
                          row.details.role === "NONE" ? null : row.details.role,
                        )}
                      </small>
                    )}
                  </div>
                  <time dateTime={row.createdAt}>
                    {formatDate(row.createdAt)}
                  </time>
                </article>
              ))}
            </div>
          )}
          <Pagination
            hasNext={!!q.data.nextCursor}
            hasPrevious={cursors.length > 1}
            next={() => setCursors([...cursors, q.data.nextCursor!])}
            previous={() => setCursors(cursors.slice(0, -1))}
            fetching={q.isFetching}
          />
        </>
      )}
    </Panel>
  );
}
