import type { ButtonHTMLAttributes, ReactNode } from "react";
import { LoaderCircle, RefreshCw } from "lucide-react";
import { errorMessage } from "./api";
export function Button({
  variant = "secondary",
  className = "",
  ...props
}: ButtonHTMLAttributes<HTMLButtonElement> & {
  variant?: "primary" | "secondary" | "danger" | "ghost";
}) {
  return <button className={`button ${variant} ${className}`} {...props} />;
}
export function Panel({
  children,
  className = "",
}: {
  children: ReactNode;
  className?: string;
}) {
  return <section className={"panel " + className}>{children}</section>;
}
export function Loading() {
  return (
    <div className="loading" role="status">
      <LoaderCircle className="spin" aria-hidden="true" />
      Загружаем данные…
    </div>
  );
}
export function ErrorState({
  error,
  onRetry,
}: {
  error: unknown;
  onRetry: () => void;
}) {
  return (
    <div className="error-state" role="alert">
      <p>{errorMessage(error)}</p>
      <Button onClick={onRetry}>
        <RefreshCw size={16} aria-hidden="true" />
        Повторить
      </Button>
    </div>
  );
}
export function Pagination({
  hasNext,
  hasPrevious,
  next,
  previous,
  fetching,
}: {
  hasNext: boolean;
  hasPrevious: boolean;
  next: () => void;
  previous: () => void;
  fetching: boolean;
}) {
  return (
    <div className="pagination">
      <span>До 25 записей на странице</span>
      <div>
        <Button disabled={!hasPrevious || fetching} onClick={previous}>
          Назад
        </Button>
        <Button disabled={!hasNext || fetching} onClick={next}>
          Далее
        </Button>
      </div>
    </div>
  );
}
