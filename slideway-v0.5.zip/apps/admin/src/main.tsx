import React, { useEffect, useState, lazy, Suspense } from "react";
import { createRoot } from "react-dom/client";
import {
  QueryClient,
  QueryClientProvider,
  useQueryClient,
} from "@tanstack/react-query";
import {
  LayoutDashboard,
  Users,
  ScrollText,
  ShieldCheck,
  RefreshCw,
  ArrowUpRight,
  LockKeyhole,
  ChevronRight,
} from "lucide-react";
import { authenticate, useAuth, roleLabel, Permission } from "./api";
import { Button, Loading } from "./components";
import DashboardPage from "./DashboardPage";
import "./styles.css";
const UsersPage = lazy(() => import("./UsersPage"));
const AuditPage = lazy(() => import("./AuditPage"));
const queryClient = new QueryClient({
  defaultOptions: {
    queries: { retry: 1, staleTime: 15000 },
    mutations: { retry: false },
  },
});
function Brand() {
  return (
    <div className="brand" translate="no">
      <span className="brand-mark">
        <i />
        <i />
      </span>
      <span>
        slideway<span className="brand-dot">.</span>
        <small>CONTROL CENTER</small>
      </span>
    </div>
  );
}
const pages = [
  {
    id: "overview",
    title: "Обзор",
    description: "Всё важное о платформе — в одном месте.",
    Icon: LayoutDashboard,
    permission: "dashboard:read",
  },
  {
    id: "users",
    title: "Пользователи",
    description: "Аккаунты, доступ и роли участников SlideWay.",
    Icon: Users,
    permission: "users:read",
  },
  {
    id: "audit",
    title: "Журнал действий",
    description: "Прозрачная история изменений и решений.",
    Icon: ScrollText,
    permission: "audit:read",
  },
] as const;
function App() {
  const { phase, identity } = useAuth();
  const qc = useQueryClient();
  const [active, setActive] = useState(location.hash.slice(1) || "overview");
  useEffect(() => {
    void authenticate();
  }, []);
  useEffect(() => {
    const listener = () => setActive(location.hash.slice(1) || "overview");
    window.addEventListener("hashchange", listener);
    return () => window.removeEventListener("hashchange", listener);
  }, []);
  if (phase === "loading") return <Loading />;
  if (phase !== "ready" || !identity)
    return (
      <div className="admin-gate">
        <Brand />
        <span className="gate-symbol">
          <LockKeyhole size={35} aria-hidden="true" />
        </span>
        <span className="eyebrow">PRIVATE WORKSPACE</span>
        <h1>
          {phase === "denied"
            ? "Доступ ограничен."
            : phase === "outside"
              ? "Центр управления."
              : "Открой панель заново."}
        </h1>
        <p>
          {phase === "denied"
            ? "У этого Telegram-аккаунта нет прав администратора. Доступ назначает владелец платформы."
            : phase === "outside"
              ? "Панель открывается через скрытую команду /admin в Telegram-боте. Команда доступна владельцу и назначенным им администраторам."
              : phase === "expired"
                ? "Сессия завершена или требуется свежий вход для изменения данных. Закрой Mini App и снова используй /admin."
                : "Не удалось подтвердить вход. Проверь соединение и заново открой панель через Telegram."}
        </p>
        <div className="gate-security">
          <ShieldCheck size={16} aria-hidden="true" />
          Проверка Telegram на сервере · Разграничение прав
        </div>
      </div>
    );
  const allowed = pages.filter((p) =>
    identity.permissions.includes(p.permission as Permission),
  );
  const page = allowed.find((p) => p.id === active) ?? allowed[0];
  return (
    <div className="admin-shell">
      <a className="skip-link" href="#main-content">
        Перейти к содержимому
      </a>
      <aside className="sidebar">
        <Brand />
        <div className="nav-caption">РАБОЧЕЕ ПРОСТРАНСТВО</div>
        <nav aria-label="Разделы панели">
          {allowed.map(({ id, title, Icon }) => (
            <a
              key={id}
              href={"#" + id}
              className={page.id === id ? "selected" : ""}
              aria-current={page.id === id ? "page" : undefined}
            >
              <Icon size={19} aria-hidden="true" />
              <span>{title}</span>
              {page.id === id && <i />}
            </a>
          ))}
        </nav>
        <div className="sidebar-note">
          <ShieldCheck size={22} aria-hidden="true" />
          <strong>Доступ под контролем</strong>
          <p>Все изменения проверяются сервером и сохраняются в журнале.</p>
        </div>
        <div className="sidebar-profile">
          <span className="user-avatar">
            {identity.displayName.slice(0, 1)}
          </span>
          <div>
            <strong>{identity.displayName}</strong>
            <small>{roleLabel(identity.role)}</small>
          </div>
          <span className="profile-dot" />
        </div>
      </aside>
      <div className="workspace">
        <header className="topbar">
          <div className="breadcrumb">
            Control Center
            <ChevronRight size={14} aria-hidden="true" />
            <span>{page.title}</span>
          </div>
          <span className="access-tag">
            <ShieldCheck size={14} aria-hidden="true" />
            {roleLabel(identity.role)}
          </span>
        </header>
        <main id="main-content" tabIndex={-1}>
          <div className="page-header">
            <div>
              <span className="eyebrow">SLIDEWAY ADMINISTRATION</span>
              <h1>
                {page.title === "Обзор"
                  ? "Платформа под контролем."
                  : page.title}
              </h1>
              <p>{page.description}</p>
            </div>
            <Button
              onClick={() => qc.invalidateQueries({ queryKey: ["admin"] })}
            >
              <RefreshCw size={16} aria-hidden="true" />
              Обновить
            </Button>
          </div>
          <Suspense fallback={<Loading />}>
            {page.id === "overview" ? (
              <DashboardPage />
            ) : page.id === "users" ? (
              <UsersPage />
            ) : (
              <AuditPage />
            )}
          </Suspense>
          <footer>
            <span>
              SLIDEWAY <b>CONTROL CENTER</b>
            </span>
            <span>
              Права проверяются для каждого запроса
              <ShieldCheck size={13} aria-hidden="true" />
            </span>
          </footer>
        </main>
      </div>
    </div>
  );
}
createRoot(document.getElementById("root")!).render(
  <React.StrictMode>
    <QueryClientProvider client={queryClient}>
      <App />
    </QueryClientProvider>
  </React.StrictMode>,
);

import "./liquid-glass.css";
