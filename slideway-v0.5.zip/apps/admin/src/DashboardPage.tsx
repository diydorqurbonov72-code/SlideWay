import { useQuery } from "@tanstack/react-query";
import {
  Users,
  UserPlus,
  Monitor,
  ShieldAlert,
  ArrowUpRight,
  CheckCircle2,
  Clock3,
  AlertCircle,
} from "lucide-react";
import { Dashboard, request, formatDate } from "./api";
import { Loading, ErrorState, Panel } from "./components";
const number = (n: number) => new Intl.NumberFormat("ru-RU").format(n);
export default function DashboardPage() {
  const q = useQuery({
    queryKey: ["admin", "dashboard"],
    queryFn: () => request<Dashboard>("/admin/dashboard"),
  });
  if (q.isPending) return <Loading />;
  if (q.isError)
    return <ErrorState error={q.error} onRetry={() => q.refetch()} />;
  const d = q.data,
    max = Math.max(...d.registrations.map((x) => x.count), 1);
  const stats = [
    {
      name: "Всего пользователей",
      value: d.users,
      Icon: Users,
      detail: "Зарегистрированы в SlideWay",
      color: "purple",
    },
    {
      name: "Новые за 24 часа",
      value: d.newUsers,
      Icon: UserPlus,
      detail: "Скользящее окно регистрации",
      color: "teal",
    },
    {
      name: "Активные сессии",
      value: d.activeSessions,
      Icon: Monitor,
      detail: "Сессии с действующим сроком",
      color: "blue",
    },
    {
      name: "Ограниченные аккаунты",
      value: d.restrictedUsers,
      Icon: ShieldAlert,
      detail: "Действующие блокировки",
      color: "amber",
    },
  ];
  return (
    <>
      <div className="metrics">
        {stats.map(({ name, value, Icon, detail, color }) => (
          <Panel key={name} className="metric">
            <div className="metric-top">
              <span>{name}</span>
              <span className={"metric-icon " + color}>
                <Icon size={18} aria-hidden="true" />
              </span>
            </div>
            <strong>{number(value)}</strong>
            <p>{detail}</p>
          </Panel>
        ))}
      </div>
      <div className="dashboard-grid">
        <Panel className="chart-panel">
          <div className="panel-heading">
            <div>
              <h2>Новые участники</h2>
              <p>Регистрации за последние 7 дней · UTC</p>
            </div>
            <span className="badge">7 дней</span>
          </div>
          <div
            className="chart"
            role="img"
            aria-label={
              "Регистрации: " +
              d.registrations.map((x) => x.date + ": " + x.count).join("; ")
            }
          >
            {d.registrations.map((x, i) => (
              <div className="chart-column" key={x.date}>
                <span className="bar-value">{number(x.count)}</span>
                <div
                  className={"bar " + (i === 6 ? "last" : "")}
                  style={{
                    height: `${(x.count / max) * 170}px`,
                    minHeight: x.count ? 6 : 2,
                  }}
                />
                <span className="bar-label">
                  {new Intl.DateTimeFormat("ru-RU", {
                    day: "numeric",
                    month: "short",
                    timeZone: "UTC",
                  }).format(new Date(x.date))}
                </span>
              </div>
            ))}
          </div>
          <div className="chart-caption">
            <span>
              <i />
              Реальные регистрации
            </span>
            <strong>
              {number(d.registrations.reduce((sum, x) => sum + x.count, 0))} за
              неделю
            </strong>
          </div>
        </Panel>
        <Panel className="queue-panel">
          <div className="panel-heading">
            <div>
              <h2>Telegram-бот</h2>
              <p>Состояние очереди команд</p>
            </div>
            <span className="tiny-orb">
              <ArrowUpRight size={17} aria-hidden="true" />
            </span>
          </div>
          {[
            {
              label: "В очереди",
              value: d.queue.pending,
              Icon: Clock3,
              color: "amber",
            },
            {
              label: "Выполнено",
              value: d.queue.done,
              Icon: CheckCircle2,
              color: "teal",
            },
            {
              label: "Завершились ошибкой",
              value: d.queue.failed,
              Icon: AlertCircle,
              color: "rose",
            },
          ].map(({ label, value, Icon, color }) => (
            <div className="queue-row" key={label}>
              <span className={"queue-icon " + color}>
                <Icon size={19} aria-hidden="true" />
              </span>
              <span>{label}</span>
              <strong>{number(value)}</strong>
            </div>
          ))}
          <div className="queue-note">
            Счётчики очереди не подтверждают доступность Telegram. Следи за
            ростом ошибок и временем ожидания.
          </div>
        </Panel>
      </div>
      <Panel className="release-note">
        <div className="release-symbol">
          S<ArrowUpRight size={12} aria-hidden="true" />
        </div>
        <div>
          <span className="eyebrow">SLIDEWAY · CONTROL CENTER</span>
          <h2>Данные, на которые можно опереться.</h2>
          <p>
            Здесь только подключённые модули. Игровая аналитика, сообщества и
            выручка появятся после запуска соответствующих функций.
          </p>
        </div>
      </Panel>
      <p className="last-update">
        Данные обновлены {formatDate(d.generatedAt)}
      </p>
    </>
  );
}
