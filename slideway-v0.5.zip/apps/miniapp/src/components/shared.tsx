import { useMutation,useQueryClient } from "@tanstack/react-query";
import type { LucideIcon } from "lucide-react";
import { Check,ChevronRight,LoaderCircle } from "lucide-react";
import { api,ApiError,Profile } from "../api";
import { navigate,Page,useApp } from "../state";
import { telegram } from "../telegram";

export function useText() {
  const language = useApp((s) => s.language);
  return (ru: string, en: string) => (language === "ru" ? ru : en);
}
export function errorText(error: unknown, ru: boolean) {
  const status = error instanceof ApiError ? error.status : 0;
  const messages: Record<number, [string, string]> = {
    400: ["Проверь заполненные поля.", "Please check the fields."],
    401: ["Сессия завершена. Открой приложение заново.", "Your session ended. Reopen the app."],
    403: ["Действие недоступно. Проверь настройки приватности и доступа.", "Action unavailable. Check privacy and access settings."],
    404: ["Запись больше недоступна. Обнови страницу.", "This item is no longer available. Refresh the page."],
    409: ["Данные изменились. Обнови страницу и повтори действие.", "Data changed. Refresh and try again."],
    429: ["Лимит запросов исчерпан. Попробуй позднее.", "Request limit reached. Try again later."],
  };
  return (messages[status ?? 0] ?? ["Не удалось связаться с сервером. Попробуй ещё раз.", "Could not reach the server. Please try again."])[ru ? 0 : 1];
}
export function Brand() {
  return (
    <a
      href="#home"
      className="brand"
      onClick={(e) => {
        e.preventDefault();
        navigate("home");
      }}
      aria-label="SlideWay"
    >
      <span className="brand-mark">
        <span />
        <span />
      </span>
      slideway<span className="brand-dot">.</span>
    </a>
  );
}
export function IconButton({
  icon: Icon,
  label,
  onClick,
}: {
  icon: LucideIcon;
  label: string;
  onClick: () => void;
}) {
  return (
    <button className="icon-button" aria-label={label} onClick={onClick}>
      <Icon size={20} />
    </button>
  );
}
export function Loading() {
  const t = useText();
  return (
    <div className="loading" role="status">
      <LoaderCircle className="spin" />
      {t("Подключаемся к SlideWay…", "Connecting to SlideWay…")}
    </div>
  );
}
export function Heading({
  eyebrow,
  title,
  description,
}: {
  eyebrow: string;
  title: string;
  description: string;
}) {
  return (
    <div className="page-heading">
      <div className="eyebrow">{eyebrow}</div>
      <h1>{title}</h1>
      <p>{description}</p>
    </div>
  );
}
export function useSave() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (data: unknown) => api<Profile>("/me", "PATCH", data),
    onSuccess: (me) => {
      qc.setQueryData(["me"], me);
      telegram()?.HapticFeedback?.notificationOccurred("success");
    },
  });
}
export function Feedback({
  mutation,
}: {
  mutation: ReturnType<typeof useSave>;
}) {
  const t = useText();
  return (
    <div aria-live="polite">
      {mutation.isSuccess && (
        <p className="success">
          <Check size={16} />
          {t("Изменения сохранены", "Changes saved")}
        </p>
      )}
      {mutation.isError && (
        <p className="error" role="alert">
          {errorText(mutation.error, useApp.getState().language === "ru")}
        </p>
      )}
    </div>
  );
}
export function QuickLink({
  icon: Icon,
  title,
  detail,
  page,
}: {
  icon: LucideIcon;
  title: string;
  detail: string;
  page: Page;
}) {
  return (
    <button className="quick-link" onClick={() => navigate(page)}>
      <Icon size={21} />
      <span>
        <strong>{title}</strong>
        <small>{detail}</small>
      </span>
      <ChevronRight size={18} />
    </button>
  );
}
