import { useApp } from "./state";
import { telegram } from "./telegram";
export class ApiError extends Error {
  constructor(public status: number) {
    super(String(status));
  }
}
export async function api<T>(
  path: string,
  method = "GET",
  body?: unknown,
): Promise<T> {
  const token = useApp.getState().token;
  const r = await fetch("/api/v1" + path, {
    method,
    headers: {
      "Content-Type": "application/json",
      ...(token ? { Authorization: "Bearer " + token } : {}),
    },
    body: body === undefined ? undefined : JSON.stringify(body),
    signal: AbortSignal.timeout(15000),
  });
  if (!r.ok) {
    if (r.status === 401 && path !== "/auth/telegram")
      useApp.setState({ token: null, phase: "expired" });
    throw new ApiError(r.status);
  }
  return r.status === 204 ? (undefined as T) : r.json();
}
let started = false;
export async function bootstrap() {
  if (started) return;
  started = true;
  const t = telegram();
  if (!t?.initData) {
    useApp.setState({ phase: "outside" });
    return;
  }
  t.ready();
  t.expand();
  try {
    const data = await api<{ accessToken: string }>("/auth/telegram", "POST", {
      initData: t.initData,
    });
    useApp.setState({ token: data.accessToken, phase: "ready" });
  } catch (e) {
    useApp.setState({
      phase: "error",
      error: e instanceof ApiError ? String(e.status) : "network",
    });
  }
}
export interface Settings {
  profileVisible: boolean;
  showActivity: boolean;
  showAchievements: boolean;
  allowFriendRequests: boolean;
  notifications: boolean;
}
export interface Profile {
  id: string;
  displayName: string;
  bio: string;
  locale: "ru" | "en" | "uz";
  createdAt: string;
  settings: Settings;
  interests: { interestKey: string }[];
}
export interface Interest {
  key: string;
  nameRu: string;
  nameEn: string;
}
export interface Session {
  id: string;
  createdAt: string;
  expiresAt: string;
  current: boolean;
}
