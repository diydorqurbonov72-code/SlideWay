import { ArrowUpRight,Gamepad2,ShieldCheck,Sparkles } from "lucide-react";
import { useApp } from "../state";

import { Brand,useText } from "../components/shared";
export default function Gate() {
  const t = useText();
  const { phase, error } = useApp();
  const username = import.meta.env.VITE_BOT_USERNAME;
  const link =
    typeof username === "string" && /^[A-Za-z0-9_]{5,32}$/.test(username)
      ? `https://t.me/${username}?start=welcome`
      : null;
  return (
    <div className="gate">
      <Brand />
      <div className="gate-art" aria-hidden="true">
        <div className="orbit" />
        <div className="orb">
          <span className="system-emoji" style={{fontSize:64}} aria-hidden="true">🖤</span>
        </div>
        <span className="floating-chip">
          <Sparkles size={18} /> Play. Connect. Level Up.
        </span>
      </div>
      <div className="eyebrow">YOUR NEXT CHAPTER</div>
      <h1>
        {t("Твой мир.", "Your world.")}
        <br />
        <span>{t("Твои правила.", "Your rules.")}</span>
      </h1>
      <p>
        {phase === "outside"
          ? t(
              "Начни со своего профиля. Открой SlideWay через меню бота в Telegram — вход произойдёт автоматически.",
              "Start with your profile. Open SlideWay from the bot menu in Telegram to sign in automatically.",
            )
          : phase === "signedout"
            ? t(
                "Ты вышел из аккаунта. Чтобы войти снова, закрой и открой Mini App.",
                "You are signed out. Close and reopen the Mini App to sign in again.",
              )
            : phase === "expired"
              ? t(
                  "Сессия завершена. Закрой и открой Mini App для безопасного входа.",
                  "Your session ended. Close and reopen the Mini App to sign in securely.",
                )
              : error === "409"
                ? t(
                    "Эти данные входа уже использованы. Закрой и открой Mini App заново.",
                    "These sign-in details were already used. Close and reopen the Mini App.",
                  )
                : t(
                    "Не удалось войти. Проверь соединение и заново открой Mini App из Telegram.",
                    "Could not sign in. Check your connection and reopen the Mini App from Telegram.",
                  )}
      </p>
      {link && (
        <a className="button primary" href={link}>
          {t("Открыть в Telegram", "Open in Telegram")}
          <ArrowUpRight size={18} />
        </a>
      )}
      <div className="gate-footer">
        <ShieldCheck size={16} />
        {t(
          "Вход через Telegram · Приватность под твоим контролем",
          "Telegram sign-in · Privacy in your hands",
        )}
      </div>
      <button
        className="text-button"
        onClick={() =>
          useApp.setState({
            language: useApp.getState().language === "ru" ? "en" : "ru",
          })
        }
      >
        Русский / English
      </button>
    </div>
  );
}
