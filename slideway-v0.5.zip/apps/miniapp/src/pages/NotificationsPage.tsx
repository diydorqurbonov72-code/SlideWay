import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { CheckCheck, Trash2, Users } from "lucide-react";
import { motion, useReducedMotion } from "framer-motion";
import { api } from "../api";
import { errorText, Heading, Loading, useText } from "../components/shared";
import { navigate, useApp } from "../state";

type ActivityType = "FRIEND_REQUEST" | "FRIEND_ACCEPTED";
interface ActivityItem {
  id: string;
  type: ActivityType;
  entityId: string;
  readAt: string | null;
  createdAt: string;
  actor: { id: string; displayName: string };
}
interface ActivityFeed {
  unread: number;
  items: ActivityItem[];
}

export default function NotificationsPage() {
  const t = useText();
  const language = useApp((state) => state.language);
  const reduce = useReducedMotion();
  const queryClient = useQueryClient();
  const feed = useQuery({
    queryKey: ["notifications"],
    queryFn: () => api<ActivityFeed>("/notifications"),
    staleTime: 0,
    refetchOnMount: "always",
    refetchInterval: 15_000,
  });
  const change = useMutation({
    mutationFn: ({
      path,
      method = "POST",
    }: {
      path: string;
      method?: string;
    }) => api(path, method),
    onSuccess: () => {
      void queryClient.invalidateQueries({ queryKey: ["notifications"] });
    },
  });
  const open = (item: ActivityItem) => {
    if (!item.readAt) change.mutate({ path: `/notifications/${item.id}/read` });
    navigate("friends");
  };
  const time = (value: string) =>
    new Intl.DateTimeFormat(language === "ru" ? "ru-RU" : "en-US", {
      day: "numeric",
      month: "short",
      hour: "2-digit",
      minute: "2-digit",
    }).format(new Date(value));

  return (
    <>
      <Heading
        eyebrow="ACTIVITY"
        title={t("Что нового.", "What's new.")}
        description={t(
          "Заявки и важные события — в одном месте.",
          "Requests and important updates in one place.",
        )}
      />
      <div className="activity-toolbar">
        <span>
          {t("Непрочитанных", "Unread")}: {feed.data?.unread ?? 0}
        </span>
        <button
          className="button secondary"
          disabled={!feed.data?.unread || change.isPending}
          onClick={() => change.mutate({ path: "/notifications/read-all" })}
        >
          <CheckCheck size={17} />
          {t("Прочитать всё", "Mark all read")}
        </button>
      </div>
      <section className="panel activity-panel">
        {feed.isPending ? (
          <Loading />
        ) : feed.isError ? (
          <div role="alert" className="error">
            {errorText(feed.error, language === "ru")}
            <button className="button secondary" onClick={() => feed.refetch()}>
              {t("Повторить", "Retry")}
            </button>
          </div>
        ) : feed.data.items.length ? (
          <div className="activity-list">
            {feed.data.items.map((item) => (
              <motion.article
                key={item.id}
                className={`activity-item${item.readAt ? "" : " unread"}`}
                initial={reduce ? false : { opacity: 0, y: 7 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.18, ease: [0.23, 1, 0.32, 1] }}
              >
                <span
                  className="activity-emoji system-emoji"
                  aria-hidden="true"
                >
                  {item.type === "FRIEND_REQUEST" ? "👋" : "🤝"}
                </span>
                <button className="activity-copy" onClick={() => open(item)}>
                  <strong>
                    {item.type === "FRIEND_REQUEST"
                      ? t(
                          `${item.actor.displayName} хочет добавить тебя в друзья`,
                          `${item.actor.displayName} sent you a friend request`,
                        )
                      : t(
                          `${item.actor.displayName} теперь в твоих друзьях`,
                          `${item.actor.displayName} accepted your request`,
                        )}
                  </strong>
                  <small>{time(item.createdAt)}</small>
                </button>
                <button
                  className="activity-remove"
                  aria-label={t("Удалить уведомление", "Delete notification")}
                  disabled={change.isPending}
                  onClick={() =>
                    change.mutate({
                      path: `/notifications/${item.id}`,
                      method: "DELETE",
                    })
                  }
                >
                  <Trash2 size={17} />
                </button>
              </motion.article>
            ))}
          </div>
        ) : (
          <div className="social-empty">
            <span className="system-emoji" aria-hidden="true">
              ✨
            </span>
            <h2>{t("Пока всё спокойно", "All caught up")}</h2>
            <p>
              {t(
                "Здесь появятся новые заявки и ответы друзей.",
                "New requests and friend updates will appear here.",
              )}
            </p>
            <button
              className="button primary"
              onClick={() => navigate("friends")}
            >
              <Users size={17} />
              {t("Найти друзей", "Find friends")}
            </button>
          </div>
        )}
        {change.isError && (
          <p className="error" role="alert">
            {errorText(change.error, language === "ru")}
          </p>
        )}
      </section>
    </>
  );
}
