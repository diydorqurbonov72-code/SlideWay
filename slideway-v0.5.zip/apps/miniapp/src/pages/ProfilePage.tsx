import { Check,ShieldCheck,SlidersHorizontal,Sparkles } from "lucide-react";
import { useState } from "react";
import { Profile } from "../api";
import { useApp } from "../state";

import {
Feedback,
Heading,
QuickLink,
useSave,
useText,
} from "../components/shared";
export default function ProfilePage({ me }: { me: Profile }) {
  const t = useText();
  const [name, setName] = useState(me.displayName),
    [bio, setBio] = useState(me.bio);
  const mutation = useSave();
  return (
    <>
      <Heading
        eyebrow="YOUR IDENTITY"
        title={t("Больше, чем имя.", "More than a name.")}
        description={t(
          "Пусть профиль расскажет твою историю.",
          "Let your profile tell your story.",
        )}
      />
      <div className="profile-layout">
        <section className="panel profile-preview">
          <div className="avatar large">
            {me.displayName.slice(0, 1).toUpperCase()}
          </div>
          <h2>{me.displayName}</h2>
          <p className="bio-preview">
            {me.bio || t("Здесь будет твоя история.", "Your story goes here.")}
          </p>
          <span className="pill">
            <ShieldCheck size={14} />
            {t("Личное пространство", "Personal space")}
          </span>
          <div className="joined">
            {t("С нами с", "Joined")}{" "}
            {new Date(me.createdAt).toLocaleDateString(
              useApp.getState().language,
              { month: "long", year: "numeric" },
            )}
          </div>
        </section>
        <form
          className="panel form"
          onSubmit={(e) => {
            e.preventDefault();
            if (name.trim())
              mutation.mutate({ displayName: name.trim(), bio: bio.trim() });
          }}
        >
          <h2>{t("Детали профиля", "Profile details")}</h2>
          <label htmlFor="display-name">
            {t("Отображаемое имя", "Display name")}
          </label>
          <input
            id="display-name"
            value={name}
            required
            maxLength={80}
            onChange={(e) => {
              setName(e.target.value);
              mutation.reset();
            }}
            autoComplete="nickname"
          />
          <label htmlFor="bio">{t("О себе", "About you")}</label>
          <textarea
            id="bio"
            value={bio}
            maxLength={280}
            rows={4}
            placeholder={t("Что тебя вдохновляет?", "What inspires you?")}
            onChange={(e) => {
              setBio(e.target.value);
              mutation.reset();
            }}
          />
          <small className="counter">{bio.length}/280</small>
          <button
            className="button primary"
            disabled={mutation.isPending || !name.trim()}
          >
            {mutation.isPending
              ? t("Сохраняем…", "Saving…")
              : t("Сохранить изменения", "Save changes")}
            <Check size={18} />
          </button>
          <Feedback mutation={mutation} />
        </form>
      </div>
      <div className="quick-links">
        <QuickLink
          icon={Sparkles}
          title={t("Мои интересы", "My interests")}
          detail={t(
            `${me.interests.length} выбрано`,
            `${me.interests.length} selected`,
          )}
          page="interests"
        />
        <QuickLink
          icon={ShieldCheck}
          title={t("Приватность", "Privacy")}
          detail={t("Твои границы", "Your boundaries")}
          page="privacy"
        />
        <QuickLink
          icon={SlidersHorizontal}
          title={t("Настройки", "Settings")}
          detail={t("Язык и сессии", "Language and sessions")}
          page="settings"
        />
      </div>
    </>
  );
}
