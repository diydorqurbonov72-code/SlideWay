import * as Dialog from "@radix-ui/react-dialog";
import { useMutation } from "@tanstack/react-query";
import { Monitor,ShieldCheck,Trash2 } from "lucide-react";
import { useState } from "react";
import { api,Profile } from "../api";
import { useApp } from "../state";

import {
errorText,
Feedback,
Heading,
QuickLink,
useSave,
useText,
} from "../components/shared";
import { client } from "../query-client";
export default function SettingsPage({ me }: { me: Profile }) {
  const t = useText();
  const mutation = useSave();
  const [deleting, setDeleting] = useState(false);
  const [confirm, setConfirm] = useState("");
  const del = useMutation({
    mutationFn: () => api("/me", "DELETE", { confirmation: "DELETE" }),
    onSuccess: () => {
      client.clear();
      useApp.setState({ token: null, phase: "signedout" });
    },
  });
  return (
    <>
      <Heading
        eyebrow="MAKE IT COMFORTABLE"
        title={t("По-твоему.", "Your way.")}
        description={t(
          "Маленькие настройки, большое удобство.",
          "Small preferences. A better experience.",
        )}
      />
      <section className="panel">
        <label className="setting-row">
          <span>
            <strong>{t("Язык интерфейса", "App language")}</strong>
            <small>{t("Русский или English", "Russian or English")}</small>
          </span>
          <select
            aria-label={t("Язык интерфейса", "App language")}
            value={me.locale === "ru" ? "ru" : "en"}
            disabled={mutation.isPending}
            onChange={(e) => mutation.mutate({ locale: e.target.value })}
          >
            <option value="ru">Русский</option>
            <option value="en">English</option>
          </select>
        </label>
        <label className="setting-row">
          <span>
            <strong>{t("Оформление", "Appearance")}</strong>
            <small>
              {t(
                "Авто — следовать теме Telegram",
                "Auto follows your Telegram theme",
              )}
            </small>
          </span>
          <select
            aria-label={t("Оформление", "Appearance")}
            value={useApp((s) => s.theme)}
            onChange={(e) =>
              useApp.setState({
                theme: e.target.value as "auto" | "dark" | "light",
              })
            }
          >
            <option value="auto">{t("Авто", "Auto")}</option>
            <option value="dark">{t("Тёмное", "Dark")}</option>
            <option value="light">{t("Светлое", "Light")}</option>
          </select>
        </label>
        <Feedback mutation={mutation} />
      </section>
      <div className="quick-links two">
        <QuickLink
          icon={Monitor}
          title={t("Активные сессии", "Active sessions")}
          detail={t("Управляй доступом", "Manage access")}
          page="sessions"
        />
        <QuickLink
          icon={ShieldCheck}
          title={t("Приватность", "Privacy")}
          detail={t("Настройки видимости", "Visibility settings")}
          page="privacy"
        />
      </div>
      <div className="danger-zone">
        <div>
          <h3>{t("Удаление аккаунта", "Delete account")}</h3>
          <p>
            {t(
              "Профиль, интересы и все сессии будут удалены.",
              "Your profile, interests and all sessions will be deleted.",
            )}
          </p>
        </div>
        <Dialog.Root
          open={deleting}
          onOpenChange={(open) => {
            if (!del.isPending) {
              setDeleting(open);
              setConfirm("");
              del.reset();
            }
          }}
        >
          <Dialog.Trigger asChild>
            <button className="button danger">
              <Trash2 size={17} />
              {t("Удалить аккаунт", "Delete account")}
            </button>
          </Dialog.Trigger>
          <Dialog.Portal>
            <Dialog.Overlay className="dialog-overlay" />
            <Dialog.Content className="dialog">
              <Dialog.Title>
                {t(
                  "Удалить аккаунт навсегда?",
                  "Permanently delete your account?",
                )}
              </Dialog.Title>
              <Dialog.Description>
                {t(
                  "Это действие нельзя отменить. Для подтверждения введи DELETE. Вход должен быть выполнен не более пяти минут назад.",
                  "This cannot be undone. Type DELETE to confirm. You must have signed in within the last five minutes.",
                )}
              </Dialog.Description>
              <label htmlFor="delete-confirm">
                {t("Подтверждение", "Confirmation")}
              </label>
              <input
                id="delete-confirm"
                value={confirm}
                onChange={(e) => setConfirm(e.target.value)}
                autoComplete="off"
              />
              {del.isError && (
                <p role="alert" className="error">
                  {errorText(del.error, useApp.getState().language === "ru")}
                </p>
              )}
              <div className="dialog-actions">
                <Dialog.Close asChild>
                  <button className="button secondary" disabled={del.isPending}>
                    {t("Отмена", "Cancel")}
                  </button>
                </Dialog.Close>
                <button
                  className="button danger"
                  disabled={confirm !== "DELETE" || del.isPending}
                  onClick={() => del.mutate()}
                >
                  {del.isPending
                    ? t("Удаляем…", "Deleting…")
                    : t("Удалить навсегда", "Delete permanently")}
                </button>
              </div>
            </Dialog.Content>
          </Dialog.Portal>
        </Dialog.Root>
      </div>
    </>
  );
}
