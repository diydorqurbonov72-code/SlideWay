import { useQuery } from "@tanstack/react-query";
import { Check } from "lucide-react";
import { useState } from "react";
import { api,Interest,Profile } from "../api";
import { useApp } from "../state";

import {
errorText,
Feedback,
Heading,
Loading,
useSave,
useText,
} from "../components/shared";
export default function InterestsPage({ me }: { me: Profile }) {
  const t = useText();
  const query = useQuery({
    queryKey: ["interests"],
    queryFn: () => api<Interest[]>("/interests"),
  });
  const [selected, setSelected] = useState(
    me.interests.map((x) => x.interestKey),
  );
  const mutation = useSave();
  return (
    <>
      <Heading
        eyebrow="FIND YOUR THING"
        title={t("Что тебя увлекает?", "What’s your thing?")}
        description={t(
          "Выбери до восьми интересов. Их всегда можно изменить.",
          "Choose up to eight interests. You can change them anytime.",
        )}
      />
      <section className="panel">
        {query.isPending ? (
          <Loading />
        ) : query.isError ? (
          <div role="alert">
            {errorText(query.error, useApp.getState().language === "ru")}
            <button
              className="button secondary"
              onClick={() => query.refetch()}
            >
              {t("Повторить", "Try again")}
            </button>
          </div>
        ) : (
          <>
            <div className="interest-grid">
              {query.data.map((i) => (
                <button
                  key={i.key}
                  aria-pressed={selected.includes(i.key)}
                  className={
                    "interest " + (selected.includes(i.key) ? "selected" : "")
                  }
                  onClick={() => {
                    setSelected((x) =>
                      x.includes(i.key)
                        ? x.filter((k) => k !== i.key)
                        : x.length < 8
                          ? [...x, i.key]
                          : x,
                    );
                    mutation.reset();
                  }}
                >
                  <span>{t(i.nameRu, i.nameEn)}</span>
                  <span className="check-circle">
                    {selected.includes(i.key) && <Check size={16} />}
                  </span>
                </button>
              ))}
            </div>
            <div className="form-footer">
              <span>
                {selected.length}/8 {t("выбрано", "selected")}
              </span>
              <button
                className="button primary"
                disabled={mutation.isPending}
                onClick={() => mutation.mutate({ interests: selected })}
              >
                {mutation.isPending
                  ? t("Сохраняем…", "Saving…")
                  : t("Сохранить интересы", "Save interests")}
                <Check size={18} />
              </button>
            </div>
            <Feedback mutation={mutation} />
          </>
        )}
      </section>
    </>
  );
}
