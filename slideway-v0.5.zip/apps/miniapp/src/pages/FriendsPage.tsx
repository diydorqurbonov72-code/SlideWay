import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { motion, useReducedMotion } from "framer-motion";
import { Search, UserPlus, Check, X, ShieldOff } from "lucide-react";
import { api, Profile } from "../api";
import { Heading, Loading, useText, errorText } from "../components/shared";
import { useApp, navigate } from "../state";
interface Person {
  id: string;
  displayName: string;
  bio?: string;
  settings?: { allowFriendRequests: boolean };
}
interface Relation {
  id: string;
  user: Person;
}
interface Social {
  friends: Relation[];
  incoming: Relation[];
  outgoing: Relation[];
  blocked: Person[];
}
export default function FriendsPage({ me }: { me: Profile }) {
  const t = useText(),
    qc = useQueryClient(),
    reduce = useReducedMotion();
  const [tab, setTab] = useState("friends"),
    [draft, setDraft] = useState(""),
    [search, setSearch] = useState(""),
    [notice, setNotice] = useState("");
  const data = useQuery({
    queryKey: ["friends"],
    staleTime: 0,
    refetchOnMount: "always",
    refetchInterval: 15000,
    queryFn: () => api<Social>("/friends"),
  });
  const found = useQuery({
    queryKey: ["people", search],
    queryFn: () =>
      api<Person[]>("/friends/search?q=" + encodeURIComponent(search)),
    enabled: search.length >= 2,
  });
  const change = useMutation({
    mutationFn: ({
      path,
      method = "POST",
      body,
    }: {
      path: string;
      method?: string;
      body?: unknown;
    }) => api(path, method, body),
    onSuccess: () => {
      setNotice(t("Готово. Изменения сохранены.", "Done. Changes saved."));
      void qc.invalidateQueries({ queryKey: ["friends"] });
      void qc.invalidateQueries({ queryKey: ["people"] });
      void qc.invalidateQueries({ queryKey: ["notifications"] });
    },
  });
  const submit = (path: string, method = "POST", body?: unknown) => {
    setNotice("");
    change.mutate({ path, method, body });
  };
  const tabs = [
    ["friends", t("Мои друзья", "My friends")],
    ["search", t("Найти", "Discover")],
    ["requests", t("Заявки", "Requests")],
    ["blocked", t("Блокировки", "Blocked")],
  ];
  const row = (person: Person, actions: React.ReactNode) => (
    <motion.div
      className="person-row"
      key={person.id}
      initial={reduce ? false : { opacity: 0, transform: "translateY(6px)" }}
      animate={{ opacity: 1, transform: "translateY(0)" }}
      transition={{ duration: 0.18, ease: [0.23, 1, 0.32, 1] }}
    >
      <span className="avatar" aria-hidden="true">
        {person.displayName.slice(0, 1)}
      </span>
      <div className="person-info">
        <h3>{person.displayName}</h3>
        {person.bio && <p>{person.bio}</p>}
      </div>
      <div className="person-actions">{actions}</div>
    </motion.div>
  );
  const empty = (text: string) => (
    <div className="social-empty">
      <span className="system-emoji" aria-hidden="true">
        🤝
      </span>
      <h2>{text}</h2>
      <p>
        {t(
          "Знакомства начинаются с простого приветствия. Найди знакомого по имени и отправь заявку.",
          "Find someone you know by name and send a friend request.",
        )}
      </p>
    </div>
  );
  return (
    <>
      <Heading
        eyebrow="BETTER TOGETHER"
        title={t("Свои люди.", "Your people.")}
        description={t(
          "Находи знакомых. Выбирай, с кем общаться.",
          "Find your people. Choose who you connect with.",
        )}
      />
      <div
        className="social-tabs"
        aria-label={t("Разделы друзей", "Friends sections")}
      >
        {tabs.map(([key, label]) => (
          <button
            key={key}
            aria-pressed={tab === key}
            onClick={() => {
              setTab(key);
              change.reset();
              setNotice("");
            }}
          >
            {label}
            {key === "requests" && data.data?.incoming.length
              ? " · " + data.data.incoming.length
              : ""}
          </button>
        ))}
      </div>
      {!me.settings.profileVisible && (
        <div className="info-note">
          <span className="system-emoji" aria-hidden="true">
            🔒
          </span>
          <p>
            {t(
              "Твой профиль скрыт из поиска. Видимость и получение заявок можно включить в приватности.",
              "Your profile is hidden from search. Enable visibility and friend requests in privacy settings.",
            )}{" "}
            <button className="text-button" onClick={() => navigate("privacy")}>
              {t("Настроить", "Manage")}
            </button>
          </p>
        </div>
      )}
      <section className="panel">
        {data.isPending ? (
          <Loading />
        ) : data.isError ? (
          <div role="alert">
            {errorText(data.error, useApp.getState().language === "ru")}
            <button className="button secondary" onClick={() => data.refetch()}>
              {t("Повторить", "Retry")}
            </button>
          </div>
        ) : (
          <>
            {tab === "friends" &&
              (data.data.friends.length
                ? data.data.friends.map((r) =>
                    row(
                      r.user,
                      <>
                        <button
                          className="button secondary"
                          disabled={change.isPending}
                          onClick={() => submit("/friends/" + r.id, "DELETE")}
                        >
                          {t("Удалить из друзей", "Remove friend")}
                        </button>
                        <button
                          className="button danger"
                          disabled={change.isPending}
                          onClick={() => submit("/friends/blocks/" + r.user.id)}
                        >
                          {t("Заблокировать", "Block")}
                        </button>
                      </>,
                    ),
                  )
                : empty(
                    t(
                      "Здесь будут твои друзья",
                      "Your friends will appear here",
                    ),
                  ))}
            {tab === "search" && (
              <>
                <form
                  className="people-search"
                  onSubmit={(e) => {
                    e.preventDefault();
                    setSearch(draft.trim());
                  }}
                >
                  <label className="sr-only" htmlFor="people-search">
                    {t("Поиск участников", "Search people")}
                  </label>
                  <input
                    id="people-search"
                    value={draft}
                    onChange={(e) => setDraft(e.target.value)}
                    minLength={2}
                    maxLength={64}
                    required
                    autoComplete="off"
                    placeholder={t("Имя или username…", "Name or username…")}
                  />
                  <button className="button primary">
                    <Search size={17} />
                    {t("Найти", "Search")}
                  </button>
                </form>
                {!search ? (
                  empty(t("Кого ищем?", "Who are you looking for?"))
                ) : found.isPending ? (
                  <Loading />
                ) : found.isError ? (
                  <p role="alert" className="error">
                    {errorText(
                      found.error,
                      useApp.getState().language === "ru",
                    )}
                  </p>
                ) : found.data?.length ? (
                  found.data.map((person) => {
                    const sent = data.data.outgoing.some(
                        (r) => r.user.id === person.id,
                      ),
                      friend = data.data.friends.some(
                        (r) => r.user.id === person.id,
                      ),
                      incoming = data.data.incoming.some(
                        (r) => r.user.id === person.id,
                      );
                    return row(
                      person,
                      <>
                        <button
                          className="button primary"
                          disabled={
                            change.isPending ||
                            sent ||
                            friend ||
                            incoming ||
                            !person.settings?.allowFriendRequests
                          }
                          onClick={() =>
                            submit("/friends/requests", "POST", {
                              userId: person.id,
                            })
                          }
                        >
                          <UserPlus size={16} />
                          {friend
                            ? t("В друзьях", "Friends")
                            : sent
                              ? t("Заявка отправлена", "Request sent")
                              : incoming
                                ? t("Есть входящая заявка", "Incoming request")
                                : !person.settings?.allowFriendRequests
                                  ? t("Заявки закрыты", "Requests off")
                                  : t("Добавить", "Add friend")}
                        </button>
                        <button
                          className="button secondary"
                          disabled={change.isPending}
                          onClick={() => submit("/friends/blocks/" + person.id)}
                        >
                          {t("Блокировать", "Block")}
                        </button>
                      </>,
                    );
                  })
                ) : (
                  empty(t("Никого не нашли", "No matches"))
                )}
              </>
            )}
            {tab === "requests" && (
              <>
                <h2>{t("Входящие", "Incoming")}</h2>
                {data.data.incoming.length
                  ? data.data.incoming.map((r) =>
                      row(
                        r.user,
                        <>
                          <button
                            className="button primary"
                            disabled={change.isPending}
                            onClick={() =>
                              submit("/friends/requests/" + r.id + "/accept")
                            }
                          >
                            <Check size={16} />
                            {t("Принять", "Accept")}
                          </button>
                          <button
                            className="button secondary"
                            disabled={change.isPending}
                            onClick={() => submit("/friends/" + r.id, "DELETE")}
                          >
                            <X size={16} />
                            {t("Отклонить", "Decline")}
                          </button>
                          <button
                            className="button danger"
                            disabled={change.isPending}
                            onClick={() =>
                              submit("/friends/blocks/" + r.user.id)
                            }
                          >
                            {t("Блокировать", "Block")}
                          </button>
                        </>,
                      ),
                    )
                  : empty(t("Новых заявок нет", "No new requests"))}
                <h2>{t("Отправленные", "Sent")}</h2>
                {data.data.outgoing.map((r) =>
                  row(
                    r.user,
                    <button
                      className="button secondary"
                      disabled={change.isPending}
                      onClick={() => submit("/friends/" + r.id, "DELETE")}
                    >
                      {t("Отменить заявку", "Cancel request")}
                    </button>,
                  ),
                )}
              </>
            )}
            {tab === "blocked" &&
              (data.data.blocked.length
                ? data.data.blocked.map((person) =>
                    row(
                      person,
                      <button
                        className="button secondary"
                        disabled={change.isPending}
                        onClick={() =>
                          submit("/friends/blocks/" + person.id, "DELETE")
                        }
                      >
                        <ShieldOff size={16} />
                        {t("Разблокировать", "Unblock")}
                      </button>,
                    ),
                  )
                : empty(
                    t("Нет заблокированных пользователей", "No blocked users"),
                  ))}
          </>
        )}
        <div className="social-notice" role="status">
          {notice}
        </div>
        {change.isError && (
          <p className="error" role="alert">
            {errorText(change.error, useApp.getState().language === "ru")}
          </p>
        )}
      </section>
    </>
  );
}
