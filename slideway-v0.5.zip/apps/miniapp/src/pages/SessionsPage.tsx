import { useMutation,useQuery,useQueryClient } from "@tanstack/react-query";
import { LogOut,Monitor } from "lucide-react";
import { api,Session } from "../api";
import { useApp } from "../state";

import { errorText,Heading,Loading,useText } from "../components/shared";
export default function SessionsPage() {
  const t = useText();
  const qc = useQueryClient();
  const q = useQuery({
    queryKey: ["sessions"],
    queryFn: () => api<Session[]>("/me/sessions"),
  });
  const mutation = useMutation({
    mutationFn: ({ id }: { id?: string; current?: boolean }) =>
      api("/me/sessions" + (id ? "/" + id : ""), "DELETE"),
    onSuccess: (_, vars) => {
      if (!vars.id || vars.current) {
        qc.clear();
        useApp.setState({ token: null, phase: "signedout" });
      } else void qc.invalidateQueries({ queryKey: ["sessions"] });
    },
  });
  return (
    <>
      <Heading
        eyebrow="STAY IN CONTROL"
        title={t("Твои сессии.", "Your sessions.")}
        description={t(
          "Заверши доступ, который больше не нужен.",
          "End access you no longer need.",
        )}
      />
      <section className="panel">
        {q.isPending ? (
          <Loading />
        ) : q.isError ? (
          <div role="alert">
            {errorText(q.error, useApp.getState().language === "ru")}
            <button className="button secondary" onClick={() => q.refetch()}>
              {t("Повторить", "Try again")}
            </button>
          </div>
        ) : (
          <>
            {q.data.map((s) => (
              <div className="session-row" key={s.id}>
                <span className="tile-icon">
                  <Monitor size={21} />
                </span>
                <div>
                  <strong>
                    {s.current
                      ? t("Текущая сессия", "Current session")
                      : t("Сессия Telegram", "Telegram session")}
                  </strong>
                  <small>
                    {t("Вход:", "Signed in:")}{" "}
                    {new Date(s.createdAt).toLocaleString(
                      useApp.getState().language,
                    )}
                  </small>
                  <small>
                    {t("Истекает:", "Expires:")}{" "}
                    {new Date(s.expiresAt).toLocaleString(
                      useApp.getState().language,
                    )}
                  </small>
                </div>
                <button
                  className="button secondary"
                  disabled={mutation.isPending}
                  onClick={() =>
                    mutation.mutate({ id: s.id, current: s.current })
                  }
                >
                  {s.current
                    ? t("Выйти", "Sign out")
                    : t("Завершить", "Revoke")}
                </button>
              </div>
            ))}
            <div className="form-footer">
              <button
                className="button danger"
                disabled={mutation.isPending}
                onClick={() => mutation.mutate({})}
              >
                <LogOut size={17} />
                {t("Выйти из всех сессий", "Sign out everywhere")}
              </button>
            </div>
          </>
        )}
        {mutation.isError && (
          <p className="error" role="alert">
            {errorText(mutation.error, useApp.getState().language === "ru")}
          </p>
        )}
      </section>
    </>
  );
}
