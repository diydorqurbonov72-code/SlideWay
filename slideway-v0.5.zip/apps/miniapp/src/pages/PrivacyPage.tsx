import { Check, ShieldCheck } from "lucide-react";
import { useState } from "react";
import { Profile, Settings } from "../api";

import { Feedback, Heading, useSave, useText } from "../components/shared";
export default function PrivacyPage({ me }: { me: Profile }) {
  const t = useText();
  const [settings, setSettings] = useState(me.settings);
  const mutation = useSave();
  const rows: {
    key: keyof Settings;
    ru: string;
    en: string;
    descRu: string;
    descEn: string;
  }[] = [
    {
      key: "profileVisible",
      ru: "Видимость профиля",
      en: "Profile visibility",
      descRu: "Разрешить показывать профиль другим участникам.",
      descEn: "Allow other members to see your profile.",
    },
    {
      key: "showActivity",
      ru: "Статус активности",
      en: "Activity status",
      descRu: "Разрешить показывать, когда ты в сети.",
      descEn: "Allow others to see when you are online.",
    },
    {
      key: "showAchievements",
      ru: "Достижения",
      en: "Achievements",
      descRu: "Разрешить показывать игровые достижения.",
      descEn: "Allow others to see game achievements.",
    },
    {
      key: "allowFriendRequests",
      ru: "Запросы в друзья",
      en: "Friend requests",
      descRu: "Разрешить новым людям отправлять запросы.",
      descEn: "Allow new people to send friend requests.",
    },
    {
      key: "notifications",
      ru: "Уведомления",
      en: "Notifications",
      descRu: "Разрешить будущие уведомления об активности.",
      descEn: "Allow future activity notifications.",
    },
  ];
  return (
    <>
      <Heading
        eyebrow="YOUR SPACE, YOUR RULES"
        title={t("Приватность — это выбор.", "Privacy is a choice.")}
        description={t(
          "Ты решаешь, чем делиться. Все разрешения изначально выключены.",
          "You decide what to share. All permissions start off.",
        )}
      />
      <div className="info-note">
        <ShieldCheck size={22} />
        <p>
          {t(
            "Настройки сохраняются уже сейчас. Видимость управляет поиском участников. Достижения и уведомления появятся позднее.",
            "Your preferences are saved now. Visibility controls people search. Achievements and notifications are coming later.",
          )}
        </p>
      </div>
      <section className="panel">
        {rows.map((row) => (
          <label className="setting-row" key={row.key}>
            <span>
              <strong>{t(row.ru, row.en)}</strong>
              <small>{t(row.descRu, row.descEn)}</small>
            </span>
            <input
              type="checkbox"
              className="switch"
              checked={settings[row.key]}
              onChange={(e) => {
                setSettings({ ...settings, [row.key]: e.target.checked });
                mutation.reset();
              }}
            />
          </label>
        ))}
        <div className="form-footer">
          <button
            className="button primary"
            disabled={mutation.isPending}
            onClick={() => mutation.mutate({ settings })}
          >
            {mutation.isPending
              ? t("Сохраняем…", "Saving…")
              : t("Сохранить настройки", "Save preferences")}
            <Check size={18} />
          </button>
        </div>
        <Feedback mutation={mutation} />
      </section>
    </>
  );
}
