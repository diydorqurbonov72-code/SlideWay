import { ArrowRight,Compass,Gamepad2,Users } from "lucide-react";
import { navigate,Page } from "../state";

import { useText } from "../components/shared";
export default function Upcoming({ page }: { page: Page }) {
  const t = useText();
  const info =
    page === "games"
      ? {
          Icon: Gamepad2,
          ru: "Твоя следующая победа.",
          en: "Your next great win.",
          descRu:
            "Quiz Battle, Memory Clash и другие игры готовятся к запуску. Сейчас можно подготовить профиль и выбрать интересы.",
          descEn:
            "Quiz Battle, Memory Clash and more are on their way. For now, set up your profile and interests.",
        }
      : page === "friends"
        ? {
            Icon: Users,
            ru: "Свои люди. Общие интересы.",
            en: "Your people. Shared interests.",
            descRu:
              "Заявки и поиск друзей ещё в разработке. Выбери интересы — это первый шаг к будущим знакомствам.",
            descEn:
              "Friend requests and discovery are still in development. Choosing your interests is the first step.",
          }
        : {
            Icon: Compass,
            ru: "Место для твоих увлечений.",
            en: "A home for your passions.",
            descRu:
              "Комнаты и управление сообществами ещё в разработке. Здесь появятся настоящие сообщества после запуска модуля.",
            descEn:
              "Rooms and community management are still in development. Real communities will appear when the module launches.",
          };
  return (
    <section className="upcoming panel">
      <span className="pill muted">{t("В разработке", "In development")}</span>
      <div className="upcoming-icon">
        <info.Icon size={56} strokeWidth={1.3} />
      </div>
      <h1>{t(info.ru, info.en)}</h1>
      <p>{t(info.descRu, info.descEn)}</p>
      <button className="button primary" onClick={() => navigate("interests")}>
        {t("Настроить интересы", "Choose your interests")}
        <ArrowRight size={18} />
      </button>
    </section>
  );
}
