import {
  ArrowUpRight,
  ChevronRight,
  Gamepad2,
  Heart,
  ShieldCheck,
  Sparkles,
  UserRound,
} from "lucide-react";
import { Profile } from "../api";
import { navigate } from "../state";

import { useText } from "../components/shared";
export default function Dashboard({ me }: { me: Profile }) {
  const t = useText();
  const completion = [
    !!me.displayName,
    !!me.bio,
    me.interests.length > 0,
  ].filter(Boolean).length;
  return (
    <>
      <div className="greeting">
        <div>
          <div className="eyebrow">WELCOME TO YOUR SPACE</div>
          <h1>
            {t("Привет,", "Hey,")} {me.displayName.split(" ")[0]}
            <span className="accent">.</span>
          </h1>
          <p>
            {t(
              "Большие истории начинаются с тебя.",
              "Every great story starts with you.",
            )}
          </p>
        </div>
        <button
          className="avatar"
          onClick={() => navigate("profile")}
          aria-label={t("Открыть профиль", "Open profile")}
        >
          {me.displayName.slice(0, 1).toUpperCase()}
        </button>
      </div>
      <section className="hero-card">
        <div className="hero-copy">
          <span className="pill">
            <span className="status-dot" />
            {t("Твоё пространство", "Your personal space")}
          </span>
          <h2>
            {t("Меньше шума.", "Less noise.")}
            <br />
            {t("Больше тебя.", "More you.")}
          </h2>
          <p>
            {t(
              "Расскажи о себе и выбери то, что тебя увлекает. Так начинается твоя история в SlideWay.",
              "Tell your story and choose what inspires you. Your SlideWay journey starts here.",
            )}
          </p>
          <button
            className="button light"
            onClick={() => navigate("interests")}
          >
            {t("Выбрать интересы", "Choose your interests")}
            <ArrowUpRight size={18} />
          </button>
        </div>
        <div className="hero-visual" aria-hidden="true">
          <span className="planet-orbit" />
          <div className="planet">
            <span className="planet-face">
              <span />
              <span />
            </span>
            <span className="planet-smile" />
          </div>
          <span className="mini-orb first">
            <span className="system-emoji">🖤</span>
          </span>
          <span className="mini-orb second">
            <span className="system-emoji">✨</span>
          </span>
          <span className="visual-caption">MAKE IT YOURS</span>
        </div>
      </section>
      <div className="section-heading">
        <h2>{t("Начни с главного", "Make yourself at home")}</h2>
        <span>{t("Твой старт", "Your starting point")}</span>
      </div>
      <div className="starter-grid">
        <button className="action-card" onClick={() => navigate("profile")}>
          <span className="tile-icon purple">
            <UserRound />
          </span>
          <div>
            <h3>{t("Твой профиль", "Your profile")}</h3>
            <p>{t("Добавь немного себя", "Add a little personality")}</p>
          </div>
          <ChevronRight size={18} />
          <div className="progress-track">
            <span style={{ width: `${(completion / 3) * 100}%` }} />
          </div>
          <small>
            {t(
              `${completion} из 3 шагов выполнено`,
              `${completion} of 3 steps complete`,
            )}
          </small>
        </button>
        <button className="action-card" onClick={() => navigate("privacy")}>
          <span className="tile-icon teal">
            <ShieldCheck />
          </span>
          <div>
            <h3>{t("Под твоим контролем", "You’re in control")}</h3>
            <p>{t("Приватность и видимость", "Privacy and visibility")}</p>
          </div>
          <ChevronRight size={18} />
          <div className="privacy-note">
            <span className="status-dot" />
            {me.settings.profileVisible
              ? t("Видимость профиля разрешена", "Profile visibility allowed")
              : t("Профиль закрыт по умолчанию", "Your profile stays private")}
          </div>
        </button>
      </div>
      <section className="next-card">
        <div className="tile-icon amber">
          <Gamepad2 />
        </div>
        <div>
          <div className="eyebrow">NEXT UP</div>
          <h3>{t("Всё начинается здесь", "This is just the beginning")}</h3>
          <p>
            {t(
              "Находи друзей во вкладке «Друзья». Игры и сообщества появятся в следующих обновлениях.",
              "Find your people in Friends. Games and communities are coming in future updates.",
            )}
          </p>
          <button className="button light" onClick={() => navigate("friends")}>
            {t("Открыть друзей", "Open friends")}
            <ArrowUpRight size={17} />
          </button>
        </div>
        <span className="pill muted">
          {t("В разработке", "In development")}
        </span>
      </section>
      <div className="quiet-footer">
        SLIDEWAY <span>PLAY. CONNECT. LEVEL UP.</span>
      </div>
    </>
  );
}
