import { useQuery } from "@tanstack/react-query";
import { motion, useReducedMotion } from "framer-motion";
import {
  ArrowLeft,
  Bell,
  Compass,
  Gamepad2,
  Home,
  Moon,
  SlidersHorizontal,
  Sun,
  UserRound,
  Users,
} from "lucide-react";
import { lazy, Suspense, useEffect } from "react";
import { api, bootstrap, Profile } from "./api";
import {
  Brand,
  errorText,
  IconButton,
  Loading,
  useText,
} from "./components/shared";
import Dashboard from "./pages/Dashboard";
import Gate from "./pages/Gate";
import { navigate, Page, useApp } from "./state";
import { telegram } from "./telegram";
const FriendsPage = lazy(() => import("./pages/FriendsPage"));
const NotificationsPage = lazy(() => import("./pages/NotificationsPage"));
const ProfilePage = lazy(() => import("./pages/ProfilePage"));
const InterestsPage = lazy(() => import("./pages/InterestsPage"));
const PrivacyPage = lazy(() => import("./pages/PrivacyPage"));
const SettingsPage = lazy(() => import("./pages/SettingsPage"));
const SessionsPage = lazy(() => import("./pages/SessionsPage"));
const Upcoming = lazy(() => import("./pages/Upcoming"));
export default function App() {
  const { phase, page, theme, language } = useApp();
  const t = useText();
  const reduce = useReducedMotion();
  const social = useQuery({
    queryKey: ["friends"],
    queryFn: () => api<{ incoming: unknown[] }>("/friends"),
    enabled: phase === "ready",
    staleTime: 0,
    refetchInterval: 15_000,
  });
  const activity = useQuery({
    queryKey: ["notifications"],
    queryFn: () => api<{ unread: number }>("/notifications"),
    enabled: phase === "ready",
    staleTime: 0,
    refetchInterval: 15_000,
  });
  useEffect(() => {
    void bootstrap();
  }, []);
  useEffect(() => {
    const tg = telegram();
    const update = () => {
      document.documentElement.dataset.theme =
        theme === "auto" ? (tg?.colorScheme ?? "dark") : theme;
      document.documentElement.style.setProperty(
        "--tg-top",
        `${(tg?.safeAreaInset?.top ?? 0) + (tg?.contentSafeAreaInset?.top ?? 0)}px`,
      );
      document.documentElement.style.setProperty(
        "--tg-bottom",
        `${tg?.safeAreaInset?.bottom ?? 0}px`,
      );
    };
    update();
    tg?.onEvent("themeChanged", update);
    tg?.onEvent("safeAreaChanged", update);
    return () => {
      tg?.offEvent("themeChanged", update);
      tg?.offEvent("safeAreaChanged", update);
    };
  }, [theme]);
  useEffect(() => {
    document.documentElement.lang = language;
  }, [language]);
  useEffect(() => {
    const back = () => navigate("home");
    const b = telegram()?.BackButton;
    if (page === "home") b?.hide();
    else b?.show();
    b?.onClick(back);
    return () => b?.offClick(back);
  }, [page]);
  useEffect(() => {
    const listener = () => {
      const raw = location.hash.slice(1);
      if (
        [
          "home",
          "games",
          "communities",
          "friends",
          "profile",
          "interests",
          "privacy",
          "settings",
          "sessions",
          "notifications",
        ].includes(raw)
      )
        useApp.setState({ page: raw as Page });
    };
    window.addEventListener("hashchange", listener);
    return () => window.removeEventListener("hashchange", listener);
  }, []);
  if (phase === "loading") return <Loading />;
  if (phase !== "ready") return <Gate />;
  return (
    <div className="shell">
      <a className="skip-link" href="#main">
        {t("Перейти к содержимому", "Skip to content")}
      </a>
      <header className="header">
        <Brand />
        <div className="header-actions">
          <span className="edition">PERSONAL SPACE</span>
          <button
            className="icon-button activity-trigger"
            aria-label={
              activity.data?.unread
                ? t(
                    `Уведомления · ${activity.data.unread}`,
                    `Notifications · ${activity.data.unread}`,
                  )
                : t("Уведомления", "Notifications")
            }
            onClick={() => navigate("notifications")}
          >
            <Bell size={20} />
            {!!activity.data?.unread && (
              <span className="activity-badge" aria-hidden="true">
                {activity.data.unread > 9 ? "9+" : activity.data.unread}
              </span>
            )}
          </button>
          <IconButton
            icon={theme === "light" ? Moon : Sun}
            label={t("Сменить тему", "Change theme")}
            onClick={() =>
              useApp.setState({
                theme:
                  document.documentElement.dataset.theme === "dark"
                    ? "light"
                    : "dark",
              })
            }
          />
          <IconButton
            icon={SlidersHorizontal}
            label={t("Настройки", "Settings")}
            onClick={() => navigate("settings")}
          />
        </div>
      </header>
      <main id="main" tabIndex={-1}>
        <motion.div
          key={page}
          initial={
            reduce
              ? false
              : { opacity: 0, transform: "translateY(10px) scale(.99)" }
          }
          animate={{ opacity: 1, transform: "translateY(0) scale(1)" }}
          transition={{ duration: 0.22, ease: [0.23, 1, 0.32, 1] }}
        >
          {!["home", "games", "communities", "friends", "profile"].includes(
            page,
          ) && (
            <button
              className="back"
              onClick={() =>
                navigate(page === "notifications" ? "home" : "profile")
              }
            >
              <ArrowLeft size={17} />
              {page === "notifications"
                ? t("На главную", "Back home")
                : t("К профилю", "Back to profile")}
            </button>
          )}
          <Suspense fallback={<Loading />}>
            <Content />
          </Suspense>
        </motion.div>
      </main>
      <nav
        className="bottom-nav"
        aria-label={t("Основная навигация", "Main navigation")}
      >
        {(
          [
            { id: "home", icon: Home, ru: "Главная", en: "Home" },
            { id: "games", icon: Gamepad2, ru: "Игры", en: "Games" },
            {
              id: "communities",
              icon: Compass,
              ru: "Сообщества",
              en: "Communities",
            },
            { id: "friends", icon: Users, ru: "Друзья", en: "Friends" },
            { id: "profile", icon: UserRound, ru: "Профиль", en: "Profile" },
          ] as const
        ).map(({ id, icon: Icon, ru, en }) => {
          const pending =
            id === "friends" ? (social.data?.incoming.length ?? 0) : 0;
          return (
            <button
              key={id}
              aria-current={page === id ? "page" : undefined}
              aria-label={pending ? `${t(ru, en)} · ${pending}` : undefined}
              className={page === id ? "active" : ""}
              onClick={() => navigate(id)}
            >
              {page === id && (
                <motion.span
                  className="nav-glass-indicator"
                  layoutId="active-tab"
                  transition={
                    reduce
                      ? { duration: 0 }
                      : { type: "spring", bounce: 0, duration: 0.3 }
                  }
                  aria-hidden="true"
                />
              )}
              <Icon size={21} />
              <span>{t(ru, en)}</span>
              {pending > 0 && (
                <span className="nav-badge" aria-hidden="true">
                  {pending > 9 ? "9+" : pending}
                </span>
              )}
            </button>
          );
        })}
      </nav>
    </div>
  );
}
function Content() {
  const page = useApp((s) => s.page);
  const t = useText();
  const query = useQuery({
    queryKey: ["me"],
    queryFn: () => api<Profile>("/me"),
  });
  useEffect(() => {
    if (query.data)
      useApp.setState({ language: query.data.locale === "ru" ? "ru" : "en" });
  }, [query.data?.locale]);
  if (query.isPending) return <Loading />;
  if (query.isError)
    return (
      <div className="panel error" role="alert">
        {errorText(query.error, useApp.getState().language === "ru")}
        <button className="button secondary" onClick={() => query.refetch()}>
          {t("Повторить", "Try again")}
        </button>
      </div>
    );
  const me = query.data;
  switch (page) {
    case "home":
      return <Dashboard me={me} />;
    case "friends":
      return <FriendsPage me={me} />;
    case "notifications":
      return <NotificationsPage />;
    case "profile":
      return <ProfilePage me={me} />;
    case "interests":
      return <InterestsPage me={me} />;
    case "privacy":
      return <PrivacyPage me={me} />;
    case "sessions":
      return <SessionsPage />;
    case "settings":
      return <SettingsPage me={me} />;
    default:
      return <Upcoming page={page} />;
  }
}
