import { create } from "zustand";
export type Page =
  | "home"
  | "games"
  | "communities"
  | "friends"
  | "profile"
  | "interests"
  | "privacy"
  | "settings"
  | "sessions"
  | "notifications";
const pages: Page[] = [
  "home",
  "games",
  "communities",
  "friends",
  "profile",
  "interests",
  "privacy",
  "settings",
  "sessions",
  "notifications",
];
export const useApp = create<{
  token: string | null;
  phase: "loading" | "outside" | "ready" | "error" | "expired" | "signedout";
  error: string;
  page: Page;
  language: "ru" | "en";
  theme: "auto" | "dark" | "light";
}>(() => ({
  token: null,
  phase: "loading",
  error: "",
  page: pages.includes(location.hash.slice(1) as Page)
    ? (location.hash.slice(1) as Page)
    : "home",
  language: navigator.language.startsWith("ru") ? "ru" : "en",
  theme: "auto",
}));
export const navigate = (page: Page) => {
  history.replaceState(null, "", "#" + page);
  useApp.setState({ page });
  window.scrollTo({ top: 0, behavior: "instant" });
};
