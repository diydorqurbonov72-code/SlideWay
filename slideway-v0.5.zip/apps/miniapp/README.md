# SlideWay Mini App

React/TypeScript/Vite with official Telegram Web Apps JS SDK, TanStack Query, Zustand, Tailwind, Radix dialog and Framer Motion. Real API only; no production mock login or localStorage backend. Session token stays in memory.

From repository root: `npm run dev:miniapp`. Vite proxies /api to 127.0.0.1:3000. For a public Telegram test, expose frontend + API behind trusted HTTPS and configure BotFather; a local HTTP page alone cannot run as a real Mini App. Outside Telegram the app explains how to open it via the bot.

`npm run build -w @slideway/miniapp` builds static files in apps/miniapp/dist. Secondary screens are lazy-loaded. VITE_BOT_USERNAME is a public build-time username, never a secret. For standalone Vite local development put it into apps/miniapp/.env.local or export it before running Vite. Compose passes TELEGRAM_BOT_USERNAME to the frontend build.

Implemented: home with actual profile completion, profile edit, interests, privacy preferences, RU/EN, theme auto/light/dark, active sessions/revocation, guarded account deletion. Games/Friends/Communities show explicit development states. No fake matches, players, statistics or balances.

Browser test: tests/browser_e2e.py (Python Playwright + Chromium). It injects a synthetic Telegram SDK context only into the test browser while using the real backend and database.
