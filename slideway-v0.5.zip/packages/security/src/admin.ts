import type { AdminRole } from "@prisma/client";
export type Role = AdminRole | "OWNER";
export type Permission =
  | "dashboard:read"
  | "users:read"
  | "users:moderate"
  | "sessions:revoke"
  | "roles:write"
  | "audit:read";
export const permissions: Record<Role, Permission[]> = {
  OWNER: [
    "dashboard:read",
    "users:read",
    "users:moderate",
    "sessions:revoke",
    "roles:write",
    "audit:read",
  ],
  ADMINISTRATOR: [
    "dashboard:read",
    "users:read",
    "users:moderate",
    "sessions:revoke",
    "audit:read",
  ],
  MODERATOR: ["users:read", "users:moderate"],
  SUPPORT: ["users:read"],
  ANALYST: ["dashboard:read"],
};
export function effectiveRole(
  user: { telegramId: bigint; adminUser?: { role: AdminRole } | null },
  owner: string,
): Role | null {
  return user.telegramId.toString() === owner
    ? "OWNER"
    : (user.adminUser?.role ?? null);
}
export function restricted(
  user: { banned: boolean; banUntil: Date | null },
  now = new Date(),
) {
  return user.banned && (!user.banUntil || user.banUntil > now);
}
