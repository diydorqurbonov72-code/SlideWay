import {
  createHash,
  createHmac,
  randomBytes,
  timingSafeEqual,
} from "node:crypto";
import { z } from "zod";
const telegramUser = z.object({
  id: z.number().int().positive().max(Number.MAX_SAFE_INTEGER),
  first_name: z.string().min(1).max(256),
  last_name: z.string().max(256).optional(),
  username: z.string().max(64).optional(),
  language_code: z.string().max(16).optional(),
  is_bot: z.literal(false).optional(),
});
export const digest = (s: string) =>
  createHash("sha256").update(s).digest("hex");
export const newSessionToken = () => randomBytes(32).toString("base64url");
export function verifyTelegram(
  raw: string,
  botToken: string,
  maxAge: number,
  now = Math.floor(Date.now() / 1000),
) {
  if (!raw || Buffer.byteLength(raw) > 8192)
    throw new Error("Invalid authentication");
  const p = new URLSearchParams(raw);
  if (new Set(p.keys()).size !== [...p.keys()].length)
    throw new Error("Duplicate fields");
  const hash = p.get("hash");
  if (!hash || !/^[a-f0-9]{64}$/.test(hash)) throw new Error("Invalid hash");
  p.delete("hash");
  const check = [...p.entries()]
    .sort(([a], [b]) => (a < b ? -1 : a > b ? 1 : 0))
    .map(([k, v]) => `${k}=${v}`)
    .join("\n");
  const secret = createHmac("sha256", "WebAppData").update(botToken).digest();
  const calculated = createHmac("sha256", secret).update(check).digest();
  if (!timingSafeEqual(calculated, Buffer.from(hash, "hex")))
    throw new Error("Invalid signature");
  const date = p.get("auth_date");
  if (!date || !/^\d{1,12}$/.test(date)) throw new Error("Invalid date");
  const authDate = Number(date);
  if (authDate > now + 30 || now - authDate > maxAge)
    throw new Error("Expired authentication");
  const user = telegramUser.parse(JSON.parse(p.get("user") || "null"));
  return {
    user,
    replayHash: hash,
    expiresAt: new Date((authDate + maxAge + 31) * 1000),
  };
}
