import "dotenv/config";
import { PrismaClient } from "@prisma/client";
import { PrismaPg } from "@prisma/adapter-pg";
const db = new PrismaClient({
  adapter: new PrismaPg({ connectionString: process.env.DATABASE_URL }),
});
const interests = [
  ["gaming", "Игры", "Gaming"],
  ["programming", "Программирование", "Programming"],
  ["design", "Дизайн", "Design"],
  ["movies", "Кино", "Movies"],
  ["music", "Музыка", "Music"],
  ["education", "Образование", "Education"],
  ["sports", "Спорт", "Sports"],
  ["languages", "Языки", "Languages"],
];
async function main() {
  for (const [key, nameRu, nameEn] of interests)
    await db.interest.upsert({
      where: { key },
      create: { key, nameRu, nameEn },
      update: { nameRu, nameEn },
    });
}
main()
  .finally(() => db.$disconnect())
  .catch(() => {
    console.error("Seed failed");
    process.exitCode = 1;
  });
