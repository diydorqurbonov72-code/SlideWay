-- CreateEnum
CREATE TYPE "FriendshipStatus" AS ENUM ('PENDING', 'ACCEPTED');

-- CreateTable
CREATE TABLE "Friendship" (
    "id" UUID NOT NULL,
    "firstId" UUID NOT NULL,
    "secondId" UUID NOT NULL,
    "requestedByFirst" BOOLEAN NOT NULL,
    "status" "FriendshipStatus" NOT NULL DEFAULT 'PENDING',
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "Friendship_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "UserBlock" (
    "actorId" UUID NOT NULL,
    "targetId" UUID NOT NULL,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "UserBlock_pkey" PRIMARY KEY ("actorId","targetId")
);

-- CreateIndex
CREATE INDEX "Friendship_secondId_status_idx" ON "Friendship"("secondId", "status");

-- CreateIndex
CREATE INDEX "Friendship_firstId_status_idx" ON "Friendship"("firstId", "status");

-- CreateIndex
CREATE UNIQUE INDEX "Friendship_firstId_secondId_key" ON "Friendship"("firstId", "secondId");

-- CreateIndex
CREATE INDEX "UserBlock_targetId_idx" ON "UserBlock"("targetId");

-- AddForeignKey
ALTER TABLE "Friendship" ADD CONSTRAINT "Friendship_firstId_fkey" FOREIGN KEY ("firstId") REFERENCES "User"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "Friendship" ADD CONSTRAINT "Friendship_secondId_fkey" FOREIGN KEY ("secondId") REFERENCES "User"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "UserBlock" ADD CONSTRAINT "UserBlock_actorId_fkey" FOREIGN KEY ("actorId") REFERENCES "User"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "UserBlock" ADD CONSTRAINT "UserBlock_targetId_fkey" FOREIGN KEY ("targetId") REFERENCES "User"("id") ON DELETE CASCADE ON UPDATE CASCADE;


ALTER TABLE "Friendship" ADD CONSTRAINT "Friendship_canonical_pair" CHECK ("firstId" < "secondId");
ALTER TABLE "UserBlock" ADD CONSTRAINT "UserBlock_no_self" CHECK ("actorId" <> "targetId");
