-- CreateTable
CREATE TABLE "TelegramUpdate" (
    "id" BIGINT NOT NULL,
    "payload" JSONB NOT NULL,
    "status" VARCHAR(16) NOT NULL DEFAULT 'pending',
    "attempts" INTEGER NOT NULL DEFAULT 0,
    "availableAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "lockedUntil" TIMESTAMP(3),
    "claimId" UUID,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "finishedAt" TIMESTAMP(3),

    CONSTRAINT "TelegramUpdate_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE INDEX "TelegramUpdate_status_availableAt_idx" ON "TelegramUpdate"("status", "availableAt");

-- CreateIndex
CREATE INDEX "TelegramUpdate_finishedAt_idx" ON "TelegramUpdate"("finishedAt");

