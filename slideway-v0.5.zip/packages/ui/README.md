# Shared UI boundary

Reusable components currently live in apps/miniapp/src/components/shared.tsx and apps/admin/src/components.tsx. Both applications use the SlideWay palette, accessible native controls and Radix dialogs. Extraction into a published shared UI workspace is not yet done. This directory is not an executable package.
