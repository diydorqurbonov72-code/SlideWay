import { z } from "zod";
export function readConfig(env: NodeJS.ProcessEnv = process.env) {
  const c = z
    .object({
      NODE_ENV: z
        .enum(["development", "test", "production"])
        .default("development"),
      PORT: z.coerce.number().int().min(1).max(65535).default(3000),
      DATABASE_URL: z.string().url(),
      REDIS_URL: z.string().url(),
      TELEGRAM_BOT_TOKEN: z.string().regex(/^\d{5,}:[A-Za-z0-9_-]{20,}$/),
      ALLOWED_ORIGINS: z.string().min(1),
      ADMIN_OWNER_TELEGRAM_ID: z
        .string()
        .regex(/^[1-9][0-9]{0,15}$/)
        .default("8765005700"),
      BOT_ENABLED: z.enum(["true", "false"]).default("false"),
      TELEGRAM_WEBHOOK_SECRET: z
        .string()
        .regex(/^[A-Za-z0-9_-]{32,256}$/)
        .optional(),
      TELEGRAM_BOT_USERNAME: z
        .string()
        .regex(/^[A-Za-z0-9_]{5,32}$/)
        .optional(),
      MINIAPP_URL: z.string().url().optional(),
      WEBHOOK_URL: z.string().url().optional(),
      AUTH_MAX_AGE_SECONDS: z.coerce
        .number()
        .int()
        .min(30)
        .max(600)
        .default(300),
      SESSION_TTL_SECONDS: z.coerce
        .number()
        .int()
        .min(60)
        .max(86400)
        .default(86400),
    })
    .parse(env);
  const origins = c.ALLOWED_ORIGINS.split(",").map((s) => s.trim());
  for (const origin of origins) {
    const u = new URL(origin);
    if (
      u.origin !== origin ||
      (c.NODE_ENV === "production" && u.protocol !== "https:")
    )
      throw new Error("Invalid allowed origin");
  }
  if (c.BOT_ENABLED === "true") {
    if (
      !c.TELEGRAM_WEBHOOK_SECRET ||
      !c.TELEGRAM_BOT_USERNAME ||
      !c.MINIAPP_URL
    )
      throw new Error("Bot configuration incomplete");
    if (new URL(c.MINIAPP_URL).protocol !== "https:")
      throw new Error("Mini App requires HTTPS");
  }
  return { ...c, origins };
}
export type Config = ReturnType<typeof readConfig>;
