import { z } from "zod";
export const authBody = z
  .object({ initData: z.string().min(1).max(8192) })
  .strict();
export const profilePatch = z
  .object({
    displayName: z.string().trim().min(1).max(80).optional(),
    bio: z.string().trim().max(280).optional(),
    locale: z.enum(["ru", "en", "uz"]).optional(),
    interests: z
      .array(z.string().regex(/^[a-z]{2,32}$/))
      .max(8)
      .refine((a) => new Set(a).size === a.length)
      .optional(),
    settings: z
      .object({
        profileVisible: z.boolean().optional(),
        showActivity: z.boolean().optional(),
        showAchievements: z.boolean().optional(),
        allowFriendRequests: z.boolean().optional(),
        notifications: z.boolean().optional(),
      })
      .strict()
      .optional(),
  })
  .strict();
