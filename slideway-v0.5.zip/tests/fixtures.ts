import { createHmac } from "node:crypto";
// Synthetic credentials used exclusively by tests; no bypass exists in the API.
export const testBotToken = "123456789:test_token_for_automated_tests_only";
export function signed(
  id = 1001,
  date = Math.floor(Date.now() / 1000),
  extra: Record<string, string> = {},
) {
  const p = new URLSearchParams({
    auth_date: String(date),
    user: JSON.stringify({ id, first_name: "Test User", language_code: "ru" }),
    ...extra,
  });
  const check = [...p.entries()]
    .sort(([a], [b]) => (a < b ? -1 : a > b ? 1 : 0))
    .map(([k, v]) => `${k}=${v}`)
    .join("\n");
  const key = createHmac("sha256", "WebAppData").update(testBotToken).digest();
  p.set("hash", createHmac("sha256", key).update(check).digest("hex"));
  return p.toString();
}
