import { test } from "node:test";
import assert from "node:assert/strict";
import { validWebhookSecret, incomingUpdate } from "../apps/bot/src/webhook";
import { readConfig } from "../packages/config/src";
import { testBotToken } from "./fixtures";
test("webhook secret rejects absent, wrong and repeated header values", () => {
  const secret = "a".repeat(40);
  assert.ok(validWebhookSecret(secret, secret));
  for (const value of [undefined, "x", secret + "x", ["a", secret]])
    assert.equal(validWebhookSecret(value, secret), false);
});
test("bot config requires complete HTTPS configuration", () => {
  const base = {
    NODE_ENV: "test",
    DATABASE_URL: "postgresql://localhost/test",
    REDIS_URL: "redis://localhost",
    TELEGRAM_BOT_TOKEN: testBotToken,
    ALLOWED_ORIGINS: "http://localhost:5173",
    BOT_ENABLED: "true",
  };
  assert.throws(() => readConfig(base));
  assert.throws(() =>
    readConfig({
      ...base,
      TELEGRAM_WEBHOOK_SECRET: "a".repeat(40),
      TELEGRAM_BOT_USERNAME: "slideway_bot",
      MINIAPP_URL: "http://localhost:5173",
    }),
  );
  assert.equal(
    readConfig({
      ...base,
      TELEGRAM_WEBHOOK_SECRET: "a".repeat(40),
      TELEGRAM_BOT_USERNAME: "slideway_bot",
      MINIAPP_URL: "https://example.com",
    }).BOT_ENABLED,
    "true",
  );
});
test("webhook strips unrelated personal data", () => {
  const parsed = incomingUpdate.parse({
    update_id: 1,
    message: {
      message_id: 1,
      date: 1,
      chat: { id: 2, type: "private", first_name: "hidden" },
      from: { id: 2, is_bot: false, first_name: "Name" },
      text: "/start",
      contact: { phone_number: "hidden" },
    },
  });
  assert.equal("contact" in parsed.message!, false);
  assert.equal("first_name" in parsed.message!.chat, false);
});
