import { test, before, after } from "node:test";
import assert from "node:assert/strict";
import { spawn, ChildProcess } from "node:child_process";
import { PrismaClient } from "@prisma/client";
import { PrismaPg } from "@prisma/adapter-pg";
import Redis from "ioredis";
import { signed, testBotToken } from "./fixtures";
import { digest } from "../packages/security/src/telegram";
if (
  process.env.NODE_ENV !== "test" ||
  !process.env.DATABASE_URL?.endsWith("/slideway_test") ||
  !process.env.REDIS_URL?.endsWith("/15")
)
  throw new Error(
    "Integration suite requires NODE_ENV=test and dedicated slideway_test database and Redis DB 15; deletes test data",
  );
const db = new PrismaClient({
  adapter: new PrismaPg({ connectionString: process.env.DATABASE_URL }),
});
const redis = new Redis(process.env.REDIS_URL!);
let child: ChildProcess;
let logs = "";
const base = "http://127.0.0.1:3301/api/v1";
const request = (
  path: string,
  method = "GET",
  body?: unknown,
  token?: string,
) =>
  fetch(base + path, {
    method,
    headers: {
      "Content-Type": "application/json",
      ...(token ? { Authorization: "Bearer " + token } : {}),
    },
    body: body === undefined ? undefined : JSON.stringify(body),
  });
async function login(id: number, nonce: string) {
  const r = await request("/auth/telegram", "POST", {
    initData: signed(id, undefined, { query_id: nonce }),
  });
  assert.equal(
    r.status,
    200,
    await (r.status !== 200 ? r.text() : Promise.resolve("")),
  );
  return (await r.json()).accessToken as string;
}
before(async () => {
  await db.telegramUpdate.deleteMany();
  await db.user.deleteMany();
  await db.authReplay.deleteMany();
  await redis.flushdb();
  child = spawn(process.execPath, ["dist/apps/api/src/main.js"], {
    env: {
      ...process.env,
      TELEGRAM_BOT_TOKEN: testBotToken,
      PORT: "3301",
      ALLOWED_ORIGINS: "http://localhost:5173",
      BOT_ENABLED: "true",
      TELEGRAM_WEBHOOK_SECRET: "integration_secret_01234567890123456789",
      TELEGRAM_BOT_USERNAME: "slideway_test_bot",
      MINIAPP_URL: "https://example.com",
    },
    stdio: ["ignore", "pipe", "pipe"],
  });
  child.stdout?.on("data", (d) => (logs += d));
  child.stderr?.on("data", (d) => (logs += d));
  for (let i = 0; i < 100; i++) {
    try {
      const r = await request("/health/ready");
      if (r.ok) return;
    } catch {}
    await new Promise((r) => setTimeout(r, 100));
  }
  throw new Error("API did not start: " + logs);
});
after(async () => {
  if (child && child.exitCode === null) {
    child.kill("SIGTERM");
    await new Promise<void>((r) => child.once("exit", () => r()));
  }
  await db.$disconnect();
  redis.disconnect();
});
test("real database/cache health and security headers", async () => {
  const r = await request("/health/ready");
  assert.equal(r.status, 200);
  assert.equal(r.headers.get("x-content-type-options"), "nosniff");
  assert.ok(r.headers.get("x-request-id"));
  assert.equal(r.headers.get("cache-control"), "no-store");
});
test("authentication required; invalid signature rejected", async () => {
  assert.equal((await request("/me")).status, 401);
  assert.equal(
    (
      await request("/auth/telegram", "POST", {
        initData: "hash=" + "0".repeat(64),
      })
    ).status,
    401,
  );
});
test("concurrent replay permits exactly one session", async () => {
  const data = signed(2101, undefined, { query_id: "replay" });
  const responses = await Promise.all(
    Array.from({ length: 6 }, () =>
      request("/auth/telegram", "POST", { initData: data }),
    ),
  );
  assert.deepEqual(
    responses.map((r) => r.status).sort(),
    [200, 409, 409, 409, 409, 409],
  );
  assert.equal(
    await db.userSession.count({ where: { user: { telegramId: 2101n } } }),
    1,
  );
});
test("profile persistence, defaults, strict schema and interests", async () => {
  const token = await login(2102, "profile");
  const r = await request("/me", "GET", undefined, token);
  const me = await r.json();
  assert.equal(me.settings.profileVisible, false);
  assert.equal(me.settings.allowFriendRequests, false);
  assert.equal("telegramId" in me, false);
  assert.equal("tokenHash" in me, false);
  assert.equal(
    (await request("/me", "PATCH", { role: "Owner" }, token)).status,
    400,
  );
  assert.equal(
    (await request("/me", "PATCH", { interests: ["nonexistent"] }, token))
      .status,
    400,
  );
  const update = await request(
    "/me",
    "PATCH",
    {
      displayName: "Alice",
      bio: "<script>alert(1)</script>'; DROP TABLE users;--",
      locale: "en",
      interests: ["gaming"],
      settings: { showActivity: true },
    },
    token,
  );
  assert.equal(update.status, 200);
  const result = await (await request("/me", "GET", undefined, token)).json();
  assert.equal(result.displayName, "Alice");
  assert.equal(result.interests[0].interestKey, "gaming");
  assert.equal(result.settings.showActivity, true);
  assert.equal(typeof result.bio, "string");
  const row = await db.userSession.findUnique({
    where: { tokenHash: digest(token) },
  });
  assert.ok(row);
  assert.notEqual(row.tokenHash, token);
});
test("sessions cannot be revoked by another user", async () => {
  const a = await login(2103, "a"),
    b = await login(2104, "b");
  const sessions = await (
    await request("/me/sessions", "GET", undefined, b)
  ).json();
  assert.equal(
    (await request("/me/sessions/" + sessions[0].id, "DELETE", undefined, a))
      .status,
    204,
  );
  assert.equal((await request("/me", "GET", undefined, b)).status, 200);
  assert.equal(
    (await request("/me/sessions/" + sessions[0].id, "DELETE", undefined, b))
      .status,
    204,
  );
  assert.equal((await request("/me", "GET", undefined, b)).status, 401);
});
test("expiry and revoke-all invalidate sessions", async () => {
  const a = await login(2105, "expire");
  await db.userSession.update({
    where: { tokenHash: digest(a) },
    data: { expiresAt: new Date(0) },
  });
  assert.equal((await request("/me", "GET", undefined, a)).status, 401);
  const b = await login(2105, "all"),
    c = await login(2105, "all2");
  assert.equal(
    (await request("/me/sessions", "DELETE", undefined, b)).status,
    204,
  );
  assert.equal((await request("/me", "GET", undefined, c)).status, 401);
});
test("account deletion requires confirmation and cascades", async () => {
  const token = await login(2106, "delete");
  assert.equal((await request("/me", "DELETE", {}, token)).status, 400);
  const me = await (await request("/me", "GET", undefined, token)).json();
  assert.equal(
    (await request("/me", "DELETE", { confirmation: "DELETE" }, token)).status,
    204,
  );
  assert.equal(await db.user.count({ where: { id: me.id } }), 0);
  assert.equal(await db.userSettings.count({ where: { userId: me.id } }), 0);
  assert.equal(await db.userSession.count({ where: { userId: me.id } }), 0);
  assert.equal((await request("/me", "GET", undefined, token)).status, 401);
});
test("malformed JSON and oversized bodies return client errors", async () => {
  const bad = await fetch(base + "/auth/telegram", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: "{",
  });
  assert.equal(bad.status, 400);
  const large = await request("/auth/telegram", "POST", {
    initData: "x".repeat(13000),
  });
  assert.equal(large.status, 413);
});
test("old session cannot delete account without reauthentication", async () => {
  const token = await login(2107, "freshness");
  await db.userSession.update({
    where: { tokenHash: digest(token) },
    data: { createdAt: new Date(Date.now() - 301000) },
  });
  assert.equal(
    (await request("/me", "DELETE", { confirmation: "DELETE" }, token)).status,
    401,
  );
  assert.equal((await request("/me", "GET", undefined, token)).status, 200);
});
test("rate limiting is enforced by Redis", async () => {
  await redis.flushdb();
  let status = 0;
  for (let i = 0; i < 21; i++)
    status = (await request("/auth/telegram", "POST", { initData: "invalid" }))
      .status;
  assert.equal(status, 429);
});
test("logs do not include credentials or profile contents", () => {
  assert.equal(logs.includes(testBotToken), false);
  assert.equal(logs.includes("DROP TABLE"), false);
  assert.equal(logs.includes("tokenHash"), false);
});

test("webhook rejects wrong secret and deduplicates concurrent deliveries", async () => {
  const data = {
    update_id: 777,
    message: {
      message_id: 1,
      date: 1,
      chat: { id: 12345, type: "private" },
      from: { id: 12345, is_bot: false, first_name: "Webhook" },
      text: "/start",
    },
  };
  assert.equal((await request("/telegram/webhook", "POST", data)).status, 401);
  const send = () =>
    fetch(base + "/telegram/webhook", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "X-Telegram-Bot-Api-Secret-Token":
          "integration_secret_01234567890123456789",
      },
      body: JSON.stringify(data),
    });
  const replies = await Promise.all(Array.from({ length: 5 }, send));
  assert.ok(replies.every((r) => r.status === 200));
  assert.equal(await db.telegramUpdate.count({ where: { id: 777n } }), 1);
});
