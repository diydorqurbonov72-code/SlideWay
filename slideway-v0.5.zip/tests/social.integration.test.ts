import { test, before, after } from "node:test";
import assert from "node:assert/strict";
import { randomUUID } from "node:crypto";
import { spawn, ChildProcess } from "node:child_process";
import { PrismaClient } from "@prisma/client";
import { PrismaPg } from "@prisma/adapter-pg";
import Redis from "ioredis";
import { signed, testBotToken } from "./fixtures";
if (
  process.env.NODE_ENV !== "test" ||
  !process.env.DATABASE_URL?.endsWith("/slideway_test") ||
  !process.env.REDIS_URL?.endsWith("/15")
)
  throw Error("Isolated test services required");
const db = new PrismaClient({
    adapter: new PrismaPg({ connectionString: process.env.DATABASE_URL }),
  }),
  redis = new Redis(process.env.REDIS_URL!);
let child: ChildProcess;
let a = "",
  b = "",
  c = "",
  aid = "",
  bid = "",
  rid = "";
const req = (path: string, method = "GET", body?: unknown, token = a) =>
  fetch("http://127.0.0.1:3303/api/v1" + path, {
    method,
    headers: {
      "Content-Type": "application/json",
      Authorization: "Bearer " + token,
    },
    body: body === undefined ? undefined : JSON.stringify(body),
  });
async function login(id: number) {
  const r = await req("/auth/telegram", "POST", {
    initData: signed(id, undefined, { query_id: randomUUID() }),
  });
  assert.equal(r.status, 200);
  return (await r.json()).accessToken;
}
before(async () => {
  await db.auditLog.deleteMany();
  await db.user.deleteMany();
  await db.authReplay.deleteMany();
  await redis.flushdb();
  child = spawn(process.execPath, ["dist/apps/api/src/main.js"], {
    env: {
      ...process.env,
      PORT: "3303",
      TELEGRAM_BOT_TOKEN: testBotToken,
      BOT_ENABLED: "false",
      ALLOWED_ORIGINS: "http://localhost:5173",
    },
    stdio: "ignore",
  });
  for (let i = 0; i < 100; i++) {
    try {
      if ((await req("/health/ready")).ok) break;
    } catch {}
    await new Promise((r) => setTimeout(r, 100));
  }
  a = await login(790001);
  b = await login(790002);
  c = await login(790003);
  aid = (await (await req("/me")).json()).id;
  bid = (await (await req("/me", "GET", undefined, b)).json()).id;
  await req("/me", "PATCH", { displayName: "SocialFixtureAlpha" });
  await req("/me", "PATCH", { displayName: "SocialFixtureBeta" }, b);
});
after(async () => {
  if (child && child.exitCode === null) {
    child.kill("SIGTERM");
    await new Promise<void>((r) => child.once("exit", () => r()));
  }
  await db.$disconnect();
  redis.disconnect();
});
test("search opt-in and request privacy; no private Telegram fields", async () => {
  assert.deepEqual(
    await (await req("/friends/search?q=SocialFixture")).json(),
    [],
  );
  assert.equal(
    (await req("/friends/requests", "POST", { userId: bid })).status,
    403,
  );
  await req(
    "/me",
    "PATCH",
    { settings: { profileVisible: true, allowFriendRequests: true } },
    b,
  );
  const people = await (await req("/friends/search?q=SocialFixture")).json();
  assert.equal(people.length, 1);
  assert.deepEqual(Object.keys(people[0]).sort(), [
    "bio",
    "displayName",
    "id",
    "settings",
  ]);
  assert.equal((await req("/friends/search?q=x")).status, 400);
  assert.equal((await req("/friends", "GET", undefined, "")).status, 401);
});
test("idempotent request and recipient-only acceptance", async () => {
  const r = await req("/friends/requests", "POST", { userId: bid });
  assert.equal(r.status, 200);
  rid = (await r.json()).id;
  const incomingActivity = await (
    await req("/notifications", "GET", undefined, b)
  ).json();
  assert.equal(incomingActivity.unread, 1);
  assert.equal(incomingActivity.items[0].type, "FRIEND_REQUEST");
  assert.equal(incomingActivity.items[0].entityId, rid);
  assert.deepEqual(Object.keys(incomingActivity.items[0].actor).sort(), [
    "displayName",
    "id",
  ]);
  assert.equal((await req("/notifications", "GET", undefined, "")).status, 401);
  assert.equal(
    (await (await req("/friends/requests", "POST", { userId: bid })).json()).id,
    rid,
  );
  assert.equal(
    (await (await req("/notifications", "GET", undefined, b)).json()).items
      .length,
    1,
  );
  assert.equal(
    (await req("/friends/requests/" + rid + "/accept", "POST")).status,
    403,
  );
  assert.equal(
    (await req("/friends/requests/" + rid + "/accept", "POST", undefined, c))
      .status,
    403,
  );
  assert.equal(
    (await (await req("/friends", "GET", undefined, b)).json()).incoming.length,
    1,
  );
  assert.equal(
    (await req("/friends/requests/" + rid + "/accept", "POST", undefined, b))
      .status,
    200,
  );
  assert.equal((await (await req("/friends")).json()).friends.length, 1);
  assert.equal(
    (await (await req("/notifications", "GET", undefined, b)).json()).items
      .length,
    0,
  );
});
test("accepted activity is private, readable and owned by its recipient", async () => {
  const activity = await (await req("/notifications")).json();
  assert.equal(activity.unread, 1);
  assert.equal(activity.items[0].type, "FRIEND_ACCEPTED");
  assert.equal(activity.items[0].actor.id, bid);
  assert.equal(
    (
      await req(
        "/notifications/" + activity.items[0].id,
        "DELETE",
        undefined,
        c,
      )
    ).status,
    200,
  );
  assert.equal((await (await req("/notifications")).json()).items.length, 1);
  assert.equal((await req("/notifications/read-all", "POST")).status, 200);
  assert.equal((await (await req("/notifications")).json()).unread, 0);
  assert.equal(
    (await req("/notifications/not-a-uuid/read", "POST")).status,
    400,
  );
});
test("foreign deletion cannot remove friendship", async () => {
  await req("/friends/" + rid, "DELETE", undefined, c);
  assert.equal((await (await req("/friends")).json()).friends.length, 1);
});
test("block removes friendship and prevents contact in both directions", async () => {
  assert.equal(
    (await req("/friends/blocks/" + aid, "POST", undefined, b)).status,
    200,
  );
  assert.equal((await (await req("/friends")).json()).friends.length, 0);
  assert.equal((await (await req("/notifications")).json()).items.length, 0);
  assert.deepEqual(
    await (await req("/friends/search?q=SocialFixture")).json(),
    [],
  );
  assert.equal(
    (await req("/friends/requests", "POST", { userId: bid })).status,
    403,
  );
  assert.equal(
    (await req("/friends/requests", "POST", { userId: aid }, b)).status,
    403,
  );
  assert.equal(
    (await (await req("/friends", "GET", undefined, b)).json()).blocked[0].id,
    aid,
  );
});
test("unblock restores discoverability without recreating friendship; self forbidden", async () => {
  await req("/friends/blocks/" + aid, "DELETE", undefined, b);
  assert.equal(
    (await (await req("/friends/search?q=SocialFixture")).json()).length,
    1,
  );
  assert.equal((await (await req("/friends")).json()).friends.length, 0);
  assert.equal((await req("/friends/blocks/" + aid, "POST")).status, 400);
  assert.equal(
    (await req("/friends/requests", "POST", { userId: aid })).status,
    400,
  );
});
test("concurrent request/block cannot leave friendship across block", async () => {
  await redis.flushdb();
  const results = await Promise.all([
    req("/friends/requests", "POST", { userId: bid }),
    req("/friends/blocks/" + aid, "POST", undefined, b),
  ]);
  assert.ok(results.every((r) => [200, 403, 409].includes(r.status)));
  if (results[1].status === 409)
    assert.equal(
      (await req("/friends/blocks/" + aid, "POST", undefined, b)).status,
      200,
    );
  assert.equal(await db.friendship.count(), 0);
  assert.equal(await db.userBlock.count(), 1);
});
test("friend requests rate limited", async () => {
  await redis.set("friend-requests:" + aid, "10", "EX", 60);
  assert.equal(
    (await req("/friends/requests", "POST", { userId: bid })).status,
    429,
  );
});
