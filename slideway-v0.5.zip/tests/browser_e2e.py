"""Real API and database; Telegram launch context is synthetic only in tests."""
import os,time,json,hmac,hashlib,urllib.parse,urllib.request,subprocess,uuid,signal
from pathlib import Path
from playwright.sync_api import sync_playwright,expect
root=Path(__file__).resolve().parents[1]
if os.environ.get('NODE_ENV')!='test' or not os.environ.get('DATABASE_URL','').endswith('/slideway_test') or not os.environ.get('REDIS_URL','').endswith('/15'):raise RuntimeError('Dedicated test DB and Redis 15 required')
subprocess.run(['node','-e',"const r=new(require('ioredis'))(process.env.REDIS_URL);r.flushdb().finally(()=>r.quit());"],cwd=root,check=True)
artifacts=root.parent/'browser-artifacts';artifacts.mkdir(exist_ok=True)
token='123456789:test_token_for_automated_tests_only'
data={'auth_date':str(int(time.time())),'query_id':str(uuid.uuid4()),'user':json.dumps({'id':880001,'first_name':'Алекс','language_code':'ru'},ensure_ascii=False,separators=(',',':'))}
secret=hmac.new(b'WebAppData',token.encode(),hashlib.sha256).digest();data['hash']=hmac.new(secret,'\n'.join(f'{k}={v}' for k,v in sorted(data.items())).encode(),hashlib.sha256).hexdigest();init=urllib.parse.urlencode(data)
def ready(url):
 for _ in range(120):
  try:
   with urllib.request.urlopen(url,timeout=1) as res:
    if res.status==200:return
  except Exception:pass
  time.sleep(.15)
 raise RuntimeError('Server did not start: '+url)
log=open(artifacts/'servers.log','w');env={**os.environ,'PORT':'3000','TELEGRAM_BOT_TOKEN':token,'ALLOWED_ORIGINS':'http://127.0.0.1:5173','BOT_ENABLED':'false'}
servers=[subprocess.Popen(cmd,cwd=root,env=env,stdout=log,stderr=log,start_new_session=True) for cmd in [['node','dist/apps/api/src/main.js'],['npm','run','dev:miniapp']]]
try:
 ready('http://127.0.0.1:3000/api/v1/health/ready');ready('http://127.0.0.1:5173')
 with sync_playwright() as p:
  browser=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox']);context=browser.new_context(viewport={'width':1280,'height':1000},locale='ru-RU')
  context.route('https://telegram.org/js/telegram-web-app.js',lambda route:route.fulfill(status=200,body=''))
  context.add_init_script('window.Telegram={WebApp:{initData:'+json.dumps(init)+',colorScheme:"dark",ready(){},expand(){},onEvent(){},offEvent(){},BackButton:{show(){},hide(){},onClick(){},offClick(){}},HapticFeedback:{notificationOccurred(){}}}};')
  page=context.new_page();errors=[];page.on('pageerror',lambda e:errors.append(str(e)));page.goto('http://127.0.0.1:5173');page.wait_for_load_state('networkidle')
  expect(page.get_by_role('heading',name='Привет, Алекс.')).to_be_visible();page.screenshot(path=str(artifacts/'desktop-home.png'),full_page=True,animations='disabled')
  # A second signed test identity exercises the real social API and browser UI.
  other={'auth_date':str(int(time.time())),'query_id':str(uuid.uuid4()),'user':json.dumps({'id':880002,'first_name':'Мария','language_code':'ru'},ensure_ascii=False,separators=(',',':'))}
  other['hash']=hmac.new(secret,'\n'.join(f'{k}={v}' for k,v in sorted(other.items())).encode(),hashlib.sha256).hexdigest()
  def call(path,method='GET',body=None,access=None):
   headers={'Content-Type':'application/json'}
   if access:headers['Authorization']='Bearer '+access
   request=urllib.request.Request('http://127.0.0.1:3000/api/v1'+path,method=method,headers=headers,data=json.dumps(body).encode() if body is not None else None)
   with urllib.request.urlopen(request) as res:return json.load(res)
  access=call('/auth/telegram','POST',{'initData':urllib.parse.urlencode(other)})['accessToken']
  call('/me','PATCH',{'displayName':'Мария Тест','settings':{'profileVisible':True,'allowFriendRequests':True}},access)
  previous=call('/friends',access=access)
  for relation in previous['friends']+previous['incoming']+previous['outgoing']:call('/friends/'+relation['id'],'DELETE',access=access)
  page.get_by_role('button',name='Друзья',exact=True).click();expect(page.get_by_role('heading',name='Свои люди.')).to_be_visible()
  page.get_by_role('button',name='Найти',exact=True).click();page.get_by_label('Поиск участников',exact=True).fill('Мария Тест');page.locator('form').get_by_role('button',name='Найти',exact=True).click()
  page.get_by_role('button',name='Добавить',exact=True).click();expect(page.get_by_role('button',name='Заявка отправлена')).to_be_disabled()
  pending=call('/friends',access=access)['incoming'];assert len(pending)==1;call('/friends/requests/'+pending[0]['id']+'/accept','POST',access=access)
  page.locator('.activity-trigger').click();expect(page.get_by_role('heading',name='Что нового.')).to_be_visible();expect(page.get_by_text('Мария Тест теперь в твоих друзьях',exact=True)).to_be_visible()
  page.set_viewport_size({'width':375,'height':812});assert page.evaluate('document.documentElement.scrollWidth <= innerWidth');page.screenshot(path=str(artifacts/'mobile-activity.png'),full_page=True,animations='disabled');page.get_by_role('button',name='Прочитать всё',exact=True).click();expect(page.get_by_text('Непрочитанных: 0',exact=True)).to_be_visible();page.set_viewport_size({'width':1280,'height':1000})
  page.get_by_role('button',name='Главная',exact=True).click();page.get_by_role('button',name='Друзья',exact=True).click();expect(page.get_by_role('heading',name='Мария Тест')).to_be_visible()
  page.set_viewport_size({'width':375,'height':812});assert page.evaluate('document.documentElement.scrollWidth <= innerWidth');page.screenshot(path=str(artifacts/'mobile-friends.png'),full_page=True,animations='disabled')
  page.get_by_role('button',name='Заблокировать',exact=True).click();expect(page.get_by_text('Здесь будут твои друзья',exact=True)).to_be_visible();page.get_by_role('button',name='Блокировки',exact=True).click();expect(page.get_by_role('heading',name='Мария Тест')).to_be_visible();page.get_by_role('button',name='Разблокировать',exact=True).click();expect(page.get_by_text('Нет заблокированных пользователей',exact=True)).to_be_visible();page.set_viewport_size({'width':1280,'height':1000})
  page.get_by_role('button',name='Профиль',exact=True).click();page.get_by_label('Отображаемое имя',exact=True).fill('Алекс Тест');page.get_by_label('О себе',exact=True).fill('<img src=x onerror="window.__xss=1">');page.get_by_role('button',name='Сохранить изменения').click();expect(page.get_by_text('Изменения сохранены')).to_be_visible();expect(page.get_by_role('heading',name='Алекс Тест',exact=True)).to_be_visible();assert page.evaluate('window.__xss') is None
  page.get_by_role('button',name='Мои интересы',exact=False).click();interest=page.get_by_role('button',name='Программирование',exact=True)
  if interest.get_attribute('aria-pressed')!='true':interest.click()
  page.get_by_role('button',name='Сохранить интересы').click();expect(page.get_by_text('Изменения сохранены')).to_be_visible()
  page.get_by_role('button',name='К профилю',exact=True).click();page.get_by_role('button',name='Приватность Твои границы').click();page.get_by_label('Статус активности',exact=False).check();page.get_by_role('button',name='Сохранить настройки').click();expect(page.get_by_text('Изменения сохранены')).to_be_visible();page.get_by_role('button',name='К профилю',exact=True).click();page.get_by_role('button',name='Приватность Твои границы').click();expect(page.get_by_label('Статус активности',exact=False)).to_be_checked()
  page.get_by_role('button',name='Настройки',exact=True).click();page.get_by_label('Оформление',exact=True).select_option('light');expect(page.locator('html')).to_have_attribute('data-theme','light');page.screenshot(path=str(artifacts/'light-settings.png'),full_page=True,animations='disabled');page.get_by_label('Язык интерфейса',exact=True).select_option('en');expect(page.get_by_role('heading',name='Your way.')).to_be_visible();page.get_by_label('App language',exact=True).select_option('ru');page.get_by_label('Оформление',exact=True).select_option('dark')
  page.get_by_role('button',name='Главная',exact=True).click();page.set_viewport_size({'width':375,'height':812});assert page.evaluate('document.documentElement.scrollWidth <= innerWidth');page.screenshot(path=str(artifacts/'mobile-home.png'),full_page=True,animations='disabled')
  page.get_by_role('button',name='Игры',exact=True).click();expect(page.get_by_text('В разработке',exact=True)).to_be_visible();page.get_by_role('button',name='Настройки',exact=True).click();page.get_by_role('button',name='Удалить аккаунт',exact=True).click();expect(page.get_by_role('dialog')).to_be_visible();expect(page.get_by_role('button',name='Удалить навсегда')).to_be_disabled();page.get_by_role('button',name='Отмена',exact=True).click();page.get_by_role('button',name='Активные сессии Управляй доступом').click();expect(page.get_by_text('Текущая сессия',exact=True)).to_be_visible();assert page.evaluate('localStorage.length===0 && sessionStorage.length===0');page.get_by_role('button',name='Выйти из всех сессий').click();expect(page.get_by_text('Ты вышел из аккаунта.',exact=False)).to_be_visible();assert not errors,errors
  outside=browser.new_context(viewport={'width':375,'height':812},locale='ru-RU',reduced_motion='reduce');outside.route('https://telegram.org/js/telegram-web-app.js',lambda route:route.fulfill(status=200,body=''));gate=outside.new_page();gate.goto('http://127.0.0.1:5173');gate.wait_for_load_state('networkidle');expect(gate.get_by_text('Начни со своего профиля.',exact=False)).to_be_visible();gate.screenshot(path=str(artifacts/'outside-telegram.png'),full_page=True);assert gate.evaluate('document.documentElement.scrollWidth <= innerWidth');browser.close()
 print('PASS: real API friends search/request/accept/block/unblock; browser flow, profile and XSS escaping, interests, privacy persistence, RU/EN, themes, mobile layout, deletion dialog, session logout, empty browser storage, outside-Telegram gate; no JS errors.')
finally:
 for s in servers:
  if s.poll() is None:os.killpg(s.pid,signal.SIGTERM)
 for s in servers:
  try:s.wait(timeout=10)
  except subprocess.TimeoutExpired:os.killpg(s.pid,signal.SIGKILL)
 log.close()
