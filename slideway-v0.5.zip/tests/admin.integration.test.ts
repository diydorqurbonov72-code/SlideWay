import { test, before, after } from "node:test";
import assert from "node:assert/strict";
import { randomUUID } from "node:crypto";
import { spawn, ChildProcess } from "node:child_process";
import { PrismaClient } from "@prisma/client";
import { PrismaPg } from "@prisma/adapter-pg";
import Redis from "ioredis";
import { signed, testBotToken } from "./fixtures";
import { digest } from "../packages/security/src/telegram";
if (
  process.env.NODE_ENV !== "test" ||
  !process.env.DATABASE_URL?.endsWith("/slideway_test") ||
  !process.env.REDIS_URL?.endsWith("/15")
)
  throw new Error("Isolated test services required");
const db = new PrismaClient({
    adapter: new PrismaPg({ connectionString: process.env.DATABASE_URL }),
  }),
  redis = new Redis(process.env.REDIS_URL!);
const base = "http://127.0.0.1:3302/api/v1";
let child: ChildProcess;
let logs = "";
let owner = "",
  member = "",
  moderator = "",
  analyst = "",
  memberId = "",
  ownerId = "",
  moderatorId = "",
  analystId = "";
const request = (
  path: string,
  method = "GET",
  body?: unknown,
  token?: string,
) =>
  fetch(base + path, {
    method,
    headers: {
      "Content-Type": "application/json",
      ...(token ? { Authorization: "Bearer " + token } : {}),
    },
    body: body === undefined ? undefined : JSON.stringify(body),
  });
async function login(id: number) {
  const r = await request("/auth/telegram", "POST", {
    initData: signed(id, undefined, { query_id: randomUUID() }),
  });
  assert.equal(r.status, 200);
  return (await r.json()).accessToken as string;
}
const cmd = (
  id: string,
  action: string,
  token = owner,
  extra: Record<string, unknown> = {},
) =>
  request(
    "/admin/users/" + id + "/" + action,
    "POST",
    { operationId: randomUUID(), reason: "Integration test action", ...extra },
    token,
  );
before(async () => {
  await db.auditLog.deleteMany();
  await db.user.deleteMany();
  await db.authReplay.deleteMany();
  await redis.flushdb();
  child = spawn(process.execPath, ["dist/apps/api/src/main.js"], {
    env: {
      ...process.env,
      PORT: "3302",
      TELEGRAM_BOT_TOKEN: testBotToken,
      ALLOWED_ORIGINS: "http://localhost:5174",
      BOT_ENABLED: "false",
      ADMIN_OWNER_TELEGRAM_ID: "8765005700",
    },
    stdio: ["ignore", "pipe", "pipe"],
  });
  child.stdout?.on("data", (d) => (logs += d));
  child.stderr?.on("data", (d) => (logs += d));
  for (let i = 0; i < 100; i++) {
    try {
      if ((await request("/health/ready")).ok) break;
    } catch {}
    await new Promise((r) => setTimeout(r, 100));
  }
  owner = await login(8765005700);
  member = await login(770001);
  moderator = await login(770002);
  analyst = await login(770003);
  ownerId = (await (await request("/me", "GET", undefined, owner)).json()).id;
  memberId = (await (await request("/me", "GET", undefined, member)).json()).id;
  moderatorId = (
    await (await request("/me", "GET", undefined, moderator)).json()
  ).id;
  analystId = (await (await request("/me", "GET", undefined, analyst)).json())
    .id;
});
after(async () => {
  if (child && child.exitCode === null) {
    child.kill("SIGTERM");
    await new Promise<void>((r) => child.once("exit", () => r()));
  }
  await db.$disconnect();
  redis.disconnect();
});
test("verified owner ID gets OWNER; ordinary accounts and spoofed body do not", async () => {
  const identity = await (
    await request("/admin/me", "GET", undefined, owner)
  ).json();
  assert.equal(identity.role, "OWNER");
  assert.equal(
    (await request("/admin/dashboard", "GET", undefined, member)).status,
    403,
  );
  assert.equal((await request("/admin/users")).status, 401);
  assert.equal(
    (
      await request("/auth/telegram", "POST", {
        initData: signed(770004),
        telegramId: 8765005700,
      })
    ).status,
    400,
  );
});
test("dashboard and user search return actual database data", async () => {
  const data = await (
    await request("/admin/dashboard", "GET", undefined, owner)
  ).json();
  assert.equal(data.users, 4);
  assert.equal(data.registrations.length, 7);
  const page = await (
    await request("/admin/users?q=8765005700", "GET", undefined, owner)
  ).json();
  assert.equal(page.items.length, 1);
  assert.equal(page.items[0].telegramId, "8765005700");
});
test("owner assigns roles; revoked sessions and role restrictions are enforced", async () => {
  assert.equal(
    (await cmd(moderatorId, "role", owner, { role: "MODERATOR" })).status,
    200,
  );
  assert.equal((await request("/me", "GET", undefined, moderator)).status, 401);
  moderator = await login(770002);
  assert.equal(
    (await cmd(analystId, "role", owner, { role: "ANALYST" })).status,
    200,
  );
  analyst = await login(770003);
  assert.equal(
    (await request("/admin/users", "GET", undefined, moderator)).status,
    200,
  );
  assert.equal(
    (await request("/admin/users", "GET", undefined, analyst)).status,
    403,
  );
  assert.equal(
    (await request("/admin/dashboard", "GET", undefined, analyst)).status,
    200,
  );
  assert.equal(
    (await request("/admin/audit", "GET", undefined, analyst)).status,
    403,
  );
  assert.equal(
    (await cmd(memberId, "role", moderator, { role: "ADMINISTRATOR" })).status,
    403,
  );
});
test("owner and other administrators are protected from moderator actions", async () => {
  assert.equal((await cmd(ownerId, "ban", moderator)).status, 403);
  assert.equal((await cmd(analystId, "ban", moderator)).status, 403);
  assert.equal((await cmd(ownerId, "ban", owner)).status, 403);
  assert.equal(
    (await request("/me", "DELETE", { confirmation: "DELETE" }, owner)).status,
    403,
  );
});
test("ban revokes sessions, blocks login, is idempotent and is audited", async () => {
  const operationId = randomUUID();
  assert.equal(
    (await cmd(memberId, "ban", moderator, { operationId, durationHours: 24 }))
      .status,
    200,
  );
  assert.equal((await request("/me", "GET", undefined, member)).status, 401);
  assert.equal(
    (
      await request("/auth/telegram", "POST", {
        initData: signed(770001, undefined, { query_id: randomUUID() }),
      })
    ).status,
    403,
  );
  assert.equal(
    (await cmd(memberId, "ban", moderator, { operationId, durationHours: 24 }))
      .status,
    200,
  );
  assert.equal(await db.auditLog.count({ where: { operationId } }), 1);
  assert.equal(
    (
      await cmd(memberId, "ban", moderator, {
        operationId,
        durationHours: 24,
        reason: "Different payload",
      })
    ).status,
    409,
  );
  assert.equal((await cmd(memberId, "unban", moderator)).status, 200);
  member = await login(770001);
});
test("concurrent operation ID creates one audit record", async () => {
  const operationId = randomUUID();
  const rs = await Promise.all(
    Array.from({ length: 4 }, () =>
      cmd(memberId, "revoke-sessions", owner, { operationId }),
    ),
  );
  assert.ok(rs.some((r) => r.status === 200));
  assert.ok(rs.every((r) => [200, 409].includes(r.status)));
  assert.equal(
    (await cmd(memberId, "revoke-sessions", owner, { operationId })).status,
    200,
  );
  assert.equal(await db.auditLog.count({ where: { operationId } }), 1);
});
test("role escalation to OWNER and unknown fields are rejected", async () => {
  assert.equal(
    (await cmd(memberId, "role", owner, { role: "OWNER" })).status,
    400,
  );
  assert.equal(
    (await cmd(memberId, "ban", owner, { actorId: ownerId })).status,
    400,
  );
});
test("audit is readable by owner and includes reasons", async () => {
  const r = await request("/admin/audit", "GET", undefined, owner);
  assert.equal(r.status, 200);
  const data = await r.json();
  assert.ok(data.items.length >= 4);
  assert.ok(
    data.items.some((x: any) => x.details.reason === "Integration test action"),
  );
});
test("sensitive actions require a fresh owner session", async () => {
  await db.userSession.update({
    where: { tokenHash: digest(owner) },
    data: { createdAt: new Date(Date.now() - 601000) },
  });
  assert.equal((await cmd(memberId, "ban")).status, 401);
  assert.equal(
    (await request("/admin/dashboard", "GET", undefined, owner)).status,
    200,
  );
  assert.equal(logs.includes(testBotToken), false);
});
