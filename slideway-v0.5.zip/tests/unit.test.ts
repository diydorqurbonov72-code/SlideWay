import { test } from "node:test";
import assert from "node:assert/strict";
import {
  verifyTelegram,
  digest,
  newSessionToken,
} from "../packages/security/src/telegram";
import { profilePatch } from "../packages/shared/src";
import { readConfig } from "../packages/config/src";
import { signed, testBotToken } from "./fixtures";
const now = 1800000000;
test("valid signed identity and signature field are accepted", () => {
  assert.equal(
    verifyTelegram(
      signed(123, now, { signature: "telegram-signature" }),
      testBotToken,
      300,
      now,
    ).user.id,
    123,
  );
});
test("tampered identity is rejected", () => {
  assert.throws(() =>
    verifyTelegram(
      signed(123, now).replace("123", "456"),
      testBotToken,
      300,
      now,
    ),
  );
});
test("wrong bot token is rejected", () => {
  assert.throws(() =>
    verifyTelegram(signed(123, now), testBotToken + "x", 300, now),
  );
});
test("expired data is rejected", () => {
  assert.throws(() =>
    verifyTelegram(signed(123, now - 301), testBotToken, 300, now),
  );
});
test("future data is rejected", () => {
  assert.throws(() =>
    verifyTelegram(signed(123, now + 31), testBotToken, 300, now),
  );
});
test("duplicate fields are rejected", () => {
  assert.throws(() =>
    verifyTelegram(
      signed(123, now) + "&auth_date=" + now,
      testBotToken,
      300,
      now,
    ),
  );
});
test("missing and malformed hashes are rejected", () => {
  for (const raw of ["user=x", "hash=ab", "hash=" + "0".repeat(64)])
    assert.throws(() => verifyTelegram(raw, testBotToken, 300, now));
});
test("invalid signed JSON is rejected", () => {
  assert.throws(() =>
    verifyTelegram(signed(123, now, { user: "{" }), testBotToken, 300, now),
  );
});
test("unsafe Telegram IDs and bots are rejected", () => {
  for (const user of [
    { id: 9007199254740992, first_name: "x" },
    { id: 123, first_name: "x", is_bot: true },
  ])
    assert.throws(() =>
      verifyTelegram(
        signed(123, now, { user: JSON.stringify(user) }),
        testBotToken,
        300,
        now,
      ),
    );
});
test("request size is bounded", () => {
  assert.throws(() => verifyTelegram("x".repeat(8193), testBotToken, 300, now));
});
test("tokens are random 256-bit values and hashes differ", () => {
  const a = newSessionToken(),
    b = newSessionToken();
  assert.match(a, /^[A-Za-z0-9_-]{43}$/);
  assert.notEqual(a, b);
  assert.notEqual(digest(a), digest(b));
  assert.equal(digest(a).length, 64);
});
test("profile rejects privilege escalation and duplicate interests", () => {
  for (const p of [
    { role: "Owner" },
    { telegramId: 123 },
    { xp: 1000 },
    { settings: { isAdmin: true } },
    { interests: ["gaming", "gaming"] },
  ])
    assert.equal(profilePatch.safeParse(p).success, false);
});
test("profile validates locale and lengths", () => {
  assert.equal(
    profilePatch.safeParse({ locale: "uz", bio: "Hello" }).success,
    true,
  );
  assert.equal(
    profilePatch.safeParse({ displayName: " ", bio: "x".repeat(281) }).success,
    false,
  );
});
test("production rejects insecure or wildcard origins", () => {
  const base = {
    NODE_ENV: "production",
    DATABASE_URL: "postgresql://localhost/test",
    REDIS_URL: "redis://localhost",
    TELEGRAM_BOT_TOKEN: testBotToken,
  };
  for (const origin of ["*", "http://example.com", "https://example.com/path"])
    assert.throws(() => readConfig({ ...base, ALLOWED_ORIGINS: origin }));
});
