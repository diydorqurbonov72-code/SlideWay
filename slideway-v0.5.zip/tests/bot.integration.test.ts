import { test, before, after } from "node:test";
import assert from "node:assert/strict";
import { PrismaClient } from "@prisma/client";
import { PrismaPg } from "@prisma/adapter-pg";
import { createBot } from "../apps/bot/src/handler";
import { processNext } from "../apps/bot/src/queue";
import { testBotToken } from "./fixtures";
if (
  process.env.NODE_ENV !== "test" ||
  !process.env.DATABASE_URL?.endsWith("/slideway_test")
)
  throw new Error("Dedicated test DB required");
const db = new PrismaClient({
  adapter: new PrismaPg({ connectionString: process.env.DATABASE_URL }),
});
const bot = createBot(
  db,
  testBotToken,
  "slideway_test_bot",
  "https://example.com",
);
const sent: { method: string; payload: any }[] = [];
let mode = "ok";
bot.api.config.use(async (_previous, method, payload) => {
  if (method === "getMe")
    return {
      ok: true,
      result: {
        id: 123456789,
        is_bot: true,
        first_name: "Test",
        username: "slideway_test_bot",
      },
    } as any;
  sent.push({ method, payload });
  if (mode === "offline") throw new Error("Simulated network failure");
  if (mode === "blocked")
    return {
      ok: false,
      error_code: 403,
      description: "Forbidden: bot was blocked",
    };
  return {
    ok: true,
    result: {
      message_id: 1,
      date: 1,
      chat: { id: 990001, type: "private" },
      text: "ok",
    },
  } as any;
});
const update = (id: number, text = "/start") => ({
  update_id: id,
  message: {
    message_id: id,
    date: Math.floor(Date.now() / 1000),
    chat: { id: 990001, type: "private" as const },
    from: {
      id: 990001,
      is_bot: false as const,
      first_name: "Bot Test",
      language_code: "ru",
    },
    text,
  },
});
before(async () => {
  await bot.init();
  await db.telegramUpdate.deleteMany();
  await db.user.deleteMany({ where: { telegramId: 990001n } });
});
after(() => db.$disconnect());
test("bot creates a real user and sends an HTTPS Mini App button", async () => {
  await bot.handleUpdate(update(9001));
  const u = await db.user.findUnique({
    where: { telegramId: 990001n },
    include: { settings: true },
  });
  assert.ok(u);
  assert.equal(u.settings?.profileVisible, false);
  assert.equal(sent.at(-1)?.method, "sendMessage");
  assert.equal(
    sent.at(-1)?.payload.reply_markup.inline_keyboard[0][0].web_app.url,
    "https://example.com/#home",
  );
});
test("bot reads existing profile without overwriting edited name", async () => {
  await db.user.update({
    where: { telegramId: 990001n },
    data: { displayName: "Edited", bio: "Saved bio" },
  });
  await bot.handleUpdate(update(9002, "/profile"));
  assert.match(sent.at(-1)?.payload.text, /Edited/);
  assert.match(sent.at(-1)?.payload.text, /Saved bio/);
});
test("bot ignores commands directed to other bots", async () => {
  const n = sent.length;
  await bot.handleUpdate(update(9003, "/start@other_bot"));
  assert.equal(sent.length, n);
});
test("concurrent workers claim one inbox item exactly once", async () => {
  await db.telegramUpdate.create({
    data: { id: 9010n, payload: update(9010) },
  });
  const n = sent.length;
  await Promise.all([
    processNext(db, (u) => bot.handleUpdate(u)),
    processNext(db, (u) => bot.handleUpdate(u)),
  ]);
  assert.equal(sent.length, n + 1);
  const row = await db.telegramUpdate.findUnique({ where: { id: 9010n } });
  assert.equal(row?.status, "done");
  assert.equal(row?.payload, null);
  assert.equal(row?.attempts, 1);
});
test("transient failure retries and clears PII after success", async () => {
  await db.telegramUpdate.create({
    data: { id: 9011n, payload: update(9011) },
  });
  mode = "offline";
  await processNext(db, (u) => bot.handleUpdate(u));
  let row = await db.telegramUpdate.findUnique({ where: { id: 9011n } });
  assert.equal(row?.status, "pending");
  assert.ok(row?.payload);
  assert.equal(await processNext(db, (u) => bot.handleUpdate(u)), false);
  await db.telegramUpdate.update({
    where: { id: 9011n },
    data: { availableAt: new Date(0) },
  });
  mode = "ok";
  await processNext(db, (u) => bot.handleUpdate(u));
  row = await db.telegramUpdate.findUnique({ where: { id: 9011n } });
  assert.equal(row?.status, "done");
  assert.equal(row?.attempts, 2);
  assert.equal(row?.payload, null);
});
test("blocked bot is terminal and does not retry forever", async () => {
  await db.telegramUpdate.create({
    data: { id: 9012n, payload: update(9012) },
  });
  mode = "blocked";
  await processNext(db, (u) => bot.handleUpdate(u));
  mode = "ok";
  const row = await db.telegramUpdate.findUnique({ where: { id: 9012n } });
  assert.equal(row?.status, "failed");
  assert.equal(row?.payload, null);
});
test("expired lease is reclaimed after worker crash", async () => {
  await db.telegramUpdate.create({
    data: {
      id: 9013n,
      payload: update(9013),
      status: "processing",
      lockedUntil: new Date(0),
      attempts: 1,
    },
  });
  await processNext(db, (u) => bot.handleUpdate(u));
  assert.equal(
    (await db.telegramUpdate.findUnique({ where: { id: 9013n } }))?.status,
    "done",
  );
});

test("hidden commands do not respond to ordinary users", async () => {
  const count = sent.length;
  await bot.handleUpdate(update(9500, "/admin"));
  await bot.handleUpdate(update(9501, "/stats"));
  assert.equal(sent.length, count);
});
test("owner hidden command opens the admin Mini App", async () => {
  const data = update(9502, "/admin");
  data.message.chat.id = 8765005700;
  data.message.from.id = 8765005700;
  await bot.handleUpdate(data);
  assert.equal(
    sent.at(-1)?.payload.reply_markup.inline_keyboard[0][0].web_app.url,
    "https://example.com/admin/",
  );
});

test("owner stats command reads real counts", async () => {
  const data = update(9503, "/stats");
  data.message.chat.id = 8765005700;
  data.message.from.id = 8765005700;
  await bot.handleUpdate(data);
  const count = await db.user.count();
  assert.match(sent.at(-1)?.payload.text, new RegExp("Пользователи: " + count));
});

test("explicitly delegated admin can open panel but not owner stats", async () => {
  const user = await db.user.findUniqueOrThrow({
    where: { telegramId: 990001n },
  });
  await db.adminUser.create({ data: { userId: user.id, role: "SUPPORT" } });
  await bot.handleUpdate(update(9504, "/admin"));
  assert.equal(
    sent.at(-1)?.payload.reply_markup.inline_keyboard[0][0].web_app.url,
    "https://example.com/admin/",
  );
  const count = sent.length;
  await bot.handleUpdate(update(9505, "/stats"));
  assert.equal(sent.length, count);
});
