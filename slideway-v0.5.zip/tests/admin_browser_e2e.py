"""Real admin API + PostgreSQL; synthetic Telegram context is injected by the test only."""
import os,time,json,hmac,hashlib,urllib.parse,urllib.request,urllib.error,subprocess,uuid,signal
from pathlib import Path
from playwright.sync_api import sync_playwright,expect
root=Path(__file__).resolve().parents[1]
if os.environ.get('NODE_ENV')!='test' or not os.environ.get('DATABASE_URL','').endswith('/slideway_test') or not os.environ.get('REDIS_URL','').endswith('/15'):raise RuntimeError('Isolated test services required')
subprocess.run(['node','-e',"const r=new(require('ioredis'))(process.env.REDIS_URL);r.flushdb().finally(()=>r.quit());"],cwd=root,check=True)
artifacts=root.parent/'admin-browser-artifacts';artifacts.mkdir(exist_ok=True)
bot_token='123456789:test_token_for_automated_tests_only'
def signed(uid,name='Алекс'):
 data={'auth_date':str(int(time.time())),'query_id':str(uuid.uuid4()),'user':json.dumps({'id':uid,'first_name':name,'language_code':'ru'},ensure_ascii=False,separators=(',',':'))}
 secret=hmac.new(b'WebAppData',bot_token.encode(),hashlib.sha256).digest();data['hash']=hmac.new(secret,'\n'.join(f'{k}={v}' for k,v in sorted(data.items())).encode(),hashlib.sha256).hexdigest();return urllib.parse.urlencode(data)
def api(path,method='GET',body=None,token=None):
 req=urllib.request.Request('http://127.0.0.1:3000/api/v1'+path,method=method,data=json.dumps(body).encode() if body is not None else None,headers={'Content-Type':'application/json',**({'Authorization':'Bearer '+token} if token else {})})
 try:
  with urllib.request.urlopen(req,timeout=15) as res:return res.status,json.load(res)
 except urllib.error.HTTPError as e:return e.code,None
def ready(url):
 for _ in range(120):
  try:
   with urllib.request.urlopen(url,timeout=1) as res:
    if res.status==200:return
  except Exception:pass
  time.sleep(.15)
 raise RuntimeError('Server did not start: '+url)
log=open(artifacts/'servers.log','w');env={**os.environ,'PORT':'3000','TELEGRAM_BOT_TOKEN':bot_token,'ALLOWED_ORIGINS':'http://127.0.0.1:5174','BOT_ENABLED':'false','ADMIN_OWNER_TELEGRAM_ID':'8765005700'}
servers=[subprocess.Popen(cmd,cwd=root,env=env,stdout=log,stderr=log,start_new_session=True) for cmd in [['node','dist/apps/api/src/main.js'],['npm','run','dev:admin']]]
try:
 ready('http://127.0.0.1:3000/api/v1/health/ready');ready('http://127.0.0.1:5174/admin/')
 target_name='Мария '+uuid.uuid4().hex[:5];target_id=600000000+int(time.time())
 status,auth=api('/auth/telegram','POST',{'initData':signed(target_id,target_name)});assert status==200;target_token=auth['accessToken']
 with sync_playwright() as p:
  browser=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox'])
  def context(uid):
   ctx=browser.new_context(viewport={'width':1440,'height':1000},locale='ru-RU');ctx.route('https://telegram.org/js/telegram-web-app.js',lambda route:route.fulfill(status=200,body=''));ctx.add_init_script('window.Telegram={WebApp:{initData:'+json.dumps(signed(uid))+',ready(){},expand(){}}};');return ctx
  ctx=context(8765005700);page=ctx.new_page();errors=[];page.on('pageerror',lambda e:errors.append(str(e)));page.goto('http://127.0.0.1:5174/admin/');page.wait_for_load_state('networkidle');expect(page.get_by_role('heading',name='Платформа под контролем.')).to_be_visible();page.screenshot(path=str(artifacts/'admin-dashboard.png'),full_page=True,animations='disabled')
  page.get_by_role('link',name='Пользователи',exact=True).click();page.get_by_label('Поиск пользователей').fill(target_name);page.get_by_role('button',name='Найти',exact=True).click();expect(page.get_by_text(target_name,exact=True)).to_be_visible();page.screenshot(path=str(artifacts/'admin-users.png'),full_page=True)
  page.get_by_role('button',name='Управлять: '+target_name).click();expect(page.get_by_role('dialog')).to_be_visible();page.get_by_label('Причина действия').fill('Проверка ограничения E2E');page.get_by_role('button',name='Подтвердить действие').click();expect(page.get_by_role('dialog')).not_to_be_visible();expect(page.get_by_text('Ограничен',exact=True)).to_be_visible();assert api('/me',token=target_token)[0]==401
  page.get_by_role('button',name='Управлять: '+target_name).click();page.get_by_label('Причина действия').fill('Ограничение снято E2E');page.get_by_role('button',name='Подтвердить действие').click();expect(page.get_by_role('dialog')).not_to_be_visible();expect(page.get_by_text('Активен',exact=True)).to_be_visible()
  page.get_by_role('button',name='Управлять: '+target_name).click();page.get_by_label('Действие',exact=True).select_option('role');page.get_by_label('Новая роль').select_option('ANALYST');page.get_by_label('Причина действия').fill('Проверка роли E2E');page.screenshot(path=str(artifacts/'admin-action.png'),full_page=True);page.get_by_role('button',name='Подтвердить действие').click();expect(page.get_by_role('dialog')).not_to_be_visible();expect(page.get_by_text('Аналитик',exact=True)).to_be_visible()
  page.get_by_role('link',name='Журнал действий',exact=True).click();expect(page.get_by_text('Проверка роли E2E',exact=True)).to_be_visible();page.screenshot(path=str(artifacts/'admin-audit.png'),full_page=True)
  page.get_by_role('link',name='Обзор',exact=True).click();page.set_viewport_size({'width':375,'height':812});assert page.evaluate('document.documentElement.scrollWidth<=innerWidth');page.screenshot(path=str(artifacts/'admin-mobile.png'),full_page=True);assert page.evaluate('localStorage.length===0&&sessionStorage.length===0');assert not errors,errors
  denied=context(target_id+1).new_page();denied.goto('http://127.0.0.1:5174/admin/');expect(denied.get_by_role('heading',name='Доступ ограничен.')).to_be_visible();assert denied.get_by_role('link',name='Пользователи',exact=True).count()==0;browser.close()
 print('PASS: verified owner dashboard; real search, ban, session revocation, unban, role assignment and audit; mobile layout; ordinary user denied; no browser storage or JS errors.')
finally:
 for s in servers:
  if s.poll() is None:os.killpg(s.pid,signal.SIGTERM)
 for s in servers:
  try:s.wait(timeout=10)
  except subprocess.TimeoutExpired:os.killpg(s.pid,signal.SIGKILL)
 log.close()
