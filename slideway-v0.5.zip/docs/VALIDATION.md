# Проверки текущей сборки 0.5

## Успешно выполнено

| Проверка | Результат |
|---|---|
| Prisma generate | успешно |
| TypeScript API + worker | успешно |
| TypeScript/Vite Mini App | успешно, отдельные lazy-loaded страницы |
| TypeScript/Vite Control Center | успешно, отдельные lazy-loaded страницы |
| SQL-миграции | 5 миграций применены к PostgreSQL |
| Unit tests | 17/17 |
| Integration tests | 40/40 |
| Mini App browser E2E | пройден |
| Control Center browser E2E | пройден |
| Production npm audit | 0 известных уязвимостей на момент проверки |
| Compose config с telegram profile | успешно |
| Nginx -t в реальном непривилегированном контейнере | успешно, с локальным тестовым сертификатом |
| OpenAPI JSON | синтаксис проверен, 23 пути; отдельный semantic validator не запускался |

Интеграционные тесты используют настоящие PostgreSQL 17 и Redis 7, а не in-memory replacements. Внешний Telegram transport подменяется только в bot tests; production-код всегда вызывает Telegram API. Browser tests запускают Chromium, реальный API и Vite, внедряя только синтетический Telegram launch context.

## Что проверено

- Друзья: opt-in поиск, приватные поля исключены, идемпотентная заявка, только получатель принимает, чужое удаление не работает, блокировки, unblock, self-target, конкурентная заявка/блокировка, rate limit.
- Уведомления: создание в транзакции с социальной связью, дедупликация, непрочитанный счётчик, владение read/delete, отсутствие Telegram ID, очистка после блокировки.
- Браузер: поиск второго тестового пользователя, отправка заявки, принятие через реальный API, центр активности, прочтение, отображение дружбы, блокировка/разблокировка. Списки обновляются при входе и каждые 15 секунд.

- HMAC initData, срок, будущая дата, поддельная подпись, duplicate fields, размер тела, ограничения Telegram ID.
- Конкурентный обмен одинакового initData: одна сессия; строгие profile payload; приватность; сохранение интересов; отзыв/expiry; чужие сессии; удаление и cascade.
- Webhook secret, concurrent update_id deduplication, реальные user upserts, bot commands/links, queue lease, retry, обработка Telegram 403, clearing payload.
- Owner 8765005700 определяется только после проверки Telegram; обычный пользователь получает 403; подмена ID/роли не повышает права.
- Administrator/Moderator/Support/Analyst permissions, защита Owner, запрет изменения админов модератором, бан/разбан, отзыв сессий, запрет входа заблокированному, role change + reauthentication.
- Atomic audit + idempotency, конкурирующие одинаковые operation IDs, конфликт изменённого payload, свежесть admin session.
- Скрытые команды: обычным пользователям нет ответа; Owner /admin и /stats; явно делегированная роль /admin, но не /stats.
- Mini App: сохранение профиля, экранирование XSS-подобного текста, интересы, приватность после переходов, RU/EN, light/dark, мобильная ширина 375px, delete confirmation, logout.
- Admin browser: реальные dashboard/search/ban/unban/role/audit, отзыв сессии после бана, mobile layout, отказ обычному аккаунту.
- В браузерных сценариях нет JS errors и записей токенов в localStorage/sessionStorage.

## Найденные и исправленные проблемы

- grammY оборачивает Telegram ошибки в BotError: worker теперь извлекает внутреннюю ошибку, поэтому блокировка бота не повторяется бесконечно.
- Интеграционный rate-limit test оставлял лимиты для browser test: browser suites очищают только явно выделенную Redis DB 15 перед запуском.
- Непривилегированный Nginx не мог прочитать конфигурацию с mode 600: права конфигурации и владельцы COPY исправлены. Production private key должен оставаться ограниченным; тестовые сертификаты не поставляются.
- После возобновления среды тестовые контейнеры были остановлены: они запущены заново, проверки повторены успешно.

## Не подтверждено

- Реальный BotFather/webhook registration и Telegram Android/iOS/Desktop: секреты/домен не предоставлены, вызов bot:register не выполнялся.
- Полная production Docker-сборка и Compose/TLS E2E. Предыдущая сборка исчерпала дисковую квоту при финальном COPY. Конфигурации обновлены, но полный образ после изменений не пересобран.
- GitHub-hosted CI: workflow создан, выполнение в GitHub не запускалось.
- Внешний pentest, полный WCAG-аудит, нагрузка 1k/10k/100k, backup restore drill.
- Чат, жалобы, игровые и финансовые сценарии: эти модули ещё не реализованы.

Скриншоты в docs/screenshots относятся к тестовой БД, не к production-пользователям. Нулевой npm audit не означает гарантированную защиту от всех атак.
