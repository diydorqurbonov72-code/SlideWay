# Развёртывание Foundation

## VPS

1. Установить Docker и Compose, настроить DNS домена, время/NTP, входящий 443 и ограниченный SSH.
2. Создать `.env` из примера с правами 0600. Заменить все пароли и bot token. Для сети контейнеров: `DATABASE_URL=postgresql://USER:URL_ENCODED_PASSWORD@db:5432/slideway`, `REDIS_URL=redis://redis:6379`. Значения должны соответствовать POSTGRES_*. Для API — production и HTTPS ALLOWED_ORIGINS.
3. Получить доверенный TLS-сертификат и положить `fullchain.pem`, `privkey.pem` в `infrastructure/nginx/certs/`. Этот каталог исключён из Git и build context. Дать чтение ключа только nginx UID/GID (обычно 101); организовать автоматическое продление. После продления `docker compose exec proxy nginx -s reload`.
4. `docker compose build`, затем `docker compose up -d`. Миграция выполняется до запуска API.
5. `docker compose run --rm migrate npm run db:seed` загружает только справочник интересов.
6. Проверить `docker compose ps` и `curl https://YOUR_DOMAIN/api/v1/health/ready`.

Без сертификата proxy не запустится. PostgreSQL, Redis и API не имеют опубликованных портов. Теперь webhook, worker и frontend реализованы. Их подключение описано ниже. Полный Compose-запуск в данной среде не подтверждён — см. VALIDATION.md.

Для локального запуска API на хосте используйте локальные БД/Redis либо отдельный Compose override с портами, привязанными только к 127.0.0.1. Для корпоративного CA Dockerfile поддерживает build secret proxy_ca; не отключать TLS validation.

## Обновления

Сначала backup и проверка восстановления, затем миграции на staging. `docker compose build`, `docker compose run --rm migrate`, `docker compose up -d --force-recreate api proxy`. Хранить предыдущий образ. Миграции не откатываются автоматически; в будущем использовать expand/contract. Текущая миграция только начальная.

## Backup

```sh
mkdir -p backups
chmod 700 backups
docker compose exec -T db pg_dump -U slideway -d slideway -Fc > backups/slideway.dump
chmod 600 backups/slideway.dump
```

Подставить фактические имя пользователя/БД. Проверить exit code и размер. Копировать в зашифрованное внешнее хранилище; автоматический backup/S3 upload в данном модуле отсутствует. Retention утверждается оператором.

## Restore

Восстанавливать сначала в новую изолированную БД, не поверх рабочей:

```sh
docker compose exec -T db createdb -U slideway slideway_restore
docker compose exec -T db pg_restore -U slideway -d slideway_restore --no-owner --exit-on-error < backups/slideway.dump
```

Проверить данные и сценарии. До подключения пользователей удалить восстановленные UserSession/AuthReplay, учесть удаления аккаунтов после даты backup. Затем согласованно переключить DATABASE_URL и перезапустить API. RPO/RTO не измерены; полный restore drill не проведён. Redis содержит только лимиты, backup не требуется.

## Эксплуатация

Настроить log rotation, alerts на readiness/5xx/диск/соединения, DB runtime-роль с минимальными DML-правами, отдельную migration-роль. Внешний PostgreSQL/Redis подключать с TLS. SIGTERM обрабатывается NestJS, соединения закрываются lifecycle hooks. Не подключать недоверенные контейнеры к внутренней сети.


## Запуск 0.5: обе панели, друзья, активность и бот

Compose proxy теперь собирает оба React-приложения: `/` и `/admin/`. API image собирает NestJS и worker. В .env задать ADMIN_OWNER_TELEGRAM_ID=8765005700 и BOT_ENABLED=true, реальные token/username/secret, MINIAPP_URL=https://YOUR_DOMAIN, WEBHOOK_URL=https://YOUR_DOMAIN/api/v1/telegram/webhook, ALLOWED_ORIGINS=https://YOUR_DOMAIN. VITE_BOT_USERNAME передаётся frontend-сборке из TELEGRAM_BOT_USERNAME и не является секретом.

`docker compose --profile telegram up -d --build` запускает API, миграцию, proxy и bot worker. Затем `docker compose run --rm migrate npm run db:seed` и, отдельно при готовом HTTPS, `docker compose run --rm migrate npm run bot:register`.

Проверить /api/v1/health/ready, открыть бот, /start и /admin с аккаунта владельца. API readiness не проверяет фактическую работу worker/Telegram; следить за backlog и логами worker. Для прекращения ошибок доставки проверить getWebhookInfo и журналы, не выводя token в чат.

Конфигурация Nginx должна быть читаема пользователем контейнера (`chmod 644 infrastructure/nginx/default.conf`). Директории сертификатов должны быть доступны на чтение/проход nginx UID/GID, private key — только доверенной группе. В rootless Docker учесть UID mapping. Нельзя применять права тестовых сертификатов к production-ключам.

Полная сборка/запуск всех production-контейнеров в этой ограниченной среде не подтверждены. Проверены TypeScript/Vite, Compose config, Nginx syntax и приложения с настоящими PostgreSQL/Redis; см. VALIDATION.md.
